# Кадровая система «Ак Барс Банк»

## Быстрый запуск

```bash
npm install
npm run db:reset && npm run db:seed    # пересоздать БД и засидить
npm run dev                            # http://localhost:3000
```

## Демо-аккаунты

Пароль у всех: **`demo1234`**

| Роль          | Логин                 |
| ------------- | --------------------- |
| Руководитель  | `manager@demo.local`  |
| Сотрудник     | `employee@demo.local` |
| Сотрудник     | `smirnova@demo.local` |
| Сотрудник     | `volkov@demo.local`   |

## Скрипты

| Команда              | Назначение                                       |
| -------------------- | ------------------------------------------------ |
| `npm run dev`        | dev-сервер (HMR)                                 |
| `npm run build`      | production-сборка                                |
| `npm run start`      | запуск production-сборки                         |
| `npm run lint`       | ESLint                                           |
| `npm run db:migrate` | применить миграции и сгенерировать клиента       |
| `npm run db:reset`   | удалить БД, применить миграции и засидить заново |
| `npm run db:seed`    | наполнить БД демо-данными                        |
| `npm run db:studio`  | Prisma Studio для ручного просмотра БД           |
