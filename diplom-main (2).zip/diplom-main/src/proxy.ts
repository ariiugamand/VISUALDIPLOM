// защита роутов
import { NextResponse, type NextRequest } from "next/server";
import { decryptSessionEdge } from "@/lib/session-edge";

const PUBLIC_ROUTES = ["/", "/login", "/register", "/forgot-password"];

function isPublic(path: string): boolean {
  return PUBLIC_ROUTES.includes(path);
}

export async function proxy(request: NextRequest) {
  const { pathname } = request.nextUrl;

  if (pathname === "/logout") return NextResponse.next();

  const token = request.cookies.get("session")?.value;
  const session = await decryptSessionEdge(token);

  if (!session && !isPublic(pathname)) {
    const url = request.nextUrl.clone();
    url.pathname = "/login";
    url.searchParams.set("next", pathname);
    return NextResponse.redirect(url);
  }

  if (session && (pathname === "/login" || pathname === "/register")) {
    const url = request.nextUrl.clone();
    url.pathname = "/dashboard";
    url.search = "";
    return NextResponse.redirect(url);
  }

  return NextResponse.next();
}

export const config = {
  matcher: ["/((?!api|_next/static|_next/image|favicon.ico|.*\\..*).*)"],
};
