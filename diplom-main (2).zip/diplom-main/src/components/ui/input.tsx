import { forwardRef, type InputHTMLAttributes, type ReactNode } from "react";
import { cn } from "@/lib/cn";

interface InputProps extends InputHTMLAttributes<HTMLInputElement> {
  leadingIcon?: ReactNode;
  trailingIcon?: ReactNode;
  variant?: "pill" | "rounded";
}

const BASE =
  "block w-full bg-surface text-foreground placeholder:text-placeholder outline-none transition border border-border-soft focus:border-brand focus:ring-4 focus:ring-brand/10 disabled:bg-muted disabled:cursor-not-allowed shadow-[0_1px_3px_-1px_rgb(0_0_0_/_0.05)]";

export const Input = forwardRef<HTMLInputElement, InputProps>(function Input(
  { className, leadingIcon, trailingIcon, variant = "rounded", ...props },
  ref,
) {
  const radius = variant === "pill" ? "rounded-full" : "rounded-xl";

  if (leadingIcon || trailingIcon) {
    return (
      <div className="relative">
        {leadingIcon && (
          <span className="pointer-events-none absolute left-4 top-1/2 -translate-y-1/2 text-text-soft">
            {leadingIcon}
          </span>
        )}
        <input
          ref={ref}
          className={cn(
            BASE,
            radius,
            "py-2.5 text-sm",
            leadingIcon ? "pl-11" : "pl-4",
            trailingIcon ? "pr-11" : "pr-4",
            className,
          )}
          {...props}
        />
        {trailingIcon && (
          <span className="pointer-events-none absolute right-4 top-1/2 -translate-y-1/2 text-text-soft">
            {trailingIcon}
          </span>
        )}
      </div>
    );
  }

  return (
    <input
      ref={ref}
      className={cn(BASE, radius, "px-4 py-2.5 text-sm", className)}
      {...props}
    />
  );
});
