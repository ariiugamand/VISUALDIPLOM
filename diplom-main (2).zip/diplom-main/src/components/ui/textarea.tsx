import { forwardRef, type TextareaHTMLAttributes } from "react";
import { cn } from "@/lib/cn";

export const Textarea = forwardRef<HTMLTextAreaElement, TextareaHTMLAttributes<HTMLTextAreaElement>>(
  function Textarea({ className, ...props }, ref) {
    return (
      <textarea
        ref={ref}
        className={cn(
          "block w-full rounded-2xl border bg-surface px-4 py-3 text-sm outline-none transition",
          "border-border text-foreground placeholder:text-placeholder",
          "focus:border-brand focus:ring-4 focus:ring-brand/10",
          "disabled:bg-muted disabled:cursor-not-allowed",
          "shadow-[0_1px_3px_-1px_rgb(0_0_0_/_0.05)] resize-y min-h-[120px]",
          className,
        )}
        {...props}
      />
    );
  },
);
