import { forwardRef, type ButtonHTMLAttributes } from "react";
import { cn } from "@/lib/cn";

type Variant = "primary" | "secondary" | "outline" | "ghost" | "danger" | "soft";
type Size = "sm" | "md" | "lg";

interface ButtonProps extends ButtonHTMLAttributes<HTMLButtonElement> {
  variant?: Variant;
  size?: Size;
}

const VARIANTS: Record<Variant, string> = {
  primary:
    "bg-brand text-white hover:bg-brand-hover active:bg-brand-dark disabled:bg-brand/50 shadow-[0_2px_6px_-2px_rgb(47_122_92_/_0.3)]",
  secondary:
    "bg-surface text-foreground border border-border hover:bg-muted disabled:opacity-50",
  outline:
    "bg-transparent text-foreground border border-foreground/80 hover:bg-foreground hover:text-white disabled:opacity-50",
  soft:
    "bg-accent-soft text-brand-dark hover:bg-accent/80 disabled:opacity-50",
  ghost: "bg-transparent text-foreground hover:bg-muted",
  danger: "bg-danger-soft text-white hover:bg-danger disabled:opacity-50",
};

const SIZES: Record<Size, string> = {
  sm: "px-4 py-2 text-sm",
  md: "px-5 py-2.5 text-sm",
  lg: "px-6 py-3 text-base",
};

export const Button = forwardRef<HTMLButtonElement, ButtonProps>(function Button(
  { variant = "primary", size = "md", className, ...props },
  ref,
) {
  return (
    <button
      ref={ref}
      className={cn(
        "inline-flex items-center justify-center gap-2 rounded-lg font-medium transition whitespace-nowrap",
        "disabled:cursor-not-allowed",
        VARIANTS[variant],
        SIZES[size],
        className,
      )}
      {...props}
    />
  );
});
