import type { ReactNode } from "react";
import { cn } from "@/lib/cn";

type Props = {
  title: string;
  subtitle?: ReactNode;
  actions?: ReactNode;
  children: ReactNode;
  titleAlign?: "left" | "center";
  hideWash?: boolean;
};

// обёртка страницы
export function PageShell({
  title,
  subtitle,
  actions,
  children,
  titleAlign = "left",
  hideWash = false,
}: Props) {
  return (
    <div className="px-5 md:px-10 py-6 md:py-8">
      <div
        className={cn(
          "mb-4 md:mb-5 flex flex-col gap-3 md:flex-row md:items-end md:justify-between",
          titleAlign === "center" && "text-center items-center md:justify-center",
        )}
      >
        <div>
          <h1 className="text-2xl md:text-[38px] font-bold tracking-tight text-foreground leading-tight">
            {title}
          </h1>
          {subtitle && (
            <p className="mt-1 text-sm md:text-base text-text-soft">{subtitle}</p>
          )}
        </div>
        {actions && <div className="flex flex-wrap items-center gap-2">{actions}</div>}
      </div>
      {hideWash ? (
        children
      ) : (
        <div className="rounded-[24px] wash-bg p-4 md:p-6 border border-border-soft">
          {children}
        </div>
      )}
    </div>
  );
}

export function PageHeader({
  title,
  subtitle,
  actions,
  titleAlign = "left",
}: {
  title: string;
  subtitle?: string;
  actions?: ReactNode;
  titleAlign?: "left" | "center";
}) {
  return (
    <div
      className={cn(
        "mb-5 flex flex-col gap-3 md:flex-row md:items-end md:justify-between",
        titleAlign === "center" && "text-center items-center md:justify-center",
      )}
    >
      <div>
        <h1 className="text-2xl md:text-[38px] font-bold tracking-tight text-foreground leading-tight">
          {title}
        </h1>
        {subtitle && <p className="mt-1 text-sm md:text-base text-text-soft">{subtitle}</p>}
      </div>
      {actions && <div className="flex items-center gap-2">{actions}</div>}
    </div>
  );
}
