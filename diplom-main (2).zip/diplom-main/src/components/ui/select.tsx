import { forwardRef, type SelectHTMLAttributes } from "react";
import { cn } from "@/lib/cn";

interface SelectProps extends SelectHTMLAttributes<HTMLSelectElement> {
  variant?: "pill" | "rounded";
}

export const Select = forwardRef<HTMLSelectElement, SelectProps>(
  function Select({ className, children, variant = "rounded", ...props }, ref) {
    const radius = variant === "pill" ? "rounded-full" : "rounded-xl";
    return (
      <div className="relative">
        <select
          ref={ref}
          className={cn(
            "block w-full appearance-none bg-surface px-4 py-2.5 pr-10 text-sm outline-none transition",
            "border border-border-soft text-foreground",
            "focus:border-brand focus:ring-4 focus:ring-brand/10",
            "disabled:bg-muted disabled:cursor-not-allowed",
            "shadow-[0_1px_3px_-1px_rgb(0_0_0_/_0.05)]",
            radius,
            className,
          )}
          {...props}
        >
          {children}
        </select>
        <span className="pointer-events-none absolute right-4 top-1/2 -translate-y-1/2 text-text-soft">
          <svg width="12" height="8" viewBox="0 0 12 8" fill="none" aria-hidden>
            <path d="M1 1.5L6 6.5L11 1.5" stroke="currentColor" strokeWidth="1.6" strokeLinecap="round" strokeLinejoin="round" />
          </svg>
        </span>
      </div>
    );
  },
);
