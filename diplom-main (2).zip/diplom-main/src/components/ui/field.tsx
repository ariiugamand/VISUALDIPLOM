import type { ReactNode } from "react";

export function Field({
  label,
  error,
  hint,
  children,
}: {
  label: string;
  error?: string;
  hint?: string;
  children: ReactNode;
}) {
  return (
    <label className="block space-y-1.5">
      {label && (
        <span className="text-sm font-medium text-text-soft">{label}</span>
      )}
      {children}
      {error ? (
        <span className="block text-xs text-danger pl-4">{error}</span>
      ) : hint ? (
        <span className="block text-xs text-text-muted pl-4">{hint}</span>
      ) : null}
    </label>
  );
}
