import type { ReactNode } from "react";
import { PageShell } from "./page-shell";

export function StubPage({
  title,
  children,
}: {
  title: string;
  description?: string;
  children?: ReactNode;
}) {
  return (
    <PageShell title={title}>
      <div className="flex flex-col items-center justify-center py-16 gap-3">
        <div className="inline-flex items-center gap-2 text-sm px-4 py-1.5 rounded-full bg-accent-soft text-brand-dark font-medium">
          Раздел в разработке
        </div>
        {children}
      </div>
    </PageShell>
  );
}
