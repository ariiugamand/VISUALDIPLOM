import Image from "next/image";

// лого
export function BrandLogo({ className = "" }: { className?: string }) {
  return (
    <div className={`flex items-center ${className}`}>
      <Image
        src="/brand/akbars-logo.png"
        alt="Ак Барс Банк"
        width={594}
        height={180}
        priority
        className="h-8 w-auto dark:invert dark:hue-rotate-180 dark:brightness-110"
      />
    </div>
  );
}
