"use client";

import Link from "next/link";
import { usePathname } from "next/navigation";
import { Calendar, CalendarDays, FileText, CheckSquare, Users } from "lucide-react";
import { cn } from "@/lib/cn";

type Tab = { label: string; href: string; icon: typeof Calendar };

const EMPLOYEE_TABS: Tab[] = [
  { label: "График", href: "/schedule", icon: Calendar },
  { label: "События", href: "/events", icon: CalendarDays },
  { label: "Заявления", href: "/applications", icon: FileText },
  { label: "Задачи", href: "/tasks", icon: CheckSquare },
];

const MANAGER_TABS: Tab[] = [
  { label: "Отдел", href: "/employees", icon: Users },
  { label: "График", href: "/schedule", icon: Calendar },
  { label: "Заявления", href: "/applications", icon: FileText },
  { label: "Задачи", href: "/tasks", icon: CheckSquare },
];

export function MobileTabBar({ role }: { role: "MANAGER" | "EMPLOYEE" }) {
  const pathname = usePathname();
  const tabs = role === "MANAGER" ? MANAGER_TABS : EMPLOYEE_TABS;

  return (
    <nav
      aria-label="Нижняя навигация"
      className="md:hidden fixed bottom-0 inset-x-0 z-30 px-3 pb-3 pt-2 pointer-events-none"
    >
      <ul
        className={cn(
          "flex items-center gap-1 rounded-[28px] p-1.5 shadow-[0_8px_24px_-8px_rgb(0_0_0_/_0.15)] pointer-events-auto",
          "bg-[linear-gradient(180deg,#c9e6d3_0%,#b1dcc2_100%)]",
          "dark:bg-[linear-gradient(180deg,#1f2b27_0%,#151d1a_100%)] dark:border dark:border-border-soft",
        )}
      >
        {tabs.map(({ label, href, icon: Icon }) => {
          const active = pathname === href || pathname.startsWith(href + "/");
          return (
            <li key={href} className="flex-1">
              <Link
                href={href}
                className={cn(
                  "flex flex-col items-center justify-center gap-0.5 py-1.5 rounded-[20px] text-[10px] leading-tight transition",
                  active
                    ? "bg-surface text-brand-dark font-medium shadow-[0_2px_6px_-2px_rgb(0_0_0_/_0.15)]"
                    : "text-brand-dark/80 hover:text-brand-dark dark:text-accent/80 dark:hover:text-accent",
                )}
              >
                <Icon size={18} strokeWidth={active ? 2.2 : 1.8} />
                <span className="px-1">{label}</span>
              </Link>
            </li>
          );
        })}
      </ul>
    </nav>
  );
}
