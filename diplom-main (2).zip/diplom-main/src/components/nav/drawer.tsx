"use client";

import Link from "next/link";
import { usePathname } from "next/navigation";
import { X, Bell, Sun, Moon, Info } from "lucide-react";
import { NAV_ITEMS } from "./navigation";
import { cn } from "@/lib/cn";
import { BrandLogo } from "@/components/brand/logo";
import { useTheme } from "@/components/theme/theme-provider";

type Props = {
  open: boolean;
  onClose: () => void;
  role: "MANAGER" | "EMPLOYEE";
};

export function NavDrawer({ open, onClose, role }: Props) {
  const pathname = usePathname();
  const [theme, setTheme] = useTheme();
  const items = NAV_ITEMS.filter((item) => item.roles.includes(role));

  return (
    <>
      <div
        className={cn(
          "fixed inset-0 bg-black/30 backdrop-blur-sm z-40 transition-opacity",
          open ? "opacity-100" : "opacity-0 pointer-events-none",
        )}
        onClick={onClose}
      />
      <aside
        className={cn(
          "fixed top-0 left-0 h-full w-72 bg-surface shadow-2xl z-50 transition-transform flex flex-col",
          open ? "translate-x-0" : "-translate-x-full",
        )}
      >
        <div className="h-16 px-5 flex items-center justify-between border-b border-border-soft shrink-0">
          <BrandLogo />
          <button
            onClick={onClose}
            className="w-9 h-9 flex items-center justify-center rounded-lg hover:bg-muted transition"
            aria-label="Закрыть меню"
          >
            <X size={20} />
          </button>
        </div>

        <nav className="flex-1 overflow-y-auto p-3">
          <div className="px-3 py-2 text-[11px] uppercase tracking-wide text-text-muted font-medium">
            Меню
          </div>
          <ul className="space-y-0.5">
            {items.map(({ label, href, icon: Icon }) => {
              const active = pathname === href || pathname.startsWith(href + "/");
              return (
                <li key={href}>
                  <Link
                    href={href}
                    onClick={onClose}
                    className={cn(
                      "flex items-center gap-3 px-3 py-2.5 rounded-lg text-sm transition",
                      active
                        ? "bg-brand text-white font-medium"
                        : "text-foreground hover:bg-muted",
                    )}
                  >
                    <Icon size={18} />
                    <span>{label}</span>
                  </Link>
                </li>
              );
            })}
          </ul>
        </nav>

        <div className="border-t border-border-soft p-3 shrink-0 space-y-0.5">
          <Link
            href="/notifications"
            onClick={onClose}
            className="w-full flex items-center gap-3 px-3 py-2 rounded-lg text-sm text-text-soft hover:bg-muted transition"
          >
            <Bell size={16} />
            <span>Уведомления</span>
          </Link>
          <button
            type="button"
            onClick={() => setTheme(theme === "dark" ? "light" : "dark")}
            className="w-full flex items-center gap-3 px-3 py-2 rounded-lg text-sm text-text-soft hover:bg-muted transition text-left"
          >
            {theme === "dark" ? <Sun size={16} /> : <Moon size={16} />}
            <span className="flex-1">Тема: {theme === "dark" ? "тёмная" : "светлая"}</span>
          </button>
          <Link
            href="/about"
            onClick={onClose}
            className="w-full flex items-center gap-3 px-3 py-2 rounded-lg text-sm text-text-soft hover:bg-muted transition"
          >
            <Info size={16} />
            <span>О приложении</span>
          </Link>
        </div>
      </aside>
    </>
  );
}
