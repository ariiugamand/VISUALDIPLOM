import {
  Calendar,
  CalendarDays,
  ClipboardList,
  FileText,
  Files,
  BookOpen,
  CheckSquare,
  Users,
  LayoutDashboard,
  UserCircle,
} from "lucide-react";
import type { LucideIcon } from "lucide-react";

export type NavItem = {
  label: string;
  href: string;
  icon: LucideIcon;
  roles: Array<"MANAGER" | "EMPLOYEE">;
};

export const NAV_ITEMS: NavItem[] = [
  {
    label: "Главная",
    href: "/dashboard",
    icon: LayoutDashboard,
    roles: ["MANAGER", "EMPLOYEE"],
  },
  {
    label: "Рабочий график",
    href: "/schedule",
    icon: Calendar,
    roles: ["MANAGER", "EMPLOYEE"],
  },
  {
    label: "Мероприятия",
    href: "/events",
    icon: CalendarDays,
    roles: ["MANAGER", "EMPLOYEE"],
  },
  {
    label: "Заявления",
    href: "/applications",
    icon: ClipboardList,
    roles: ["MANAGER", "EMPLOYEE"],
  },
  {
    label: "Задачи",
    href: "/tasks",
    icon: CheckSquare,
    roles: ["MANAGER", "EMPLOYEE"],
  },
  {
    label: "Отчёты",
    href: "/reports",
    icon: FileText,
    roles: ["MANAGER", "EMPLOYEE"],
  },
  {
    label: "Шаблоны документов",
    href: "/templates",
    icon: Files,
    roles: ["MANAGER", "EMPLOYEE"],
  },
  {
    label: "База знаний",
    href: "/knowledge",
    icon: BookOpen,
    roles: ["MANAGER", "EMPLOYEE"],
  },
  {
    label: "Мой отдел",
    href: "/employees",
    icon: Users,
    roles: ["MANAGER"],
  },
  {
    label: "Личный кабинет",
    href: "/profile",
    icon: UserCircle,
    roles: ["MANAGER", "EMPLOYEE"],
  },
];
