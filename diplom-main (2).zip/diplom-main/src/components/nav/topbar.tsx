"use client";

import { useState } from "react";
import Link from "next/link";
import { Bell, Menu, LogOut } from "lucide-react";
import { logoutAction } from "@/app/actions/auth";
import { BrandLogo } from "@/components/brand/logo";
import { WatermarkToggle } from "@/components/watermark/watermark";
import { NavDrawer } from "./drawer";

type Props = {
  firstName: string;
  lastName: string;
  position: string | null;
  role: "MANAGER" | "EMPLOYEE";
  unreadCount?: number;
};

export function Topbar({ firstName, lastName, position, role, unreadCount = 0 }: Props) {
  const [open, setOpen] = useState(false);
  const initials = `${lastName[0] ?? ""}${firstName[0] ?? ""}`.toUpperCase();

  return (
    <>
      <header className="h-16 border-b border-border-soft bg-surface flex items-center justify-between px-6 shrink-0">
        <div className="flex items-center gap-4">
          <button
            onClick={() => setOpen(true)}
            className="w-10 h-10 flex items-center justify-center rounded-full hover:bg-muted transition"
            aria-label="Меню"
          >
            <Menu size={22} strokeWidth={2} />
          </button>
          <BrandLogo />
          <div className="hidden sm:block h-6 w-px bg-border mx-1" />
          <div className="hidden sm:block text-sm text-text-soft">Кадровая система</div>
        </div>

        <div className="flex items-center gap-3">
          <WatermarkToggle />
          <Link
            href="/notifications"
            className="relative w-10 h-10 flex items-center justify-center rounded-lg hover:bg-muted transition"
            aria-label="Уведомления"
          >
            <Bell size={20} strokeWidth={2} />
            {unreadCount > 0 && (
              <span className="absolute top-2 right-2 w-2.5 h-2.5 rounded-full bg-accent border-2 border-surface" />
            )}
          </Link>

          <Link
            href="/profile"
            className="flex items-center gap-3 pl-2 group"
            aria-label="Личный кабинет"
          >
            <div className="text-right hidden md:block">
              <div className="text-sm font-medium text-foreground leading-tight group-hover:text-brand transition">
                {lastName} {firstName}
              </div>
              <div className="text-xs text-text-soft leading-tight">
                {position ?? (role === "MANAGER" ? "Руководитель" : "Сотрудник")}
              </div>
            </div>
            <div className="w-10 h-10 rounded-full bg-muted text-text-soft flex items-center justify-center text-sm font-semibold group-hover:bg-accent-soft group-hover:text-brand-dark transition">
              {initials}
            </div>
          </Link>
          <form action={logoutAction}>
            <button
              type="submit"
              className="w-10 h-10 flex items-center justify-center rounded-full text-text-soft hover:text-danger hover:bg-muted transition"
              aria-label="Выйти"
            >
              <LogOut size={18} />
            </button>
          </form>
        </div>
      </header>

      <NavDrawer open={open} onClose={() => setOpen(false)} role={role} />
    </>
  );
}
