"use client";

import { useEffect, useState } from "react";
import { Droplet, DropletOff } from "lucide-react";

const STORAGE_KEY = "mxide-watermark-on";
const EVENT_NAME = "mxide-watermark-change";

function useWatermarkState(): [boolean, (v: boolean) => void] {
  const [on, setOn] = useState(false);

  useEffect(() => {
    try {
      setOn(localStorage.getItem(STORAGE_KEY) === "1");
    } catch {}

    const onChange = () => {
      try {
        setOn(localStorage.getItem(STORAGE_KEY) === "1");
      } catch {}
    };
    window.addEventListener(EVENT_NAME, onChange);
    window.addEventListener("storage", onChange);
    return () => {
      window.removeEventListener(EVENT_NAME, onChange);
      window.removeEventListener("storage", onChange);
    };
  }, []);

  const set = (v: boolean) => {
    setOn(v);
    try {
      localStorage.setItem(STORAGE_KEY, v ? "1" : "0");
    } catch {}
    window.dispatchEvent(new Event(EVENT_NAME));
  };

  return [on, set];
}

// водяной знак
export function WatermarkOverlay() {
  const [on, setOn] = useWatermarkState();

  useEffect(() => {
    const onKey = (e: KeyboardEvent) => {
      if (!e.ctrlKey || !e.shiftKey) return;
      const key = (e.key ?? "").toLowerCase();
      if (key === "w" || key === "ц") {
        e.preventDefault();
        setOn(!on);
      }
    };
    window.addEventListener("keydown", onKey);
    return () => window.removeEventListener("keydown", onKey);
  }, [on, setOn]);

  if (!on) return null;

  const rows = 10;
  const cols = 7;
  const cells = Array.from({ length: rows * cols }, (_, i) => i);

  return (
    <div
      aria-hidden
      className="fixed inset-0 z-[9999] pointer-events-none overflow-hidden select-none"
      style={{ contain: "strict" }}
    >
      <div
        className="absolute inset-0 grid"
        style={{
          gridTemplateColumns: `repeat(${cols}, 1fr)`,
          gridTemplateRows: `repeat(${rows}, 1fr)`,
          transform: "rotate(-25deg) scale(1.45)",
          transformOrigin: "center",
        }}
      >
        {cells.map((i) => (
          <div
            key={i}
            className="flex items-center justify-center"
            style={{
              animation: `mxide-drift ${7 + (i % 6)}s ease-in-out ${-(i % 9)}s infinite alternate`,
            }}
          >
            <span
              className="text-3xl md:text-4xl font-bold whitespace-nowrap"
              style={{
                color: "rgba(15, 25, 21, 0.11)",
                letterSpacing: "0.08em",
                textShadow: "0 0 1px rgba(255,255,255,0.35)",
              }}
            >
              mxide
            </span>
          </div>
        ))}
      </div>
      <style>{`
        @keyframes mxide-drift {
          0%   { transform: translate(0, 0); }
          35%  { transform: translate(-12px, 8px); }
          70%  { transform: translate(6px, -10px); }
          100% { transform: translate(14px, 4px); }
        }
      `}</style>
    </div>
  );
}

export function WatermarkToggle({ className = "" }: { className?: string }) {
  const [on, setOn] = useWatermarkState();

  return (
    <button
      onClick={() => setOn(!on)}
      className={`w-10 h-10 flex items-center justify-center rounded-full hover:bg-muted transition ${className}`}
      title={on ? "Выключить водяной знак (Ctrl+Shift+W)" : "Включить водяной знак (Ctrl+Shift+W)"}
      aria-label="Водяной знак"
    >
      {on ? (
        <Droplet size={18} className="text-brand" />
      ) : (
        <DropletOff size={18} className="text-text-soft" />
      )}
    </button>
  );
}
