"use client";

import { useEffect, useState } from "react";

type Theme = "light" | "dark";
const KEY = "theme";
const EVENT = "theme-change";

function applyTheme(t: Theme) {
  if (typeof document === "undefined") return;
  document.documentElement.classList.toggle("dark", t === "dark");
}

export function ThemeProvider({ children }: { children: React.ReactNode }) {
  useEffect(() => {
    try {
      const v = (localStorage.getItem(KEY) as Theme) ?? "light";
      applyTheme(v);
    } catch {}
  }, []);
  return <>{children}</>;
}

export function useTheme(): [Theme, (t: Theme) => void] {
  const [theme, setTheme] = useState<Theme>("light");
  useEffect(() => {
    try {
      setTheme((localStorage.getItem(KEY) as Theme) ?? "light");
    } catch {}
    const onChange = () => {
      try {
        setTheme((localStorage.getItem(KEY) as Theme) ?? "light");
      } catch {}
    };
    window.addEventListener(EVENT, onChange);
    window.addEventListener("storage", onChange);
    return () => {
      window.removeEventListener(EVENT, onChange);
      window.removeEventListener("storage", onChange);
    };
  }, []);

  const set = (t: Theme) => {
    setTheme(t);
    try {
      localStorage.setItem(KEY, t);
    } catch {}
    applyTheme(t);
    window.dispatchEvent(new Event(EVENT));
  };

  return [theme, set];
}
