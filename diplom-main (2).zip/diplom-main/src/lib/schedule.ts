// типы смен
export const SHIFT_TYPES = [
  { value: "WORK", label: "Рабочий день", color: "#52b788" },
  { value: "WEEKEND", label: "Выходной", color: "#c8a13a" },
  { value: "VACATION", label: "Отпуск", color: "#2a7dc7" },
  { value: "SICK", label: "Больничный", color: "#c44848" },
  { value: "EVENT", label: "Мероприятие", color: "#8a5fd2" },
] as const;

export type ShiftType = (typeof SHIFT_TYPES)[number]["value"];

export const MONTHS_RU = [
  "Январь", "Февраль", "Март", "Апрель", "Май", "Июнь",
  "Июль", "Август", "Сентябрь", "Октябрь", "Ноябрь", "Декабрь",
];

export const WEEKDAYS_RU = ["Пн", "Вт", "Ср", "Чт", "Пт", "Сб", "Вс"];

export function shiftTypeInfo(v: string) {
  return SHIFT_TYPES.find((s) => s.value === v) ?? null;
}

export function daysInMonth(year: number, month: number): number {
  return new Date(year, month + 1, 0).getDate();
}

// понедельник = 0
export function weekdayIndex(date: Date): number {
  const d = date.getDay();
  return (d + 6) % 7;
}
