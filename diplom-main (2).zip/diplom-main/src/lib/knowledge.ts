// категории
export const KNOWLEDGE_CATEGORIES = [
  "Обслуживание",
  "Кредитование",
  "Вклады",
  "Карты",
  "Для сотрудников",
  "Прочее",
] as const;

export type KnowledgeCategory = (typeof KNOWLEDGE_CATEGORIES)[number];
