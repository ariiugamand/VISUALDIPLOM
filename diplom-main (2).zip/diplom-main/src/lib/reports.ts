// типы/статусы отчётов
export const REPORT_TYPES = [
  "Квартальный",
  "По кредитованию",
  "По вкладам",
  "По обслуживанию",
  "Внутренний",
  "Прочее",
] as const;

export const REPORT_STATUSES = [
  { value: "DRAFT", label: "Подготовлен" },
  { value: "IN_REVIEW", label: "На проверке" },
  { value: "SUBMITTED", label: "Отправлен" },
] as const;

export function reportStatusLabel(v: string): string {
  return REPORT_STATUSES.find((s) => s.value === v)?.label ?? v;
}

export function reportStatusBadge(v: string): string {
  switch (v) {
    case "DRAFT":
      return "bg-muted text-text-soft";
    case "IN_REVIEW":
      return "bg-blue-50 text-info";
    case "SUBMITTED":
      return "bg-accent-soft text-brand-dark";
    default:
      return "bg-muted text-text-soft";
  }
}
