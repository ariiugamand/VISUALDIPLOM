import "server-only";
import { promises as fs } from "fs";
import path from "path";
import { randomUUID } from "crypto";

export const UPLOADS_ROOT = path.join(process.cwd(), "uploads");
export const APPLICATIONS_DIR = path.join(UPLOADS_ROOT, "applications");
export const TASKS_DIR = path.join(UPLOADS_ROOT, "tasks");
export const REPORTS_DIR = path.join(UPLOADS_ROOT, "reports");
export const TEMPLATES_DIR = path.join(UPLOADS_ROOT, "templates");

export const MAX_FILE_SIZE = 10 * 1024 * 1024;
export const MAX_FILES_PER_APPLICATION = 5;
export const MAX_FILES_PER_TASK = 3;
export const MAX_FILES_PER_REPORT = 10;
export const MAX_TEMPLATE_PDF_SIZE = 15 * 1024 * 1024;

export const ALLOWED_MIME = new Set([
  "image/png",
  "image/jpeg",
  "image/webp",
  "image/gif",
  "application/pdf",
  "application/msword",
  "application/vnd.openxmlformats-officedocument.wordprocessingml.document",
  "application/vnd.ms-excel",
  "application/vnd.openxmlformats-officedocument.spreadsheetml.sheet",
  "text/plain",
]);

export function isAllowedFile(file: File): string | null {
  if (file.size > MAX_FILE_SIZE) {
    return `Файл «${file.name}» больше 10 МБ`;
  }
  if (!ALLOWED_MIME.has(file.type) && file.type !== "") {
    return `Недопустимый тип файла: «${file.name}» (${file.type})`;
  }
  return null;
}

// санитайз имени
export function makeStoredName(originalName: string): string {
  const ext = path.extname(originalName).toLowerCase().slice(0, 10);
  const base = path
    .basename(originalName, path.extname(originalName))
    .replace(/[^\wа-яА-ЯёЁ.\- ]+/g, "")
    .slice(0, 80)
    .trim()
    .replace(/\s+/g, "_");
  return `${randomUUID()}__${base || "file"}${ext}`;
}

export async function saveApplicationFile(
  applicationId: string,
  file: File,
): Promise<{ storedName: string; fullPath: string; relativePath: string }> {
  const dir = path.join(APPLICATIONS_DIR, applicationId);
  await fs.mkdir(dir, { recursive: true });
  const storedName = makeStoredName(file.name);
  const fullPath = path.join(dir, storedName);
  const bytes = Buffer.from(await file.arrayBuffer());
  await fs.writeFile(fullPath, bytes);
  return {
    storedName,
    fullPath,
    relativePath: path.posix.join("applications", applicationId, storedName),
  };
}

export async function readStoredFile(
  relativePath: string,
): Promise<Buffer> {
  const safeRelative = relativePath.replace(/\\/g, "/");
  if (safeRelative.includes("..")) throw new Error("Invalid path");
  const full = path.join(UPLOADS_ROOT, safeRelative);
  if (!full.startsWith(UPLOADS_ROOT)) throw new Error("Invalid path");
  return fs.readFile(full);
}

export async function deleteApplicationFiles(applicationId: string): Promise<void> {
  const dir = path.join(APPLICATIONS_DIR, applicationId);
  await fs.rm(dir, { recursive: true, force: true });
}

export async function saveTaskFile(
  taskId: string,
  file: File,
): Promise<{ storedName: string; fullPath: string; relativePath: string }> {
  const dir = path.join(TASKS_DIR, taskId);
  await fs.mkdir(dir, { recursive: true });
  const storedName = makeStoredName(file.name);
  const fullPath = path.join(dir, storedName);
  const bytes = Buffer.from(await file.arrayBuffer());
  await fs.writeFile(fullPath, bytes);
  return {
    storedName,
    fullPath,
    relativePath: path.posix.join("tasks", taskId, storedName),
  };
}

export async function deleteTaskFiles(taskId: string): Promise<void> {
  const dir = path.join(TASKS_DIR, taskId);
  await fs.rm(dir, { recursive: true, force: true });
}

export async function saveReportFile(
  reportId: string,
  file: File,
): Promise<{ storedName: string; fullPath: string; relativePath: string }> {
  const dir = path.join(REPORTS_DIR, reportId);
  await fs.mkdir(dir, { recursive: true });
  const storedName = makeStoredName(file.name);
  const fullPath = path.join(dir, storedName);
  const bytes = Buffer.from(await file.arrayBuffer());
  await fs.writeFile(fullPath, bytes);
  return {
    storedName,
    fullPath,
    relativePath: path.posix.join("reports", reportId, storedName),
  };
}

export async function deleteReportFiles(reportId: string): Promise<void> {
  const dir = path.join(REPORTS_DIR, reportId);
  await fs.rm(dir, { recursive: true, force: true });
}

export function isPdfFile(file: File): string | null {
  if (file.size > MAX_TEMPLATE_PDF_SIZE) {
    return `Файл больше ${Math.round(MAX_TEMPLATE_PDF_SIZE / 1024 / 1024)} МБ`;
  }
  const nameLower = file.name.toLowerCase();
  const looksPdf =
    file.type === "application/pdf" || nameLower.endsWith(".pdf");
  if (!looksPdf) return "Разрешены только PDF-файлы";
  return null;
}

export async function saveTemplatePdf(
  templateId: string,
  file: File,
): Promise<{ storedName: string; fullPath: string; relativePath: string }> {
  const dir = path.join(TEMPLATES_DIR, templateId);
  await fs.mkdir(dir, { recursive: true });
  const storedName = makeStoredName(file.name);
  const fullPath = path.join(dir, storedName);
  const bytes = Buffer.from(await file.arrayBuffer());
  await fs.writeFile(fullPath, bytes);
  return {
    storedName,
    fullPath,
    relativePath: path.posix.join("templates", templateId, storedName),
  };
}

export async function deleteTemplateFiles(templateId: string): Promise<void> {
  const dir = path.join(TEMPLATES_DIR, templateId);
  await fs.rm(dir, { recursive: true, force: true });
}

export async function deleteStoredFile(relativePath: string): Promise<void> {
  const safeRelative = relativePath.replace(/\\/g, "/");
  if (safeRelative.includes("..")) return;
  const full = path.join(UPLOADS_ROOT, safeRelative);
  if (!full.startsWith(UPLOADS_ROOT)) return;
  await fs.rm(full, { force: true });
}
