import "server-only";
import { redirect } from "next/navigation";
import { prisma } from "./prisma";
import { getSession, type SessionPayload } from "./session";

export type AuthUser = Awaited<ReturnType<typeof loadUser>>;

async function loadUser(userId: string) {
  return prisma.user.findUnique({
    where: { id: userId },
    include: { department: true },
  });
}

export async function getCurrentUser() {
  const session = await getSession();
  if (!session) return null;
  const user = await loadUser(session.userId);
  return user;
}

export async function requireAuth(): Promise<{
  session: SessionPayload;
  user: NonNullable<AuthUser>;
}> {
  const session = await getSession();
  if (!session) redirect("/login");
  const user = await loadUser(session.userId);
  // юзер удалён
  if (!user) redirect("/logout");
  if (user.status !== "ACTIVE") redirect("/logout");
  return { session, user };
}

export async function requireRole(role: "MANAGER" | "EMPLOYEE") {
  const ctx = await requireAuth();
  if (ctx.session.role !== role) {
    redirect("/dashboard");
  }
  return ctx;
}
