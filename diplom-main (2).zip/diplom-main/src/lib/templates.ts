// типы
export const TEMPLATE_TYPES = [
  "Договор",
  "Заявление",
  "Справка",
  "Уведомление",
  "Доверенность",
  "Служебная записка",
  "Акт",
  "Прочее",
] as const;

export type TemplateType = (typeof TEMPLATE_TYPES)[number];
