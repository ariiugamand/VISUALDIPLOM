// для proxy
import { jwtVerify } from "jose";

export type SessionPayload = {
  userId: string;
  role: "MANAGER" | "EMPLOYEE";
  expiresAt: number;
};

function getSecret(): Uint8Array {
  const secret = process.env.SESSION_SECRET;
  if (!secret) throw new Error("SESSION_SECRET is not set");
  return new TextEncoder().encode(secret);
}

export async function decryptSessionEdge(
  token: string | undefined,
): Promise<SessionPayload | null> {
  if (!token) return null;
  try {
    const { payload } = await jwtVerify(token, getSecret(), { algorithms: ["HS256"] });
    if (typeof payload.userId !== "string") return null;
    if (payload.role !== "MANAGER" && payload.role !== "EMPLOYEE") return null;
    if (typeof payload.expiresAt !== "number") return null;
    return {
      userId: payload.userId,
      role: payload.role,
      expiresAt: payload.expiresAt,
    };
  } catch {
    return null;
  }
}
