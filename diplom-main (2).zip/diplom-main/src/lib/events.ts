// типы события
export const EVENT_IMPORTANCES = [
  { value: "IMPORTANT", label: "Важное объявление", severity: "Высокая" },
  { value: "ACTIVITY", label: "Активность", severity: "Средняя" },
  { value: "CORPORATE", label: "Корпоратив", severity: "Низкая" },
] as const;

export type EventImportance = (typeof EVENT_IMPORTANCES)[number]["value"];

export function importanceLabel(v: string): string {
  return EVENT_IMPORTANCES.find((i) => i.value === v)?.label ?? v;
}

export function severityLabel(v: string): string {
  return EVENT_IMPORTANCES.find((i) => i.value === v)?.severity ?? "—";
}

export function isImportant(v: string): boolean {
  return v === "IMPORTANT";
}
