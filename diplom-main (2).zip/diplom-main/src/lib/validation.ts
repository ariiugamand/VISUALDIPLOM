import { z } from "zod";

export const LoginSchema = z.object({
  login: z.string().min(1, { error: "Укажите email или телефон" }).trim(),
  password: z.string().min(1, { error: "Введите пароль" }),
});

export const RegisterSchema = z
  .object({
    email: z.email({ error: "Некорректный email" }).trim(),
    phone: z.string().trim().optional().or(z.literal("")),
    firstName: z.string().min(1, { error: "Введите имя" }).trim(),
    lastName: z.string().min(1, { error: "Введите фамилию" }).trim(),
    middleName: z.string().trim().optional().or(z.literal("")),
    position: z.string().trim().optional().or(z.literal("")),
    role: z.enum(["MANAGER", "EMPLOYEE"]).default("EMPLOYEE"),
    password: z
      .string()
      .min(8, { error: "Минимум 8 символов" })
      .regex(/[a-zA-Zа-яА-Я]/, { error: "Должна быть хотя бы одна буква" })
      .regex(/[0-9]/, { error: "Должна быть хотя бы одна цифра" }),
    passwordConfirm: z.string(),
  })
  .refine((data) => data.password === data.passwordConfirm, {
    error: "Пароли не совпадают",
    path: ["passwordConfirm"],
  });

export const EmployeeCreateSchema = z.object({
  email: z.email({ error: "Некорректный email" }).trim(),
  phone: z.string().trim().optional().or(z.literal("")),
  firstName: z.string().min(1, { error: "Введите имя" }).trim(),
  lastName: z.string().min(1, { error: "Введите фамилию" }).trim(),
  middleName: z.string().trim().optional().or(z.literal("")),
  position: z.string().trim().optional().or(z.literal("")),
  departmentId: z.string().trim().optional().or(z.literal("")),
  role: z.enum(["MANAGER", "EMPLOYEE"]).default("EMPLOYEE"),
  password: z.string().min(8, { error: "Минимум 8 символов" }),
});

export const EmployeeUpdateSchema = z.object({
  id: z.string().min(1),
  email: z.email({ error: "Некорректный email" }).trim(),
  phone: z.string().trim().optional().or(z.literal("")),
  firstName: z.string().min(1, { error: "Введите имя" }).trim(),
  lastName: z.string().min(1, { error: "Введите фамилию" }).trim(),
  middleName: z.string().trim().optional().or(z.literal("")),
  position: z.string().trim().optional().or(z.literal("")),
  departmentId: z.string().trim().optional().or(z.literal("")),
  role: z.enum(["MANAGER", "EMPLOYEE"]),
  status: z.enum(["ACTIVE", "SUSPENDED", "FIRED"]).default("ACTIVE"),
});
