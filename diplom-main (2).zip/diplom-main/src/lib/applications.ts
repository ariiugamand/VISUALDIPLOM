// типы заявлений
export const APPLICATION_TYPES = [
  { value: "VACATION", label: "Отпуск" },
  { value: "SICK_LEAVE", label: "Больничный" },
  { value: "SCHEDULE_CHANGE", label: "Изменение графика" },
  { value: "PROFILE_CHANGE", label: "Изменение личных данных" },
  { value: "OTHER", label: "Прочее" },
] as const;

export type ApplicationType = (typeof APPLICATION_TYPES)[number]["value"];

export const APPLICATION_STATUSES = [
  { value: "CREATED", label: "Создано" },
  { value: "SENT", label: "Отправлено" },
  { value: "APPROVED", label: "Одобрено" },
  { value: "REJECTED", label: "Отклонено" },
] as const;

export type ApplicationStatus = (typeof APPLICATION_STATUSES)[number]["value"];

export function typeLabel(type: string): string {
  return APPLICATION_TYPES.find((t) => t.value === type)?.label ?? type;
}

export function statusLabel(status: string): string {
  return APPLICATION_STATUSES.find((s) => s.value === status)?.label ?? status;
}

export function statusBadgeClasses(status: string): string {
  switch (status) {
    case "CREATED":
      return "bg-muted text-text-soft";
    case "SENT":
      return "bg-blue-50 text-info";
    case "APPROVED":
      return "bg-accent-soft text-brand-dark";
    case "REJECTED":
      return "bg-red-50 text-danger";
    default:
      return "bg-muted text-text-soft";
  }
}
