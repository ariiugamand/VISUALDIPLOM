import { NextResponse } from "next/server";
import { prisma } from "@/lib/prisma";
import { requireAuth } from "@/lib/auth";
import { readStoredFile } from "@/lib/uploads";

// PDF
export async function GET(
  req: Request,
  ctx: { params: Promise<{ id: string }> },
) {
  await requireAuth();
  const { id } = await ctx.params;

  const tpl = await prisma.documentTemplate.findUnique({
    where: { id },
    select: { pdfUrl: true, pdfFilename: true },
  });
  if (!tpl || !tpl.pdfUrl) {
    return new NextResponse("Not found", { status: 404 });
  }

  try {
    const buf = await readStoredFile(tpl.pdfUrl);
    const url = new URL(req.url);
    const isDownload = url.searchParams.get("download") === "1";
    const disposition = isDownload
      ? `attachment; filename*=UTF-8''${encodeURIComponent(tpl.pdfFilename ?? "template.pdf")}`
      : `inline; filename*=UTF-8''${encodeURIComponent(tpl.pdfFilename ?? "template.pdf")}`;

    return new NextResponse(new Uint8Array(buf), {
      status: 200,
      headers: {
        "Content-Type": "application/pdf",
        "Content-Length": String(buf.byteLength),
        "Content-Disposition": disposition,
      },
    });
  } catch {
    return new NextResponse("File missing on disk", { status: 404 });
  }
}
