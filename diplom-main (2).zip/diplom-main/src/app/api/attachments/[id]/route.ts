import { NextResponse } from "next/server";
import { prisma } from "@/lib/prisma";
import { requireAuth } from "@/lib/auth";
import { readStoredFile } from "@/lib/uploads";

// файл
export async function GET(
  _req: Request,
  ctx: { params: Promise<{ id: string }> },
) {
  const { session, user } = await requireAuth();
  const { id } = await ctx.params;
  const isManager = session.role === "MANAGER";

  let filename: string | null = null;
  let url: string | null = null;
  let mimeType: string | null = null;
  let allowed = false;

  // заявление
  const app = await prisma.applicationAttachment.findUnique({
    where: { id },
    include: { application: { select: { userId: true } } },
  });
  if (app) {
    filename = app.filename;
    url = app.url;
    mimeType = app.mimeType;
    allowed = isManager || app.application.userId === user.id;
  }

  // задача
  if (!filename) {
    const task = await prisma.taskAttachment.findUnique({
      where: { id },
      include: { task: { select: { assigneeId: true, createdById: true } } },
    });
    if (task) {
      filename = task.filename;
      url = task.url;
      mimeType = task.mimeType;
      allowed =
        isManager ||
        task.task.assigneeId === user.id ||
        task.task.createdById === user.id;
    }
  }

  // отчёт
  if (!filename) {
    const rep = await prisma.reportAttachment.findUnique({
      where: { id },
      include: { report: { select: { authorId: true } } },
    });
    if (rep) {
      filename = rep.filename;
      url = rep.url;
      mimeType = rep.mimeType;
      allowed = isManager || rep.report.authorId === user.id;
    }
  }

  if (!filename || !url) return new NextResponse("Not found", { status: 404 });
  if (!allowed) return new NextResponse("Forbidden", { status: 403 });

  try {
    const buf = await readStoredFile(url);
    return new NextResponse(new Uint8Array(buf), {
      status: 200,
      headers: {
        "Content-Type": mimeType || "application/octet-stream",
        "Content-Length": String(buf.byteLength),
        "Content-Disposition": `attachment; filename*=UTF-8''${encodeURIComponent(filename)}`,
      },
    });
  } catch {
    return new NextResponse("File missing on disk", { status: 404 });
  }
}
