import { NextResponse } from "next/server";
import { destroySession } from "@/lib/session";

// выход
export async function GET(request: Request) {
  await destroySession();
  const url = new URL("/login", request.url);
  return NextResponse.redirect(url);
}

export async function POST(request: Request) {
  await destroySession();
  const url = new URL("/login", request.url);
  return NextResponse.redirect(url, { status: 303 });
}
