"use server";

import { z } from "zod";
import { redirect } from "next/navigation";
import { prisma } from "@/lib/prisma";
import { hashPassword } from "@/lib/password";

const RESET_CODE = "0000";

const schema = z
  .object({
    email: z.email({ error: "Укажите email" }).trim(),
    code: z.string().trim().min(1, { error: "Введите код" }),
    password: z
      .string()
      .min(8, { error: "Минимум 8 символов" })
      .regex(/[a-zA-Zа-яА-Я]/, { error: "Хотя бы одна буква" })
      .regex(/[0-9]/, { error: "Хотя бы одна цифра" }),
    passwordConfirm: z.string(),
  })
  .refine((d) => d.password === d.passwordConfirm, {
    error: "Пароли не совпадают",
    path: ["passwordConfirm"],
  });

export type ResetFormState =
  | { errors?: Record<string, string[] | undefined>; message?: string; ok?: boolean }
  | undefined;

export async function resetPasswordAction(
  _prev: ResetFormState,
  formData: FormData,
): Promise<ResetFormState> {
  const parsed = schema.safeParse({
    email: formData.get("email"),
    code: formData.get("code"),
    password: formData.get("password"),
    passwordConfirm: formData.get("passwordConfirm"),
  });
  if (!parsed.success) return { errors: parsed.error.flatten().fieldErrors };

  if (parsed.data.code !== RESET_CODE) {
    return { message: `Неверный код подтверждения (для теста используйте ${RESET_CODE})` };
  }

  const user = await prisma.user.findUnique({
    where: { email: parsed.data.email.toLowerCase() },
  });
  if (!user) return { message: "Пользователь с таким email не найден" };

  await prisma.user.update({
    where: { id: user.id },
    data: { passwordHash: await hashPassword(parsed.data.password) },
  });

  redirect("/login?reset=1");
}
