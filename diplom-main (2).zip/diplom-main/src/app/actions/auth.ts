"use server";

import { redirect } from "next/navigation";
import { prisma } from "@/lib/prisma";
import { hashPassword, verifyPassword } from "@/lib/password";
import { createSession, destroySession } from "@/lib/session";
import { LoginSchema, RegisterSchema } from "@/lib/validation";

export type AuthFormState =
  | {
      errors?: Record<string, string[] | undefined>;
      message?: string;
    }
  | undefined;

export async function loginAction(_prev: AuthFormState, formData: FormData): Promise<AuthFormState> {
  const parsed = LoginSchema.safeParse({
    login: formData.get("login"),
    password: formData.get("password"),
  });

  if (!parsed.success) {
    return { errors: parsed.error.flatten().fieldErrors };
  }

  const { login, password } = parsed.data;

  const user = await prisma.user.findFirst({
    where: {
      OR: [{ email: login.toLowerCase() }, { phone: login }],
    },
  });

  if (!user) {
    return { message: "Неверный логин или пароль" };
  }
  if (user.status !== "ACTIVE") {
    return { message: "Учётная запись отключена. Обратитесь к руководителю." };
  }

  const ok = await verifyPassword(password, user.passwordHash);
  if (!ok) {
    return { message: "Неверный логин или пароль" };
  }

  await createSession(user.id, user.role as "MANAGER" | "EMPLOYEE");
  redirect("/dashboard");
}

export async function registerAction(
  _prev: AuthFormState,
  formData: FormData,
): Promise<AuthFormState> {
  const parsed = RegisterSchema.safeParse({
    email: formData.get("email"),
    phone: formData.get("phone") ?? "",
    firstName: formData.get("firstName"),
    lastName: formData.get("lastName"),
    middleName: formData.get("middleName") ?? "",
    position: formData.get("position") ?? "",
    role: formData.get("role") ?? "EMPLOYEE",
    password: formData.get("password"),
    passwordConfirm: formData.get("passwordConfirm"),
  });

  if (!parsed.success) {
    return { errors: parsed.error.flatten().fieldErrors };
  }

  const data = parsed.data;
  const email = data.email.toLowerCase();

  const exists = await prisma.user.findFirst({
    where: {
      OR: [{ email }, ...(data.phone ? [{ phone: data.phone }] : [])],
    },
    select: { id: true },
  });
  if (exists) {
    return { message: "Пользователь с таким email или телефоном уже существует" };
  }

  const passwordHash = await hashPassword(data.password);
  const user = await prisma.user.create({
    data: {
      email,
      phone: data.phone || null,
      firstName: data.firstName,
      lastName: data.lastName,
      middleName: data.middleName || null,
      position: data.position || null,
      role: data.role,
      passwordHash,
    },
  });

  await createSession(user.id, user.role as "MANAGER" | "EMPLOYEE");
  redirect("/dashboard");
}

export async function logoutAction(): Promise<void> {
  await destroySession();
  redirect("/login");
}
