import type { Metadata } from "next";
import { Geist } from "next/font/google";
import "./globals.css";
import { WatermarkOverlay } from "@/components/watermark/watermark";
import { ThemeProvider } from "@/components/theme/theme-provider";

const geistSans = Geist({
  variable: "--font-geist-sans",
  subsets: ["latin", "cyrillic"],
});

export const metadata: Metadata = {
  title: "Корпоративный портал",
  description: "Система управления графиком, задачами и сотрудниками",
};

// избежать FOUC
const themeInitScript = `
try {
  var t = localStorage.getItem('theme');
  if (t === 'dark') document.documentElement.classList.add('dark');
} catch (e) {}
`;

export default function RootLayout({
  children,
}: {
  children: React.ReactNode;
}) {
  return (
    <html
      lang="ru"
      className={`${geistSans.variable} h-full antialiased`}
      suppressHydrationWarning
    >
      <head>
        <script dangerouslySetInnerHTML={{ __html: themeInitScript }} />
      </head>
      <body className="min-h-full bg-background text-foreground">
        <ThemeProvider>{children}</ThemeProvider>
        <WatermarkOverlay />
      </body>
    </html>
  );
}
