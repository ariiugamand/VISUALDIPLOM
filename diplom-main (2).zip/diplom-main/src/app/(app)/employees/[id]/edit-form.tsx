"use client";

import { useActionState } from "react";
import { updateEmployeeAction, type EmployeeFormState } from "../actions";
import { Field } from "@/components/ui/field";
import { Input } from "@/components/ui/input";
import { Button } from "@/components/ui/button";
import { Select } from "@/components/ui/select";

type UserDto = {
  id: string;
  email: string;
  phone: string | null;
  firstName: string;
  lastName: string;
  middleName: string | null;
  position: string | null;
  role: "MANAGER" | "EMPLOYEE";
  status: string;
};

export function EmployeeEditForm({ user }: { user: UserDto }) {
  const [state, action, pending] = useActionState<EmployeeFormState, FormData>(
    updateEmployeeAction,
    undefined,
  );

  return (
    <form action={action} className="space-y-4">
      <input type="hidden" name="id" value={user.id} />

      <div className="grid grid-cols-2 gap-3">
        <Field label="Фамилия" error={state?.errors?.lastName?.[0]}>
          <Input name="lastName" defaultValue={user.lastName} required />
        </Field>
        <Field label="Имя" error={state?.errors?.firstName?.[0]}>
          <Input name="firstName" defaultValue={user.firstName} required />
        </Field>
      </div>
      <Field label="Отчество" error={state?.errors?.middleName?.[0]}>
        <Input name="middleName" defaultValue={user.middleName ?? ""} />
      </Field>
      <div className="grid grid-cols-2 gap-3">
        <Field label="Email" error={state?.errors?.email?.[0]}>
          <Input name="email" type="email" defaultValue={user.email} required />
        </Field>
        <Field label="Телефон" error={state?.errors?.phone?.[0]}>
          <Input name="phone" type="tel" defaultValue={user.phone ?? ""} />
        </Field>
      </div>
      <div className="grid grid-cols-2 gap-3">
        <Field label="Должность" error={state?.errors?.position?.[0]}>
          <Input name="position" defaultValue={user.position ?? ""} />
        </Field>
        <Field label="Роль" error={state?.errors?.role?.[0]}>
          <Select name="role" defaultValue={user.role}>
            <option value="EMPLOYEE">Сотрудник</option>
            <option value="MANAGER">Руководитель</option>
          </Select>
        </Field>
      </div>
      <Field label="Статус" error={state?.errors?.status?.[0]}>
        <Select name="status" defaultValue={user.status}>
          <option value="ACTIVE">Активен</option>
          <option value="SUSPENDED">Приостановлен</option>
          <option value="FIRED">Уволен</option>
        </Select>
      </Field>

      {state?.message && (
        <div className="rounded-2xl bg-red-50 border border-red-200 px-4 py-3 text-sm text-danger">
          {state.message}
        </div>
      )}

      <div className="flex justify-center pt-2">
        <Button type="submit" disabled={pending} size="lg">
          {pending ? "Сохраняем…" : "Сохранить"}
        </Button>
      </div>
    </form>
  );
}
