import Link from "next/link";
import { notFound } from "next/navigation";
import { ArrowLeft } from "lucide-react";
import { prisma } from "@/lib/prisma";
import { requireRole } from "@/lib/auth";
import { PageShell } from "@/components/ui/page-shell";
import { EmployeeEditForm } from "./edit-form";

export default async function EditEmployeePage(props: PageProps<"/employees/[id]">) {
  await requireRole("MANAGER");
  const { id } = await props.params;

  const user = await prisma.user.findUnique({ where: { id } });
  if (!user) notFound();

  const title = `${user.lastName} ${user.firstName} ${user.middleName ?? ""}`.trim();

  return (
    <div>
      <div className="px-6 md:px-10 pt-6">
        <Link
          href="/employees"
          className="inline-flex items-center gap-1.5 text-sm text-text-soft hover:text-foreground"
        >
          <ArrowLeft size={14} /> К списку
        </Link>
      </div>
      <PageShell title={title} subtitle="Редактирование данных сотрудника" titleAlign="center">
        <EmployeeEditForm
          user={{
            id: user.id,
            email: user.email,
            phone: user.phone,
            firstName: user.firstName,
            lastName: user.lastName,
            middleName: user.middleName,
            position: user.position,
            role: user.role as "MANAGER" | "EMPLOYEE",
            status: user.status,
          }}
        />
      </PageShell>
    </div>
  );
}
