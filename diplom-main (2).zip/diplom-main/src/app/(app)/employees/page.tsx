import { prisma } from "@/lib/prisma";
import { requireRole } from "@/lib/auth";
import { PageShell } from "@/components/ui/page-shell";
import { EmployeeList } from "./employee-list";

export default async function EmployeesPage() {
  const { user: currentUser } = await requireRole("MANAGER");

  const users = await prisma.user.findMany({
    orderBy: [{ lastName: "asc" }, { firstName: "asc" }],
  });

  const list = users.map((u) => ({
    id: u.id,
    firstName: u.firstName,
    lastName: u.lastName,
    middleName: u.middleName,
    position: u.position,
    email: u.email,
    phone: u.phone,
    hireDate: u.hireDate,
    role: u.role as "MANAGER" | "EMPLOYEE",
  }));

  return (
    <PageShell title="Мой отдел" subtitle="Список сотрудников подразделения">
      <EmployeeList employees={list} currentUserId={currentUser.id} />
    </PageShell>
  );
}
