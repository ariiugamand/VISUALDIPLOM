import Link from "next/link";
import { ArrowLeft } from "lucide-react";
import { requireRole } from "@/lib/auth";
import { PageShell } from "@/components/ui/page-shell";
import { EmployeeCreateForm } from "./create-form";

export default async function NewEmployeePage() {
  await requireRole("MANAGER");

  return (
    <div>
      <div className="px-6 md:px-10 pt-6">
        <Link
          href="/employees"
          className="inline-flex items-center gap-1.5 text-sm text-text-soft hover:text-foreground"
        >
          <ArrowLeft size={14} /> К списку
        </Link>
      </div>
      <PageShell title="Новый сотрудник" titleAlign="center">
        <EmployeeCreateForm />
      </PageShell>
    </div>
  );
}
