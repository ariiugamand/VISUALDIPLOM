"use client";

import { useActionState } from "react";
import { createEmployeeAction, type EmployeeFormState } from "../actions";
import { Field } from "@/components/ui/field";
import { Input } from "@/components/ui/input";
import { Button } from "@/components/ui/button";
import { Select } from "@/components/ui/select";

export function EmployeeCreateForm() {
  const [state, action, pending] = useActionState<EmployeeFormState, FormData>(
    createEmployeeAction,
    undefined,
  );

  return (
    <form action={action} className="space-y-4">
      <div className="grid grid-cols-2 gap-3">
        <Field label="Фамилия" error={state?.errors?.lastName?.[0]}>
          <Input name="lastName" required />
        </Field>
        <Field label="Имя" error={state?.errors?.firstName?.[0]}>
          <Input name="firstName" required />
        </Field>
      </div>
      <Field label="Отчество" error={state?.errors?.middleName?.[0]}>
        <Input name="middleName" />
      </Field>
      <div className="grid grid-cols-2 gap-3">
        <Field label="Email" error={state?.errors?.email?.[0]}>
          <Input name="email" type="email" required />
        </Field>
        <Field label="Телефон" error={state?.errors?.phone?.[0]}>
          <Input name="phone" type="tel" />
        </Field>
      </div>
      <div className="grid grid-cols-2 gap-3">
        <Field label="Должность" error={state?.errors?.position?.[0]}>
          <Input name="position" />
        </Field>
        <Field label="Роль" error={state?.errors?.role?.[0]}>
          <Select name="role" defaultValue="EMPLOYEE">
            <option value="EMPLOYEE">Сотрудник</option>
            <option value="MANAGER">Руководитель</option>
          </Select>
        </Field>
      </div>
      <Field label="Начальный пароль" error={state?.errors?.password?.[0]}>
        <Input name="password" type="text" required minLength={8} />
      </Field>

      {state?.message && (
        <div className="rounded-2xl bg-red-50 border border-red-200 px-4 py-3 text-sm text-danger">
          {state.message}
        </div>
      )}

      <div className="flex justify-center pt-2">
        <Button type="submit" disabled={pending} size="lg">
          {pending ? "Сохраняем…" : "Создать"}
        </Button>
      </div>
    </form>
  );
}
