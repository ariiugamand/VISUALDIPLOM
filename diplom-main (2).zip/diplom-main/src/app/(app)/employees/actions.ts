"use server";

import { revalidatePath } from "next/cache";
import { redirect } from "next/navigation";
import { prisma } from "@/lib/prisma";
import { requireRole } from "@/lib/auth";
import { hashPassword } from "@/lib/password";
import { EmployeeCreateSchema, EmployeeUpdateSchema } from "@/lib/validation";

export type EmployeeFormState =
  | {
      errors?: Record<string, string[] | undefined>;
      message?: string;
    }
  | undefined;

export async function createEmployeeAction(
  _prev: EmployeeFormState,
  formData: FormData,
): Promise<EmployeeFormState> {
  await requireRole("MANAGER");

  const parsed = EmployeeCreateSchema.safeParse({
    email: formData.get("email"),
    phone: formData.get("phone") ?? "",
    firstName: formData.get("firstName"),
    lastName: formData.get("lastName"),
    middleName: formData.get("middleName") ?? "",
    position: formData.get("position") ?? "",
    departmentId: formData.get("departmentId") ?? "",
    role: formData.get("role") ?? "EMPLOYEE",
    password: formData.get("password"),
  });

  if (!parsed.success) {
    return { errors: parsed.error.flatten().fieldErrors };
  }

  const data = parsed.data;
  const email = data.email.toLowerCase();

  const exists = await prisma.user.findFirst({
    where: { OR: [{ email }, ...(data.phone ? [{ phone: data.phone }] : [])] },
    select: { id: true },
  });
  if (exists) return { message: "Пользователь с таким email или телефоном уже существует" };

  const passwordHash = await hashPassword(data.password);
  await prisma.user.create({
    data: {
      email,
      phone: data.phone || null,
      firstName: data.firstName,
      lastName: data.lastName,
      middleName: data.middleName || null,
      position: data.position || null,
      departmentId: data.departmentId || null,
      role: data.role,
      passwordHash,
    },
  });

  revalidatePath("/employees");
  redirect("/employees");
}

export async function updateEmployeeAction(
  _prev: EmployeeFormState,
  formData: FormData,
): Promise<EmployeeFormState> {
  await requireRole("MANAGER");

  const parsed = EmployeeUpdateSchema.safeParse({
    id: formData.get("id"),
    email: formData.get("email"),
    phone: formData.get("phone") ?? "",
    firstName: formData.get("firstName"),
    lastName: formData.get("lastName"),
    middleName: formData.get("middleName") ?? "",
    position: formData.get("position") ?? "",
    departmentId: formData.get("departmentId") ?? "",
    role: formData.get("role"),
    status: formData.get("status") ?? "ACTIVE",
  });

  if (!parsed.success) {
    return { errors: parsed.error.flatten().fieldErrors };
  }

  const data = parsed.data;
  const email = data.email.toLowerCase();

  const conflict = await prisma.user.findFirst({
    where: {
      id: { not: data.id },
      OR: [{ email }, ...(data.phone ? [{ phone: data.phone }] : [])],
    },
    select: { id: true },
  });
  if (conflict) return { message: "Email или телефон уже заняты другим пользователем" };

  await prisma.user.update({
    where: { id: data.id },
    data: {
      email,
      phone: data.phone || null,
      firstName: data.firstName,
      lastName: data.lastName,
      middleName: data.middleName || null,
      position: data.position || null,
      departmentId: data.departmentId || null,
      role: data.role,
      status: data.status,
    },
  });

  revalidatePath("/employees");
  redirect("/employees");
}

export async function deleteEmployeeAction(formData: FormData): Promise<void> {
  const { user: current } = await requireRole("MANAGER");
  const id = formData.get("id");
  if (typeof id !== "string" || !id) return;
  if (id === current.id) return; // себя удалить нельзя

  await prisma.user.delete({ where: { id } });
  revalidatePath("/employees");
}
