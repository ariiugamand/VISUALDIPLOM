"use client";

import Link from "next/link";
import { useMemo, useState } from "react";
import { Search, MoreHorizontal, Calendar, Phone, Mail, Pencil, Trash2 } from "lucide-react";
import { useRouter } from "next/navigation";
import { Input } from "@/components/ui/input";
import { Select } from "@/components/ui/select";
import { Button } from "@/components/ui/button";
import { Modal } from "@/components/ui/modal";
import { Plus } from "lucide-react";
import { deleteEmployeeAction } from "./actions";

type EmployeeDto = {
  id: string;
  firstName: string;
  lastName: string;
  middleName: string | null;
  position: string | null;
  email: string;
  phone: string | null;
  hireDate: Date | null;
  role: "MANAGER" | "EMPLOYEE";
};

type Props = {
  employees: EmployeeDto[];
  currentUserId: string;
};

function formatTenure(hireDate: Date | null): string {
  if (!hireDate) return "—";
  const now = new Date();
  const years = now.getFullYear() - hireDate.getFullYear();
  const months = now.getMonth() - hireDate.getMonth();
  const totalMonths = years * 12 + months;
  if (totalMonths < 12) {
    return `${totalMonths} мес.`;
  }
  const y = Math.floor(totalMonths / 12);
  const m = totalMonths % 12;
  const yrLabel = y % 10 === 1 && y % 100 !== 11 ? "год" : y % 10 >= 2 && y % 10 <= 4 && (y % 100 < 10 || y % 100 >= 20) ? "года" : "лет";
  if (m === 0) return `${y} ${yrLabel}`;
  return `${y} ${yrLabel} ${m} мес.`;
}

export function EmployeeList({ employees, currentUserId }: Props) {
  const router = useRouter();
  const [query, setQuery] = useState("");
  const [order, setOrder] = useState<"asc" | "desc">("asc");
  const [activeId, setActiveId] = useState<string | null>(null);
  const [deletingId, setDeletingId] = useState<string | null>(null);

  const filtered = useMemo(() => {
    const q = query.trim().toLowerCase();
    const base = q
      ? employees.filter((e) =>
          `${e.lastName} ${e.firstName} ${e.middleName ?? ""}`.toLowerCase().includes(q),
        )
      : employees;
    const sorted = [...base].sort((a, b) =>
      `${a.lastName} ${a.firstName}`.localeCompare(`${b.lastName} ${b.firstName}`, "ru"),
    );
    return order === "asc" ? sorted : sorted.reverse();
  }, [employees, query, order]);

  const active = activeId ? employees.find((e) => e.id === activeId) ?? null : null;

  const handleDelete = async (id: string) => {
    if (!confirm("Удалить сотрудника? Действие необратимо.")) return;
    setDeletingId(id);
    const fd = new FormData();
    fd.append("id", id);
    await deleteEmployeeAction(fd);
    setActiveId(null);
    setDeletingId(null);
    router.refresh();
  };

  return (
    <>
      <div className="flex flex-col sm:flex-row gap-3 mb-5">
        <div className="flex-1">
          <Input
            placeholder="Поиск по ФИО"
            leadingIcon={<Search size={16} />}
            value={query}
            onChange={(e) => setQuery(e.target.value)}
          />
        </div>
        <div className="sm:w-32">
          <Select value={order} onChange={(e) => setOrder(e.target.value as "asc" | "desc")}>
            <option value="asc">А–Я</option>
            <option value="desc">Я–А</option>
          </Select>
        </div>
        <Link href="/employees/new" className="shrink-0">
          <Button className="w-full sm:w-auto">
            <Plus size={16} /> Добавить сотрудника
          </Button>
        </Link>
      </div>

      <div className="grid grid-cols-1 md:grid-cols-2 gap-x-3 gap-y-2">
        {filtered.map((u, index) => (
          <button
            key={u.id}
            type="button"
            onClick={() => setActiveId(u.id)}
            className="group flex items-center gap-3 px-3 py-3 rounded-2xl bg-surface border border-border-soft hover:shadow-chip transition text-left"
          >
            <span className="w-8 text-sm text-text-muted font-medium shrink-0">
              {String(index + 1).padStart(2, "0")}
            </span>
            <div className="flex-1 min-w-0">
              <div className="font-medium text-foreground truncate">
                {u.lastName} {u.firstName} {u.middleName ?? ""}
              </div>
            </div>
            <span className="w-8 h-8 flex items-center justify-center rounded-full text-text-soft group-hover:bg-muted transition">
              <MoreHorizontal size={16} />
            </span>
          </button>
        ))}
        {filtered.length === 0 && (
          <div className="col-span-full text-center text-text-soft py-10">
            {query ? "Ничего не найдено" : "Сотрудников пока нет"}
          </div>
        )}
      </div>

      <Modal open={active !== null} onClose={() => setActiveId(null)} maxWidth="max-w-md">
        {active && (
          <div className="p-6 md:p-7">
            <div className="text-center">
              <div className="text-xl md:text-2xl font-semibold text-foreground">
                {active.lastName} {active.firstName} {active.middleName ?? ""}
              </div>
              {active.hireDate && (
                <div className="mt-1.5 inline-flex items-center gap-1.5 text-sm text-text-soft">
                  <Calendar size={14} />
                  {active.hireDate.toLocaleDateString("ru-RU", {
                    day: "numeric",
                    month: "long",
                    year: "numeric",
                  })}
                </div>
              )}
            </div>
            <div className="h-px bg-border-soft my-5" />
            <dl className="space-y-3 text-sm">
              <div className="grid grid-cols-[130px_1fr] gap-4">
                <dt className="text-text-soft">Должность:</dt>
                <dd className="text-foreground">{active.position ?? "—"}</dd>
              </div>
              <div className="grid grid-cols-[130px_1fr] gap-4">
                <dt className="text-text-soft">Срок работы:</dt>
                <dd className="text-foreground">{formatTenure(active.hireDate)}</dd>
              </div>
              <div className="grid grid-cols-[130px_1fr] gap-4">
                <dt className="text-text-soft">Контакты:</dt>
                <dd className="text-foreground space-y-1.5">
                  {active.phone && (
                    <div className="flex items-center gap-2">
                      <Phone size={14} className="text-text-soft" />
                      <span>{active.phone}</span>
                    </div>
                  )}
                  <div className="flex items-center gap-2">
                    <Mail size={14} className="text-text-soft" />
                    <span>{active.email}</span>
                  </div>
                </dd>
              </div>
            </dl>
            <div className="h-px bg-border-soft my-5" />
            <div className="flex flex-col sm:flex-row gap-2 justify-center">
              {active.id !== currentUserId && (
                <Button
                  variant="secondary"
                  onClick={() => handleDelete(active.id)}
                  disabled={deletingId === active.id}
                >
                  <Trash2 size={15} />
                  {deletingId === active.id ? "Удаляем…" : "Удалить"}
                </Button>
              )}
              <Link href={`/employees/${active.id}`}>
                <Button className="w-full sm:w-auto">
                  <Pencil size={15} /> Редактировать
                </Button>
              </Link>
            </div>
          </div>
        )}
      </Modal>
    </>
  );
}
