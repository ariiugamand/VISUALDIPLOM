"use client";

import Link from "next/link";
import { useTransition } from "react";
import { useRouter } from "next/navigation";
import { Button } from "@/components/ui/button";
import { deleteEventAction } from "./actions";

export function EventRowActions({ id }: { id: string }) {
  const [pending, start] = useTransition();
  const router = useRouter();

  const onCancel = () => {
    if (!confirm("Отменить мероприятие? Оно будет удалено.")) return;
    const fd = new FormData();
    fd.append("id", id);
    start(async () => {
      await deleteEventAction(fd);
      router.refresh();
    });
  };

  return (
    <>
      <Button variant="secondary" size="sm" onClick={onCancel} disabled={pending}>
        {pending ? "…" : "Отменить"}
      </Button>
      <Link href={`/events/${id}/edit`}>
        <Button size="sm">Редактировать</Button>
      </Link>
    </>
  );
}
