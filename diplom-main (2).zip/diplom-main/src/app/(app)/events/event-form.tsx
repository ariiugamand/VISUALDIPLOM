"use client";

import { useActionState } from "react";
import { Calendar, Clock, CheckCircle } from "lucide-react";
import { Field } from "@/components/ui/field";
import { Input } from "@/components/ui/input";
import { Select } from "@/components/ui/select";
import { Textarea } from "@/components/ui/textarea";
import { Button } from "@/components/ui/button";
import { EVENT_IMPORTANCES } from "@/lib/events";
import type { EventFormState } from "./actions";

type Props = {
  action: (state: EventFormState, formData: FormData) => Promise<EventFormState>;
  submitLabel: string;
  initial?: {
    id?: string;
    title?: string;
    description?: string | null;
    date?: string;
    time?: string;
    importance?: string;
  };
};

export function EventForm({ action, submitLabel, initial }: Props) {
  const [state, formAction, pending] = useActionState<EventFormState, FormData>(
    action,
    undefined,
  );

  return (
    <form action={formAction} className="space-y-5 max-w-2xl mx-auto">
      {initial?.id && <input type="hidden" name="id" value={initial.id} />}

      <Field label="Название мероприятия" error={state?.errors?.title?.[0]}>
        <Input
          name="title"
          placeholder="Встреча с командой"
          required
          maxLength={200}
          defaultValue={initial?.title ?? ""}
          leadingIcon={<CheckCircle size={16} />}
          variant="rounded"
        />
      </Field>

      <div className="grid grid-cols-1 sm:grid-cols-[1fr_1fr] gap-3">
        <Field label="Дата" error={state?.errors?.date?.[0]}>
          <Input
            name="date"
            type="date"
            required
            defaultValue={initial?.date ?? ""}
            leadingIcon={<Calendar size={16} />}
            variant="rounded"
          />
        </Field>
        <Field label="Время" error={state?.errors?.time?.[0]}>
          <Input
            name="time"
            type="time"
            required
            defaultValue={initial?.time ?? ""}
            leadingIcon={<Clock size={16} />}
            variant="rounded"
          />
        </Field>
      </div>

      <Field label="Описание" error={state?.errors?.description?.[0]}>
        <Textarea
          name="description"
          placeholder="Добавьте описание…"
          maxLength={4000}
          defaultValue={initial?.description ?? ""}
        />
      </Field>

      <Field label="Тип события" error={state?.errors?.importance?.[0]}>
        <Select
          name="importance"
          defaultValue={initial?.importance ?? EVENT_IMPORTANCES[0].value}
          variant="rounded"
        >
          {EVENT_IMPORTANCES.map((e) => (
            <option key={e.value} value={e.value}>
              {e.label} · важность {e.severity.toLowerCase()}
            </option>
          ))}
        </Select>
      </Field>

      {state?.message && (
        <div className="rounded-2xl bg-red-50 border border-red-200 px-4 py-3 text-sm text-danger">
          {state.message}
        </div>
      )}

      <div className="flex justify-center pt-2">
        <Button type="submit" disabled={pending} size="lg" className="min-w-[160px]">
          {pending ? "Сохраняем…" : submitLabel}
        </Button>
      </div>
    </form>
  );
}
