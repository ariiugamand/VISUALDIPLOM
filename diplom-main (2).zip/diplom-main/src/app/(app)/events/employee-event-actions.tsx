"use client";

import { useTransition } from "react";
import { useRouter } from "next/navigation";
import { CheckCircle2, UserPlus } from "lucide-react";
import { Button } from "@/components/ui/button";
import { acknowledgeEventAction, registerEventAction } from "./actions";
import { isImportant } from "@/lib/events";

type Props = {
  id: string;
  importance: string;
  acknowledged: boolean;
  registered: boolean;
};

export function EmployeeEventActions({ id, importance, acknowledged, registered }: Props) {
  const router = useRouter();
  const [pending, start] = useTransition();

  const onAck = () => {
    const fd = new FormData();
    fd.append("id", id);
    start(async () => {
      await acknowledgeEventAction(fd);
      router.refresh();
    });
  };

  const onRegister = () => {
    const fd = new FormData();
    fd.append("id", id);
    start(async () => {
      await registerEventAction(fd);
      router.refresh();
    });
  };

  if (isImportant(importance)) {
    if (acknowledged) {
      return (
        <span className="inline-flex items-center gap-1.5 text-sm text-brand-dark font-medium">
          <CheckCircle2 size={16} /> Прочитано
        </span>
      );
    }
    return (
      <Button size="sm" onClick={onAck} disabled={pending}>
        <CheckCircle2 size={14} /> Ознакомиться
      </Button>
    );
  }

  if (registered) {
    return (
      <span className="inline-flex items-center gap-1.5 text-sm text-info font-medium">
        <UserPlus size={16} /> Записан
      </span>
    );
  }
  return (
    <Button size="sm" variant="soft" onClick={onRegister} disabled={pending}>
      <UserPlus size={14} /> Записаться
    </Button>
  );
}
