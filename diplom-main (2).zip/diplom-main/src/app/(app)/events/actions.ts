"use server";

import { z } from "zod";
import { revalidatePath } from "next/cache";
import { redirect } from "next/navigation";
import { prisma } from "@/lib/prisma";
import { requireAuth, requireRole } from "@/lib/auth";

const schema = z.object({
  title: z.string().min(3, { error: "Введите название" }).max(200).trim(),
  description: z.string().max(4000).trim().optional().or(z.literal("")),
  date: z.string().min(1, { error: "Укажите дату" }),
  time: z.string().min(1, { error: "Укажите время" }),
  importance: z.enum(["IMPORTANT", "ACTIVITY", "CORPORATE"]),
});

export type EventFormState =
  | { errors?: Record<string, string[] | undefined>; message?: string }
  | undefined;

function combineDateTime(date: string, time: string): Date {
  return new Date(`${date}T${time}`);
}

export async function createEventAction(
  _prev: EventFormState,
  formData: FormData,
): Promise<EventFormState> {
  const { user } = await requireRole("MANAGER");

  const parsed = schema.safeParse({
    title: formData.get("title"),
    description: formData.get("description") ?? "",
    date: formData.get("date"),
    time: formData.get("time"),
    importance: formData.get("importance"),
  });

  if (!parsed.success) return { errors: parsed.error.flatten().fieldErrors };

  const startsAt = combineDateTime(parsed.data.date, parsed.data.time);
  if (Number.isNaN(startsAt.getTime())) {
    return { message: "Некорректная дата или время" };
  }

  await prisma.event.create({
    data: {
      title: parsed.data.title,
      description: parsed.data.description || null,
      startsAt,
      importance: parsed.data.importance,
      createdById: user.id,
    },
  });

  revalidatePath("/events");
  redirect("/events");
}

export async function updateEventAction(
  _prev: EventFormState,
  formData: FormData,
): Promise<EventFormState> {
  await requireRole("MANAGER");
  const id = formData.get("id");
  if (typeof id !== "string") return { message: "Некорректный id" };

  const parsed = schema.safeParse({
    title: formData.get("title"),
    description: formData.get("description") ?? "",
    date: formData.get("date"),
    time: formData.get("time"),
    importance: formData.get("importance"),
  });
  if (!parsed.success) return { errors: parsed.error.flatten().fieldErrors };

  const startsAt = combineDateTime(parsed.data.date, parsed.data.time);
  if (Number.isNaN(startsAt.getTime())) {
    return { message: "Некорректная дата или время" };
  }

  await prisma.event.update({
    where: { id },
    data: {
      title: parsed.data.title,
      description: parsed.data.description || null,
      startsAt,
      importance: parsed.data.importance,
    },
  });

  revalidatePath("/events");
  revalidatePath(`/events/${id}`);
  redirect("/events");
}

export async function deleteEventAction(formData: FormData): Promise<void> {
  await requireRole("MANAGER");
  const id = formData.get("id");
  if (typeof id !== "string") return;
  await prisma.event.delete({ where: { id } });
  revalidatePath("/events");
}

export async function acknowledgeEventAction(formData: FormData): Promise<void> {
  const { user } = await requireAuth();
  const eventId = formData.get("id");
  if (typeof eventId !== "string") return;
  await prisma.eventRecipient.upsert({
    where: { eventId_userId: { eventId, userId: user.id } },
    update: { acknowledged: true, acknowledgedAt: new Date() },
    create: {
      eventId,
      userId: user.id,
      acknowledged: true,
      acknowledgedAt: new Date(),
    },
  });
  revalidatePath("/events");
}

export async function registerEventAction(formData: FormData): Promise<void> {
  const { user } = await requireAuth();
  const eventId = formData.get("id");
  if (typeof eventId !== "string") return;
  await prisma.eventRecipient.upsert({
    where: { eventId_userId: { eventId, userId: user.id } },
    update: { registered: true, registeredAt: new Date() },
    create: {
      eventId,
      userId: user.id,
      registered: true,
      registeredAt: new Date(),
    },
  });
  revalidatePath("/events");
}
