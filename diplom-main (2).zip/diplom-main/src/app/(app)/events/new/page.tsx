import Link from "next/link";
import { ArrowLeft } from "lucide-react";
import { requireRole } from "@/lib/auth";
import { PageShell } from "@/components/ui/page-shell";
import { EventForm } from "../event-form";
import { createEventAction } from "../actions";

export default async function NewEventPage() {
  await requireRole("MANAGER");

  return (
    <div>
      <div className="px-5 md:px-10 pt-6">
        <Link
          href="/events"
          className="inline-flex items-center gap-1.5 text-sm text-text-soft hover:text-foreground"
        >
          <ArrowLeft size={14} /> К мероприятиям
        </Link>
      </div>
      <PageShell
        title="Создание мероприятия"
        subtitle="Заполните информацию ниже"
        titleAlign="center"
      >
        <EventForm action={createEventAction} submitLabel="Создать" />
      </PageShell>
    </div>
  );
}
