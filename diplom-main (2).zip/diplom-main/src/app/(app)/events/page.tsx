import Link from "next/link";
import { Plus } from "lucide-react";
import { prisma } from "@/lib/prisma";
import { requireAuth } from "@/lib/auth";
import { PageShell } from "@/components/ui/page-shell";
import { Button } from "@/components/ui/button";
import { EventsList } from "./events-list";

export default async function EventsPage() {
  const { user, session } = await requireAuth();
  const isManager = session.role === "MANAGER";

  const mapped = isManager
    ? (
        await prisma.event.findMany({
          orderBy: [{ startsAt: "asc" }],
          include: {
            recipients: {
              where: { OR: [{ acknowledged: true }, { registered: true }] },
              include: {
                user: { select: { id: true, firstName: true, lastName: true } },
              },
            },
          },
        })
      ).map((e) => ({
        id: e.id,
        title: e.title,
        description: e.description,
        startsAt: e.startsAt.toISOString(),
        importance: e.importance,
        acknowledged: false,
        registered: false,
        acknowledgedBy: e.recipients
          .filter((r) => r.acknowledged)
          .map((r) => ({
            id: r.user.id,
            name: `${r.user.lastName} ${r.user.firstName}`,
          })),
        registeredBy: e.recipients
          .filter((r) => r.registered)
          .map((r) => ({
            id: r.user.id,
            name: `${r.user.lastName} ${r.user.firstName}`,
          })),
      }))
    : (
        await prisma.event.findMany({
          orderBy: [{ startsAt: "asc" }],
          include: {
            recipients: {
              where: { userId: user.id },
              select: { acknowledged: true, registered: true },
            },
          },
        })
      ).map((e) => {
        const r = e.recipients[0];
        return {
          id: e.id,
          title: e.title,
          description: e.description,
          startsAt: e.startsAt.toISOString(),
          importance: e.importance,
          acknowledged: r?.acknowledged ?? false,
          registered: r?.registered ?? false,
          acknowledgedBy: undefined,
          registeredBy: undefined,
        };
      });

  return (
    <PageShell
      title="Мероприятия"
      titleAlign="center"
      actions={
        isManager ? (
          <Link href="/events/new">
            <Button>
              <Plus size={16} /> Создать событие
            </Button>
          </Link>
        ) : undefined
      }
    >
      {mapped.length === 0 ? (
        <div className="text-center py-14 text-text-soft">Мероприятий пока нет</div>
      ) : (
        <EventsList events={mapped} isManager={isManager} />
      )}
    </PageShell>
  );
}
