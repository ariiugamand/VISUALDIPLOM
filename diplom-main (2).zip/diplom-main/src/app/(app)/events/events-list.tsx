"use client";

import { useMemo, useState } from "react";
import { AlertCircle, Calendar, CheckCircle2, Filter, Search, UserPlus } from "lucide-react";
import { Modal } from "@/components/ui/modal";
import { EVENT_IMPORTANCES, importanceLabel, isImportant, severityLabel } from "@/lib/events";
import { EmployeeEventActions } from "./employee-event-actions";
import { EventRowActions } from "./event-row-actions";

type RecipientLite = { id: string; name: string };

type EventDto = {
  id: string;
  title: string;
  description: string | null;
  startsAt: string;
  importance: string;
  acknowledged?: boolean;
  registered?: boolean;
  acknowledgedBy?: RecipientLite[];
  registeredBy?: RecipientLite[];
};

type Props = {
  events: EventDto[];
  isManager: boolean;
};

function fmtDateTime(iso: string): string {
  const d = new Date(iso);
  return `${d.toLocaleDateString("ru-RU", {
    day: "2-digit",
    month: "2-digit",
    year: "2-digit",
  })}, ${d.toLocaleTimeString("ru-RU", {
    hour: "2-digit",
    minute: "2-digit",
  })}`;
}

function fmtFullDate(iso: string): string {
  return new Date(iso).toLocaleDateString("ru-RU", {
    day: "numeric",
    month: "long",
    year: "numeric",
  });
}

function fmtTime(iso: string): string {
  return new Date(iso).toLocaleTimeString("ru-RU", {
    hour: "2-digit",
    minute: "2-digit",
  });
}

export function EventsList({ events, isManager }: Props) {
  const [query, setQuery] = useState("");
  const [importanceFilter, setImportanceFilter] = useState<string>("ALL");
  const [filterOpen, setFilterOpen] = useState(false);
  const [activeId, setActiveId] = useState<string | null>(null);

  const filtered = useMemo(() => {
    const q = query.trim().toLowerCase();
    return events.filter((e) => {
      if (importanceFilter !== "ALL" && e.importance !== importanceFilter) return false;
      if (!q) return true;
      return (
        e.title.toLowerCase().includes(q) ||
        (e.description ?? "").toLowerCase().includes(q)
      );
    });
  }, [events, query, importanceFilter]);

  const active = activeId ? events.find((e) => e.id === activeId) ?? null : null;

  return (
    <div className="space-y-4">
      <div className="flex items-center gap-2">
        <div className="relative">
          <button
            type="button"
            onClick={() => setFilterOpen((v) => !v)}
            className="w-10 h-10 flex items-center justify-center rounded-full border border-border-soft bg-surface text-text-soft hover:bg-muted transition relative"
            aria-label="Фильтр"
          >
            <Filter size={16} />
            {importanceFilter !== "ALL" && (
              <span className="absolute top-1.5 right-1.5 w-2 h-2 rounded-full bg-brand" />
            )}
          </button>
          {filterOpen && (
            <>
              <div
                className="fixed inset-0 z-10"
                onClick={() => setFilterOpen(false)}
                aria-hidden
              />
              <div className="absolute left-0 top-11 z-20 w-56 rounded-xl border border-border-soft bg-surface shadow-card p-1.5">
                <FilterItem
                  active={importanceFilter === "ALL"}
                  onClick={() => {
                    setImportanceFilter("ALL");
                    setFilterOpen(false);
                  }}
                >
                  Все события
                </FilterItem>
                {EVENT_IMPORTANCES.map((imp) => (
                  <FilterItem
                    key={imp.value}
                    active={importanceFilter === imp.value}
                    onClick={() => {
                      setImportanceFilter(imp.value);
                      setFilterOpen(false);
                    }}
                  >
                    {imp.label}
                  </FilterItem>
                ))}
              </div>
            </>
          )}
        </div>
        <div className="flex-1 relative">
          <Search
            size={16}
            className="absolute left-3.5 top-1/2 -translate-y-1/2 text-text-muted pointer-events-none"
          />
          <input
            type="text"
            value={query}
            onChange={(e) => setQuery(e.target.value)}
            placeholder="Поиск"
            className="w-full h-10 pl-10 pr-3 rounded-full border border-border-soft bg-surface text-sm placeholder:text-placeholder focus:outline-none focus:border-brand/60 transition"
          />
        </div>
      </div>

      {filtered.length === 0 ? (
        <div className="text-center py-14 text-text-soft">Ничего не найдено</div>
      ) : (
        <div className="space-y-3 md:space-y-0 md:divide-y md:divide-border-soft">
          {filtered.map((e) => (
            <article
              key={e.id}
              className="flex flex-col md:flex-row md:items-center gap-3 md:gap-4 md:py-5 md:first:pt-0 md:last:pb-0 rounded-2xl md:rounded-none bg-surface md:bg-transparent border md:border-none border-border-soft p-4 md:p-0 cursor-pointer hover:bg-muted/40 md:hover:bg-muted/40 transition"
              onClick={() => setActiveId(e.id)}
            >
              <div className="flex items-start gap-3 flex-1 min-w-0">
                <Calendar size={22} className="text-text-soft mt-1 shrink-0 hidden md:block" />
                <div className="flex-1 min-w-0">
                  <div className="text-base md:text-lg font-semibold text-foreground">
                    {e.title}
                  </div>
                  <div className="text-sm text-text-soft mt-0.5">{fmtDateTime(e.startsAt)}</div>
                  {e.description && (
                    <p className="text-sm text-text-soft mt-1 line-clamp-1">{e.description}</p>
                  )}
                  <div className="mt-2 flex flex-wrap items-center gap-2">
                    {!isManager && e.acknowledged && (
                      <span className="inline-flex items-center gap-1 text-xs text-brand-dark">
                        <CheckCircle2 size={12} /> Ознакомлен
                      </span>
                    )}
                    {!isManager && e.registered && (
                      <span className="inline-flex items-center gap-1 text-xs text-info">
                        <UserPlus size={12} /> Вы записаны
                      </span>
                    )}
                    {!isManager &&
                      isImportant(e.importance) &&
                      !e.acknowledged && (
                        <span className="text-xs text-danger">
                          *необходимо отметить прочтение
                        </span>
                      )}
                    <ImportanceBadge importance={e.importance} />
                  </div>
                </div>
              </div>
              <div
                className="flex items-center gap-2 md:shrink-0 justify-end"
                onClick={(ev) => ev.stopPropagation()}
              >
                {isManager ? (
                  <EventRowActions id={e.id} />
                ) : (
                  <EmployeeEventActions
                    id={e.id}
                    importance={e.importance}
                    acknowledged={e.acknowledged ?? false}
                    registered={e.registered ?? false}
                  />
                )}
              </div>
            </article>
          ))}
        </div>
      )}

      <Modal open={activeId !== null} onClose={() => setActiveId(null)} maxWidth="max-w-md">
        {active && (
          <div className="p-6">
            <div className="mb-4">
              <ImportanceBadge importance={active.importance} />
            </div>
            <div className="space-y-2 text-sm">
              <div className="flex gap-2">
                <span className="text-text-soft w-20 shrink-0">Событие:</span>
                <span className="text-foreground font-medium flex-1">{active.title}</span>
              </div>
              <div className="flex gap-2">
                <span className="text-text-soft w-20 shrink-0">Дата:</span>
                <span className="text-foreground flex-1">{fmtFullDate(active.startsAt)}</span>
              </div>
              <div className="flex gap-2">
                <span className="text-text-soft w-20 shrink-0">Время:</span>
                <span className="text-foreground flex-1">{fmtTime(active.startsAt)}</span>
              </div>
            </div>
            {active.description && (
              <div className="mt-4 rounded-xl border border-border-soft bg-muted/40 px-4 py-3 text-sm text-foreground whitespace-pre-wrap">
                {active.description}
              </div>
            )}
            {!isManager && isImportant(active.importance) && !active.acknowledged && (
              <div className="mt-3 text-xs text-danger text-center">
                *для данного события необходимо отметить прочтение
              </div>
            )}
            {!isManager && (
              <div className="mt-5 flex justify-center">
                <EmployeeEventActions
                  id={active.id}
                  importance={active.importance}
                  acknowledged={active.acknowledged ?? false}
                  registered={active.registered ?? false}
                />
              </div>
            )}
            {isManager && (
              <RecipientsBlock
                acknowledged={active.acknowledgedBy ?? []}
                registered={active.registeredBy ?? []}
                isImportantEvent={isImportant(active.importance)}
              />
            )}
          </div>
        )}
      </Modal>
    </div>
  );
}

function FilterItem({
  active,
  onClick,
  children,
}: {
  active: boolean;
  onClick: () => void;
  children: React.ReactNode;
}) {
  return (
    <button
      type="button"
      onClick={onClick}
      className={`w-full text-left px-3 py-2 rounded-lg text-sm transition ${
        active ? "bg-accent-soft text-brand-dark font-medium" : "text-foreground hover:bg-muted"
      }`}
    >
      {children}
    </button>
  );
}

function ImportanceBadge({ importance }: { importance: string }) {
  if (isImportant(importance)) {
    return (
      <span className="inline-flex items-center gap-1.5 px-2.5 py-1 rounded-md bg-danger-soft/30 border border-danger-soft/50 text-danger text-xs font-medium shrink-0">
        <AlertCircle size={12} />
        Важно! · важность {severityLabel(importance).toLowerCase()}
      </span>
    );
  }
  return (
    <span className="inline-flex items-center gap-1.5 px-2.5 py-1 rounded-md bg-accent-soft text-brand-dark text-xs font-medium shrink-0">
      {importanceLabel(importance)} · важность {severityLabel(importance).toLowerCase()}
    </span>
  );
}

function RecipientsBlock({
  acknowledged,
  registered,
  isImportantEvent,
}: {
  acknowledged: RecipientLite[];
  registered: RecipientLite[];
  isImportantEvent: boolean;
}) {
  const total = acknowledged.length + registered.length;
  if (total === 0) {
    return (
      <div className="mt-5 pt-4 border-t border-border-soft text-xs text-text-soft text-center">
        Сотрудники пока не отреагировали
      </div>
    );
  }
  return (
    <div className="mt-5 pt-4 border-t border-border-soft space-y-3">
      {isImportantEvent ? (
        <NameList
          icon={CheckCircle2}
          iconClass="text-brand-dark"
          title="Прочитали"
          items={acknowledged}
        />
      ) : (
        <NameList
          icon={UserPlus}
          iconClass="text-info"
          title="Записались"
          items={registered}
        />
      )}
    </div>
  );
}

function NameList({
  icon: Icon,
  iconClass,
  title,
  items,
}: {
  icon: typeof CheckCircle2;
  iconClass: string;
  title: string;
  items: RecipientLite[];
}) {
  return (
    <div>
      <div className="flex items-center gap-1.5 mb-2">
        <Icon size={14} className={iconClass} />
        <span className="text-xs uppercase tracking-wide text-text-muted font-medium">
          {title} ({items.length})
        </span>
      </div>
      {items.length === 0 ? (
        <div className="text-xs text-text-soft pl-5">Никто</div>
      ) : (
        <ul className="space-y-1 pl-5 text-sm text-foreground">
          {items.map((u) => (
            <li key={u.id}>{u.name}</li>
          ))}
        </ul>
      )}
    </div>
  );
}
