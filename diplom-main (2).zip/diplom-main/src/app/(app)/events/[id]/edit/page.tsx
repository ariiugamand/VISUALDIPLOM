import Link from "next/link";
import { notFound } from "next/navigation";
import { ArrowLeft } from "lucide-react";
import { prisma } from "@/lib/prisma";
import { requireRole } from "@/lib/auth";
import { PageShell } from "@/components/ui/page-shell";
import { EventForm } from "../../event-form";
import { updateEventAction } from "../../actions";

export default async function EditEventPage(props: PageProps<"/events/[id]/edit">) {
  await requireRole("MANAGER");
  const { id } = await props.params;

  const event = await prisma.event.findUnique({ where: { id } });
  if (!event) notFound();

  const date = event.startsAt.toISOString().slice(0, 10);
  const time = event.startsAt.toTimeString().slice(0, 5);

  return (
    <div>
      <div className="px-5 md:px-10 pt-6">
        <Link
          href="/events"
          className="inline-flex items-center gap-1.5 text-sm text-text-soft hover:text-foreground"
        >
          <ArrowLeft size={14} /> К мероприятиям
        </Link>
      </div>
      <PageShell title="Редактирование мероприятия" titleAlign="center">
        <EventForm
          action={updateEventAction}
          submitLabel="Сохранить"
          initial={{
            id: event.id,
            title: event.title,
            description: event.description,
            date,
            time,
            importance: event.importance,
          }}
        />
      </PageShell>
    </div>
  );
}
