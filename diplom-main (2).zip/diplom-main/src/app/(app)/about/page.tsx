import { PageShell } from "@/components/ui/page-shell";
import { BrandLogo } from "@/components/brand/logo";
import { requireAuth } from "@/lib/auth";

export default async function AboutPage() {
  await requireAuth();
  return (
    <PageShell title="О приложении" titleAlign="center">
      <div className="max-w-2xl mx-auto space-y-6">
        <div className="flex flex-col items-center gap-3 py-4">
          <BrandLogo className="scale-150" />
          <div className="text-center">
            <div className="text-xl font-semibold text-foreground">Кадровая система</div>
            <div className="text-sm text-text-soft mt-1">Версия 1.0.0</div>
          </div>
        </div>

        <div className="rounded-xl bg-surface border border-border-soft p-5 text-sm">
          <p className="text-foreground leading-relaxed">
            Корпоративный портал для управления сотрудниками, рабочим графиком,
            заявлениями, задачами, мероприятиями, отчётами, шаблонами
            документов и базой знаний.
          </p>
        </div>
      </div>
    </PageShell>
  );
}
