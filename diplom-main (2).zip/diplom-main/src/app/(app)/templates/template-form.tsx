"use client";

import { useActionState, useRef, useState } from "react";
import { FileText, Paperclip, X } from "lucide-react";
import { Field } from "@/components/ui/field";
import { Input } from "@/components/ui/input";
import { Select } from "@/components/ui/select";
import { Textarea } from "@/components/ui/textarea";
import { Button } from "@/components/ui/button";
import { TEMPLATE_TYPES } from "@/lib/templates";
import type { TemplateFormState } from "./actions";

const MAX_PDF_SIZE = 15 * 1024 * 1024;

function fmtSize(bytes: number): string {
  if (bytes < 1024) return `${bytes} Б`;
  if (bytes < 1024 * 1024) return `${(bytes / 1024).toFixed(0)} КБ`;
  return `${(bytes / (1024 * 1024)).toFixed(1)} МБ`;
}

type Props = {
  action: (state: TemplateFormState, formData: FormData) => Promise<TemplateFormState>;
  submitLabel: string;
  initial?: {
    id?: string;
    name?: string;
    type?: string;
    content?: string;
    pdfFilename?: string | null;
    pdfSize?: number | null;
  };
};

export function TemplateForm({ action, submitLabel, initial }: Props) {
  const [state, formAction, pending] = useActionState<TemplateFormState, FormData>(
    action,
    undefined,
  );

  const [pdfFile, setPdfFile] = useState<File | null>(null);
  const [pdfError, setPdfError] = useState<string | null>(null);
  // есть старый
  const [keepExisting, setKeepExisting] = useState<boolean>(
    !!initial?.pdfFilename,
  );
  const fileInputRef = useRef<HTMLInputElement>(null);

  const onPick = (files: FileList | null) => {
    if (!files || files.length === 0) return;
    const f = files[0];
    const isPdf = f.type === "application/pdf" || f.name.toLowerCase().endsWith(".pdf");
    if (!isPdf) {
      setPdfError("Можно прикреплять только PDF-файлы");
      return;
    }
    if (f.size > MAX_PDF_SIZE) {
      setPdfError("Файл больше 15 МБ");
      return;
    }
    setPdfError(null);
    setPdfFile(f);
    setKeepExisting(false);
  };

  const onRemoveNew = () => {
    setPdfFile(null);
    if (fileInputRef.current) fileInputRef.current.value = "";
  };

  const onRemoveExisting = () => {
    setKeepExisting(false);
  };

  const onSubmit = (e: React.FormEvent<HTMLFormElement>) => {
    if (fileInputRef.current) {
      const dt = new DataTransfer();
      if (pdfFile) dt.items.add(pdfFile);
      fileInputRef.current.files = dt.files;
    }
    void e;
  };

  const showExisting = !!initial?.pdfFilename && keepExisting && !pdfFile;

  return (
    <form
      action={formAction}
      onSubmit={onSubmit}
      className="space-y-4 max-w-3xl mx-auto"
    >
      {initial?.id && <input type="hidden" name="id" value={initial.id} />}
      {/* флаг удаления */}
      {initial?.pdfFilename && !keepExisting && !pdfFile && (
        <input type="hidden" name="pdfRemove" value="1" />
      )}

      <Field label="Название шаблона" error={state?.errors?.name?.[0]}>
        <Input name="name" required maxLength={200} defaultValue={initial?.name ?? ""} />
      </Field>

      <Field label="Тип" error={state?.errors?.type?.[0]}>
        <Select name="type" defaultValue={initial?.type ?? TEMPLATE_TYPES[0]}>
          {TEMPLATE_TYPES.map((t) => (
            <option key={t} value={t}>
              {t}
            </option>
          ))}
        </Select>
      </Field>

      {/* PDF */}
      <div>
        <div className="flex items-center justify-between mb-2">
          <span className="text-sm font-medium text-text-soft">
            PDF-файл шаблона{" "}
            <span className="text-xs text-text-muted font-normal">
              (до 15 МБ, необязательно)
            </span>
          </span>
          <Button
            type="button"
            variant="soft"
            size="sm"
            onClick={() => fileInputRef.current?.click()}
          >
            <Paperclip size={14} />
            {showExisting || pdfFile ? "Заменить PDF" : "Прикрепить PDF"}
          </Button>
        </div>
        <input
          ref={fileInputRef}
          type="file"
          name="pdf"
          accept="application/pdf,.pdf"
          className="hidden"
          onChange={(e) => onPick(e.target.files)}
        />

        {pdfFile && (
          <div className="flex items-center gap-2 px-3 py-2 rounded-xl bg-accent-soft/40 border border-accent-soft text-sm">
            <FileText size={14} className="text-brand-dark shrink-0" />
            <span className="flex-1 min-w-0 truncate text-brand-dark font-medium">
              {pdfFile.name}
            </span>
            <span className="text-xs text-brand-dark/70">{fmtSize(pdfFile.size)}</span>
            <button
              type="button"
              onClick={onRemoveNew}
              className="w-6 h-6 flex items-center justify-center rounded-full hover:bg-border hover:text-danger transition"
              aria-label="Убрать"
            >
              <X size={14} />
            </button>
          </div>
        )}

        {showExisting && (
          <div className="flex items-center gap-2 px-3 py-2 rounded-xl bg-muted/60 border border-border-soft text-sm">
            <FileText size={14} className="text-text-soft shrink-0" />
            <span className="flex-1 min-w-0 truncate text-foreground">
              {initial?.pdfFilename}
            </span>
            {initial?.pdfSize != null && (
              <span className="text-xs text-text-muted">
                {fmtSize(initial.pdfSize)}
              </span>
            )}
            <button
              type="button"
              onClick={onRemoveExisting}
              className="w-6 h-6 flex items-center justify-center rounded-full text-text-soft hover:bg-border hover:text-danger transition"
              aria-label="Убрать PDF"
              title="Убрать PDF"
            >
              <X size={14} />
            </button>
          </div>
        )}

        {!pdfFile && !showExisting && (
          <div className="text-xs text-text-muted px-1">
            PDF не прикреплён — будет использоваться текст ниже
          </div>
        )}

        {pdfError && (
          <div className="text-xs text-danger mt-1.5 pl-1">{pdfError}</div>
        )}
      </div>

      <Field
        label="Текст шаблона"
        hint="Можно оставить пустым, если прикреплён PDF"
        error={state?.errors?.content?.[0]}
      >
        <Textarea
          name="content"
          defaultValue={initial?.content ?? ""}
          maxLength={20000}
          className="min-h-[240px]"
        />
      </Field>

      {state?.message && (
        <div className="rounded-xl bg-red-50 border border-red-200 px-4 py-3 text-sm text-danger">
          {state.message}
        </div>
      )}

      <div className="flex justify-center pt-2">
        <Button type="submit" disabled={pending} size="lg">
          {pending ? "Сохраняем…" : submitLabel}
        </Button>
      </div>
    </form>
  );
}
