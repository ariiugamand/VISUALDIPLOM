import { prisma } from "@/lib/prisma";
import { requireAuth } from "@/lib/auth";
import { PageShell } from "@/components/ui/page-shell";
import { TemplatesClient } from "./templates-client";

export default async function TemplatesPage() {
  const { session } = await requireAuth();
  const isManager = session.role === "MANAGER";

  const templates = await prisma.documentTemplate.findMany({
    include: {
      author: { select: { firstName: true, lastName: true } },
      _count: { select: { filled: true } },
    },
    orderBy: [{ updatedAt: "desc" }],
  });

  const items = templates.map((t) => ({
    id: t.id,
    name: t.name,
    type: t.type,
    content: t.content,
    updatedAt: t.updatedAt.toISOString(),
    usageCount: t._count.filled,
    author: t.author,
    hasPdf: !!t.pdfUrl,
  }));

  return (
    <PageShell
      title="Шаблоны документов"
      subtitle={
        isManager
          ? "Управляйте шаблонами и создавайте документы быстро"
          : "Заполнение документов по шаблонам"
      }
    >
      <TemplatesClient templates={items} isManager={isManager} />
    </PageShell>
  );
}
