"use client";

import { useMemo, useRef, useState, useTransition } from "react";
import Link from "next/link";
import { useRouter } from "next/navigation";
import {
  Copy,
  Download,
  Eye,
  FileText,
  Files,
  Pencil,
  Plus,
  Search,
  Trash2,
  Upload,
} from "lucide-react";
import { Button } from "@/components/ui/button";
import { TEMPLATE_TYPES } from "@/lib/templates";
import {
  deleteTemplateAction,
  duplicateTemplateAction,
  importTemplateAction,
} from "./actions";

type TemplateItem = {
  id: string;
  name: string;
  type: string;
  content: string;
  updatedAt: string;
  usageCount: number;
  author: { firstName: string; lastName: string };
  hasPdf: boolean;
};

type Props = {
  templates: TemplateItem[];
  isManager: boolean;
};

function plural(n: number, forms: [string, string, string]): string {
  const abs = Math.abs(n) % 100;
  const n1 = abs % 10;
  if (abs > 10 && abs < 20) return forms[2];
  if (n1 > 1 && n1 < 5) return forms[1];
  if (n1 === 1) return forms[0];
  return forms[2];
}

function downloadText(filename: string, text: string) {
  const blob = new Blob([text], { type: "text/plain;charset=utf-8" });
  const url = URL.createObjectURL(blob);
  const a = document.createElement("a");
  a.href = url;
  a.download = `${filename}.txt`;
  document.body.appendChild(a);
  a.click();
  document.body.removeChild(a);
  URL.revokeObjectURL(url);
}

function downloadTemplate(t: TemplateItem) {
  if (t.hasPdf) {
    // скачать
    const a = document.createElement("a");
    a.href = `/api/templates/${t.id}/pdf?download=1`;
    document.body.appendChild(a);
    a.click();
    document.body.removeChild(a);
  } else {
    downloadText(t.name, t.content);
  }
}

export function TemplatesClient({ templates, isManager }: Props) {
  const router = useRouter();
  const [pending, start] = useTransition();
  const [query, setQuery] = useState("");
  const [typeFilter, setTypeFilter] = useState<string>("ALL");
  const fileInputRef = useRef<HTMLInputElement>(null);
  const [importError, setImportError] = useState<string | null>(null);
  const [importing, setImporting] = useState(false);

  const filtered = useMemo(() => {
    const q = query.trim().toLowerCase();
    return templates.filter((t) => {
      if (typeFilter !== "ALL" && t.type !== typeFilter) return false;
      if (!q) return true;
      return (
        t.name.toLowerCase().includes(q) ||
        t.content.toLowerCase().includes(q) ||
        t.type.toLowerCase().includes(q)
      );
    });
  }, [templates, query, typeFilter]);

  const onDuplicate = (id: string) => {
    const fd = new FormData();
    fd.append("id", id);
    start(async () => {
      await duplicateTemplateAction(fd);
      router.refresh();
    });
  };

  const onDelete = (id: string, name: string) => {
    if (!confirm(`Удалить шаблон «${name}»? Действие необратимо.`)) return;
    const fd = new FormData();
    fd.append("id", id);
    start(async () => {
      await deleteTemplateAction(fd);
      router.refresh();
    });
  };

  const onImportClick = () => {
    setImportError(null);
    fileInputRef.current?.click();
  };

  const onImport = async (picked: FileList | null) => {
    if (!picked || picked.length === 0) return;
    const file = picked[0];
    setImporting(true);
    setImportError(null);
    try {
      const fd = new FormData();
      fd.append("file", file);
      const res = await importTemplateAction(fd);
      if (res.ok && res.id) {
        router.push(`/templates/${res.id}/edit`);
      } else {
        setImportError(res.message ?? "Не удалось загрузить файл");
      }
    } finally {
      setImporting(false);
      if (fileInputRef.current) fileInputRef.current.value = "";
    }
  };

  return (
    <div>
      {/* действия */}
      {isManager && (
        <div className="flex flex-wrap gap-2 mb-5 justify-end">
          <Link href="/templates/new">
            <Button>
              <Plus size={16} /> Новый шаблон
            </Button>
          </Link>
          <Button variant="secondary" onClick={onImportClick} disabled={importing}>
            <Upload size={16} /> {importing ? "Импорт…" : "Импорт файла"}
          </Button>
          <input
            ref={fileInputRef}
            type="file"
            accept=".txt,.md,.pdf,application/pdf"
            className="hidden"
            onChange={(e) => onImport(e.target.files)}
          />
        </div>
      )}

      {/* поиск */}
      <div className="flex flex-wrap items-center gap-3 mb-5">
        <div className="flex flex-wrap gap-2">
          <TabPill
            active={typeFilter === "ALL"}
            onClick={() => setTypeFilter("ALL")}
          >
            Все типы
          </TabPill>
          {TEMPLATE_TYPES.map((t) => (
            <TabPill
              key={t}
              active={typeFilter === t}
              onClick={() => setTypeFilter(t)}
            >
              {t}
            </TabPill>
          ))}
        </div>
        <div className="ml-auto relative min-w-[200px] flex-1 md:flex-initial md:w-80">
          <Search
            size={16}
            className="absolute left-3.5 top-1/2 -translate-y-1/2 text-text-muted pointer-events-none"
          />
          <input
            type="text"
            value={query}
            onChange={(e) => setQuery(e.target.value)}
            placeholder="Поиск шаблонов…"
            className="w-full h-10 pl-10 pr-3 rounded-lg border border-border-soft bg-surface text-sm placeholder:text-placeholder focus:outline-none focus:border-brand/60 transition"
          />
        </div>
      </div>

      {importError && (
        <div className="mb-3 rounded-lg border border-red-200 bg-red-50 px-3 py-2 text-sm text-danger">
          {importError}
        </div>
      )}

      {/* таблица */}
      {filtered.length === 0 ? (
        <div className="flex flex-col items-center justify-center py-14 gap-3 text-center">
          <div className="w-14 h-14 rounded-full bg-accent-soft text-brand-dark flex items-center justify-center">
            <Files size={26} />
          </div>
          <div className="text-foreground font-medium">
            {templates.length === 0 ? "Шаблонов пока нет" : "Ничего не найдено"}
          </div>
          {isManager && templates.length === 0 && (
            <Link href="/templates/new">
              <Button variant="soft" size="sm">
                <Plus size={14} /> Создать первый
              </Button>
            </Link>
          )}
        </div>
      ) : (
        <>
          {/* десктоп */}
          <div className="hidden md:block rounded-2xl border border-border-soft bg-surface overflow-hidden">
            <table className="w-full text-sm">
              <thead className="bg-muted/60 text-text-soft">
                <tr>
                  <th className="text-left font-medium px-4 py-3">
                    Название шаблона
                  </th>
                  <th className="text-left font-medium px-4 py-3">Тип</th>
                  <th className="text-left font-medium px-4 py-3">Обновлён</th>
                  <th className="text-left font-medium px-4 py-3">
                    Использован
                  </th>
                  <th className="text-right font-medium px-4 py-3">Действия</th>
                </tr>
              </thead>
              <tbody className="divide-y divide-border-soft">
                {filtered.map((t) => (
                  <tr key={t.id} className="hover:bg-muted/30 transition">
                    <td className="px-4 py-3">
                      <Link
                        href={`/templates/${t.id}`}
                        className="flex items-center gap-2 group"
                        title="Открыть шаблон"
                      >
                        <FileText
                          size={16}
                          className="text-text-soft shrink-0 group-hover:text-brand transition"
                        />
                        <span className="font-medium text-foreground group-hover:text-brand transition">
                          {t.name}
                        </span>
                        {t.hasPdf && (
                          <span className="ml-1 inline-flex items-center gap-1 px-1.5 py-0.5 rounded-md bg-accent-soft/60 text-brand-dark text-[10px] font-semibold uppercase tracking-wide">
                            PDF
                          </span>
                        )}
                      </Link>
                    </td>
                    <td className="px-4 py-3 text-text-soft">{t.type}</td>
                    <td className="px-4 py-3 text-text-soft">
                      {new Date(t.updatedAt).toLocaleDateString("ru-RU")}
                    </td>
                    <td className="px-4 py-3 text-text-soft">
                      {t.usageCount}{" "}
                      {plural(t.usageCount, ["раз", "раза", "раз"])}
                    </td>
                    <td className="px-4 py-3">
                      <div className="flex items-center justify-end gap-0.5">
                        <RowAction
                          href={`/templates/${t.id}`}
                          icon={Eye}
                          title="Просмотр"
                        />
                        {isManager && (
                          <>
                            <RowAction
                              href={`/templates/${t.id}/edit`}
                              icon={Pencil}
                              title="Редактировать"
                            />
                            <RowButton
                              icon={Copy}
                              title="Дублировать"
                              onClick={() => onDuplicate(t.id)}
                              disabled={pending}
                            />
                          </>
                        )}
                        <RowButton
                          icon={Download}
                          title="Скачать"
                          onClick={() => downloadTemplate(t)}
                        />
                        {isManager && (
                          <RowButton
                            icon={Trash2}
                            title="Удалить"
                            onClick={() => onDelete(t.id, t.name)}
                            disabled={pending}
                            danger
                          />
                        )}
                      </div>
                    </td>
                  </tr>
                ))}
              </tbody>
            </table>
          </div>

          {/* мобилка */}
          <div className="md:hidden space-y-3">
            {filtered.map((t) => (
              <div
                key={t.id}
                className="rounded-2xl border border-border-soft bg-surface p-4"
              >
                <div className="flex items-start gap-2 mb-1">
                  <FileText size={16} className="text-text-soft shrink-0 mt-1" />
                  <Link
                    href={`/templates/${t.id}`}
                    className="font-semibold text-foreground flex-1 min-w-0 hover:text-brand"
                  >
                    {t.name}
                  </Link>
                </div>
                <div className="text-xs text-text-soft">
                  {t.type} · обновлён{" "}
                  {new Date(t.updatedAt).toLocaleDateString("ru-RU")} · использован{" "}
                  {t.usageCount} {plural(t.usageCount, ["раз", "раза", "раз"])}
                </div>
                <div className="mt-3 flex items-center gap-1">
                  <RowAction
                    href={`/templates/${t.id}`}
                    icon={Eye}
                    title="Просмотр"
                  />
                  {isManager && (
                    <>
                      <RowAction
                        href={`/templates/${t.id}/edit`}
                        icon={Pencil}
                        title="Редактировать"
                      />
                      <RowButton
                        icon={Copy}
                        title="Дублировать"
                        onClick={() => onDuplicate(t.id)}
                        disabled={pending}
                      />
                    </>
                  )}
                  <RowButton
                    icon={Download}
                    title="Скачать"
                    onClick={() => downloadTemplate(t)}
                  />
                  {isManager && (
                    <RowButton
                      icon={Trash2}
                      title="Удалить"
                      onClick={() => onDelete(t.id, t.name)}
                      disabled={pending}
                      danger
                    />
                  )}
                </div>
              </div>
            ))}
          </div>
        </>
      )}

    </div>
  );
}

function TabPill({
  active,
  onClick,
  children,
}: {
  active: boolean;
  onClick: () => void;
  children: React.ReactNode;
}) {
  return (
    <button
      type="button"
      onClick={onClick}
      className={`px-4 py-1.5 rounded-md text-sm transition ${
        active
          ? "bg-brand text-white font-medium"
          : "bg-muted text-text-soft hover:bg-border"
      }`}
    >
      {children}
    </button>
  );
}

function RowAction({
  href,
  icon: Icon,
  title,
}: {
  href: string;
  icon: typeof Eye;
  title: string;
}) {
  return (
    <Link
      href={href}
      title={title}
      aria-label={title}
      className="w-8 h-8 flex items-center justify-center rounded-md text-text-soft hover:text-brand hover:bg-muted transition"
    >
      <Icon size={16} />
    </Link>
  );
}

function RowButton({
  icon: Icon,
  title,
  onClick,
  disabled,
  danger,
}: {
  icon: typeof Eye;
  title: string;
  onClick: () => void;
  disabled?: boolean;
  danger?: boolean;
}) {
  return (
    <button
      type="button"
      onClick={onClick}
      disabled={disabled}
      title={title}
      aria-label={title}
      className={`w-8 h-8 flex items-center justify-center rounded-md hover:bg-muted transition disabled:opacity-50 disabled:cursor-not-allowed ${
        danger
          ? "text-text-soft hover:text-danger"
          : "text-text-soft hover:text-brand"
      }`}
    >
      <Icon size={16} />
    </button>
  );
}

