import Link from "next/link";
import { ArrowLeft } from "lucide-react";
import { requireRole } from "@/lib/auth";
import { PageShell } from "@/components/ui/page-shell";
import { TemplateForm } from "../template-form";
import { createTemplateAction } from "../actions";

export default async function NewTemplatePage() {
  await requireRole("MANAGER");
  return (
    <div>
      <div className="px-5 md:px-10 pt-6">
        <Link
          href="/templates"
          className="inline-flex items-center gap-1.5 text-sm text-text-soft hover:text-foreground"
        >
          <ArrowLeft size={14} /> К шаблонам
        </Link>
      </div>
      <PageShell title="Новый шаблон" titleAlign="center">
        <TemplateForm action={createTemplateAction} submitLabel="Создать" />
      </PageShell>
    </div>
  );
}
