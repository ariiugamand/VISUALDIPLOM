"use client";

import { useTransition } from "react";
import { useRouter } from "next/navigation";
import { Trash2 } from "lucide-react";
import { Button } from "@/components/ui/button";
import { deleteTemplateAction } from "../actions";

export function DeleteTemplateButton({ id }: { id: string }) {
  const router = useRouter();
  const [pending, start] = useTransition();
  const onClick = () => {
    if (!confirm("Удалить шаблон?")) return;
    const fd = new FormData();
    fd.append("id", id);
    start(async () => {
      await deleteTemplateAction(fd);
      router.push("/templates");
    });
  };
  return (
    <Button variant="danger" size="sm" onClick={onClick} disabled={pending}>
      <Trash2 size={14} /> Удалить
    </Button>
  );
}
