"use client";

import { useActionState } from "react";
import { Save } from "lucide-react";
import { Textarea } from "@/components/ui/textarea";
import { Button } from "@/components/ui/button";
import { fillTemplateAction, type TemplateFormState } from "../actions";

type Props = {
  templateId: string;
  initialContent: string;
};

export function FillForm({ templateId, initialContent }: Props) {
  const [state, action, pending] = useActionState<TemplateFormState, FormData>(
    fillTemplateAction,
    undefined,
  );

  return (
    <form action={action} className="space-y-3">
      <input type="hidden" name="templateId" value={templateId} />
      <Textarea
        name="content"
        defaultValue={initialContent}
        className="min-h-[280px] font-[inherit]"
        maxLength={30000}
        placeholder="Подставьте свои данные в шаблон"
      />
      {state?.message && (
        <div
          className={`rounded-xl px-4 py-3 text-sm ${
            state.errors
              ? "bg-red-50 border border-red-200 text-danger"
              : "bg-accent-soft/40 border border-accent-soft text-brand-dark"
          }`}
        >
          {state.message}
        </div>
      )}
      <div className="flex justify-end">
        <Button type="submit" disabled={pending}>
          <Save size={15} /> {pending ? "Сохраняем…" : "Сохранить документ"}
        </Button>
      </div>
    </form>
  );
}
