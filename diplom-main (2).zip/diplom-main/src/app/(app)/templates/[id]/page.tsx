import Link from "next/link";
import { notFound } from "next/navigation";
import {
  ArrowLeft,
  User,
  Calendar,
  Pencil,
  Download,
  FileText,
} from "lucide-react";
import { prisma } from "@/lib/prisma";
import { requireAuth } from "@/lib/auth";
import { PageShell } from "@/components/ui/page-shell";
import { Button } from "@/components/ui/button";
import { FillForm } from "./fill-form";
import { DeleteTemplateButton } from "./delete-button";

function fmtSize(bytes: number): string {
  if (bytes < 1024) return `${bytes} Б`;
  if (bytes < 1024 * 1024) return `${(bytes / 1024).toFixed(0)} КБ`;
  return `${(bytes / (1024 * 1024)).toFixed(1)} МБ`;
}

export default async function TemplatePage(props: PageProps<"/templates/[id]">) {
  const { session } = await requireAuth();
  const { id } = await props.params;
  const isManager = session.role === "MANAGER";

  const template = await prisma.documentTemplate.findUnique({
    where: { id },
    include: { author: { select: { firstName: true, lastName: true } } },
  });
  if (!template) notFound();

  const hasPdf = !!template.pdfUrl;

  return (
    <div>
      <div className="px-5 md:px-10 pt-6 flex items-center justify-between gap-2 flex-wrap">
        <Link
          href="/templates"
          className="inline-flex items-center gap-1.5 text-sm text-text-soft hover:text-foreground"
        >
          <ArrowLeft size={14} /> К шаблонам
        </Link>
        <div className="flex items-center gap-2">
          {hasPdf && (
            <a href={`/api/templates/${template.id}/pdf?download=1`} download>
              <Button variant="secondary" size="sm">
                <Download size={14} /> Скачать PDF
              </Button>
            </a>
          )}
          {isManager && (
            <>
              <Link href={`/templates/${template.id}/edit`}>
                <Button variant="secondary" size="sm">
                  <Pencil size={14} /> Редактировать
                </Button>
              </Link>
              <DeleteTemplateButton id={template.id} />
            </>
          )}
        </div>
      </div>
      <PageShell title={template.name} subtitle={template.type}>
        <div className="flex flex-wrap items-center gap-4 mb-5 text-sm text-text-soft">
          <div className="flex items-center gap-1.5">
            <User size={14} />
            <span>
              {template.author.lastName} {template.author.firstName}
            </span>
          </div>
          <div className="flex items-center gap-1.5">
            <Calendar size={14} />
            <span>
              Обновлён {template.updatedAt.toLocaleDateString("ru-RU")}
            </span>
          </div>
          {hasPdf && template.pdfFilename && (
            <div className="flex items-center gap-1.5">
              <FileText size={14} />
              <span>
                {template.pdfFilename}
                {template.pdfSize != null && (
                  <span className="text-text-muted"> · {fmtSize(template.pdfSize)}</span>
                )}
              </span>
            </div>
          )}
        </div>

        {hasPdf ? (
          <div className="rounded-xl bg-surface border border-border-soft overflow-hidden mb-6">
            <iframe
              src={`/api/templates/${template.id}/pdf#zoom=page-fit&toolbar=1`}
              className="w-full h-[80vh] min-h-[520px] bg-muted"
              title={template.name}
            />
          </div>
        ) : template.content ? (
          <div className="rounded-xl bg-surface border border-border-soft p-5 text-sm text-foreground leading-relaxed mb-6 overflow-x-auto">
            <div className="whitespace-pre-wrap break-words min-w-0">
              {template.content}
            </div>
          </div>
        ) : (
          <div className="rounded-xl bg-surface border border-border-soft p-10 text-center text-text-soft text-sm mb-6">
            Шаблон пуст
          </div>
        )}

        {!isManager && template.content && (
          <div className="mt-4">
            <div className="text-sm font-medium text-foreground mb-3">
              Заполнить документ по шаблону
            </div>
            <FillForm templateId={template.id} initialContent={template.content} />
          </div>
        )}
      </PageShell>
    </div>
  );
}
