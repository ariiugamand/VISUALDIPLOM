import Link from "next/link";
import { notFound } from "next/navigation";
import { ArrowLeft } from "lucide-react";
import { prisma } from "@/lib/prisma";
import { requireRole } from "@/lib/auth";
import { PageShell } from "@/components/ui/page-shell";
import { TemplateForm } from "../../template-form";
import { updateTemplateAction } from "../../actions";

export default async function EditTemplatePage(props: PageProps<"/templates/[id]/edit">) {
  await requireRole("MANAGER");
  const { id } = await props.params;
  const tpl = await prisma.documentTemplate.findUnique({ where: { id } });
  if (!tpl) notFound();
  return (
    <div>
      <div className="px-5 md:px-10 pt-6">
        <Link
          href={`/templates/${id}`}
          className="inline-flex items-center gap-1.5 text-sm text-text-soft hover:text-foreground"
        >
          <ArrowLeft size={14} /> К шаблону
        </Link>
      </div>
      <PageShell title="Редактирование шаблона" titleAlign="center">
        <TemplateForm
          action={updateTemplateAction}
          submitLabel="Сохранить"
          initial={{
            id: tpl.id,
            name: tpl.name,
            type: tpl.type,
            content: tpl.content,
            pdfFilename: tpl.pdfFilename,
            pdfSize: tpl.pdfSize,
          }}
        />
      </PageShell>
    </div>
  );
}
