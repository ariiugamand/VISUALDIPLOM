"use server";

import { z } from "zod";
import { revalidatePath } from "next/cache";
import { redirect } from "next/navigation";
import { prisma } from "@/lib/prisma";
import { requireAuth, requireRole } from "@/lib/auth";
import { TEMPLATE_TYPES } from "@/lib/templates";
import {
  deleteStoredFile,
  deleteTemplateFiles,
  isPdfFile,
  saveTemplatePdf,
} from "@/lib/uploads";

// схема
const schema = z.object({
  name: z.string().min(3, { error: "Введите название" }).max(200).trim(),
  type: z.enum(TEMPLATE_TYPES),
  content: z.string().max(20000).trim().optional().or(z.literal("")),
});

export type TemplateFormState =
  | { errors?: Record<string, string[] | undefined>; message?: string }
  | undefined;

export async function createTemplateAction(
  _prev: TemplateFormState,
  formData: FormData,
): Promise<TemplateFormState> {
  const { user } = await requireRole("MANAGER");
  const parsed = schema.safeParse({
    name: formData.get("name"),
    type: formData.get("type"),
    content: formData.get("content") ?? "",
  });
  if (!parsed.success) return { errors: parsed.error.flatten().fieldErrors };

  const raw = formData.get("pdf");
  const hasFile = raw instanceof File && raw.size > 0;

  // проверка
  if (!hasFile && (!parsed.data.content || parsed.data.content.length < 5)) {
    return {
      message: "Заполните текст шаблона или прикрепите PDF-файл",
    };
  }

  if (hasFile) {
    const err = isPdfFile(raw);
    if (err) return { message: err };
  }

  const tpl = await prisma.documentTemplate.create({
    data: {
      name: parsed.data.name,
      type: parsed.data.type,
      content: parsed.data.content ?? "",
      authorId: user.id,
    },
  });

  if (hasFile) {
    const saved = await saveTemplatePdf(tpl.id, raw);
    await prisma.documentTemplate.update({
      where: { id: tpl.id },
      data: {
        pdfUrl: saved.relativePath,
        pdfFilename: raw.name,
        pdfSize: raw.size,
      },
    });
  }

  revalidatePath("/templates");
  redirect(`/templates/${tpl.id}`);
}

export async function updateTemplateAction(
  _prev: TemplateFormState,
  formData: FormData,
): Promise<TemplateFormState> {
  await requireRole("MANAGER");
  const id = formData.get("id");
  if (typeof id !== "string") return { message: "Некорректный id" };

  const parsed = schema.safeParse({
    name: formData.get("name"),
    type: formData.get("type"),
    content: formData.get("content") ?? "",
  });
  if (!parsed.success) return { errors: parsed.error.flatten().fieldErrors };

  const current = await prisma.documentTemplate.findUnique({
    where: { id },
    select: { pdfUrl: true },
  });
  if (!current) return { message: "Шаблон не найден" };

  const raw = formData.get("pdf");
  const hasNewFile = raw instanceof File && raw.size > 0;
  const removeFlag = formData.get("pdfRemove") === "1";

  // итоговое состояние
  const willHavePdf = hasNewFile || (!removeFlag && !!current.pdfUrl);

  if (
    !willHavePdf &&
    (!parsed.data.content || parsed.data.content.length < 5)
  ) {
    return {
      message: "Оставьте текст шаблона или PDF-файл — пустым шаблон быть не может",
    };
  }

  if (hasNewFile) {
    const err = isPdfFile(raw);
    if (err) return { message: err };
  }

  // текст
  await prisma.documentTemplate.update({
    where: { id },
    data: {
      name: parsed.data.name,
      type: parsed.data.type,
      content: parsed.data.content ?? "",
    },
  });

  // замена PDF
  if (hasNewFile) {
    if (current.pdfUrl) {
      await deleteStoredFile(current.pdfUrl).catch(() => {});
    }
    const saved = await saveTemplatePdf(id, raw);
    await prisma.documentTemplate.update({
      where: { id },
      data: {
        pdfUrl: saved.relativePath,
        pdfFilename: raw.name,
        pdfSize: raw.size,
      },
    });
  } else if (removeFlag && current.pdfUrl) {
    await deleteStoredFile(current.pdfUrl).catch(() => {});
    await prisma.documentTemplate.update({
      where: { id },
      data: { pdfUrl: null, pdfFilename: null, pdfSize: null },
    });
  }

  revalidatePath("/templates");
  revalidatePath(`/templates/${id}`);
  redirect(`/templates/${id}`);
}

export async function deleteTemplateAction(formData: FormData): Promise<void> {
  await requireRole("MANAGER");
  const id = formData.get("id");
  if (typeof id !== "string") return;
  await prisma.documentTemplate.delete({ where: { id } });
  await deleteTemplateFiles(id).catch(() => {});
  revalidatePath("/templates");
}

export async function duplicateTemplateAction(formData: FormData): Promise<void> {
  const { user } = await requireRole("MANAGER");
  const id = formData.get("id");
  if (typeof id !== "string") return;
  const src = await prisma.documentTemplate.findUnique({ where: { id } });
  if (!src) return;
  // без PDF
  await prisma.documentTemplate.create({
    data: {
      name: `${src.name} (копия)`,
      type: src.type,
      category: src.category,
      content: src.content,
      authorId: user.id,
    },
  });
  revalidatePath("/templates");
}

export async function importTemplateAction(
  formData: FormData,
): Promise<{ ok: boolean; message?: string; id?: string }> {
  const { user } = await requireRole("MANAGER");
  const file = formData.get("file");
  if (!(file instanceof File) || file.size === 0) {
    return { ok: false, message: "Файл не выбран" };
  }

  const nameLower = file.name.toLowerCase();
  const isPdf = file.type === "application/pdf" || nameLower.endsWith(".pdf");
  const isText =
    nameLower.endsWith(".txt") ||
    nameLower.endsWith(".md") ||
    file.type.startsWith("text/");

  if (!isPdf && !isText) {
    return { ok: false, message: "Поддерживаются только PDF и текстовые файлы" };
  }

  const baseName =
    file.name.replace(/\.[^.]+$/, "").slice(0, 200) || "Импортированный шаблон";

  if (isPdf) {
    const err = isPdfFile(file);
    if (err) return { ok: false, message: err };
    const tpl = await prisma.documentTemplate.create({
      data: {
        name: baseName,
        type: "Прочее",
        content: "",
        authorId: user.id,
      },
    });
    const saved = await saveTemplatePdf(tpl.id, file);
    await prisma.documentTemplate.update({
      where: { id: tpl.id },
      data: {
        pdfUrl: saved.relativePath,
        pdfFilename: file.name,
        pdfSize: file.size,
      },
    });
    revalidatePath("/templates");
    return { ok: true, id: tpl.id };
  }

  // текст
  if (file.size > 2 * 1024 * 1024) {
    return { ok: false, message: "Файл больше 2 МБ" };
  }
  const text = await file.text();
  if (!text.trim()) return { ok: false, message: "Файл пустой" };

  const tpl = await prisma.documentTemplate.create({
    data: {
      name: baseName,
      type: "Прочее",
      content: text.slice(0, 20000),
      authorId: user.id,
    },
  });
  revalidatePath("/templates");
  return { ok: true, id: tpl.id };
}

const fillSchema = z.object({
  templateId: z.string().min(1),
  content: z.string().min(5, { error: "Заполните документ" }).max(30000).trim(),
});

export async function fillTemplateAction(
  _prev: TemplateFormState,
  formData: FormData,
): Promise<TemplateFormState> {
  const { user } = await requireAuth();
  const parsed = fillSchema.safeParse({
    templateId: formData.get("templateId"),
    content: formData.get("content"),
  });
  if (!parsed.success) return { errors: parsed.error.flatten().fieldErrors };
  const tpl = await prisma.documentTemplate.findUnique({
    where: { id: parsed.data.templateId },
    select: { id: true },
  });
  if (!tpl) return { message: "Шаблон не найден" };
  await prisma.filledDocument.create({
    data: {
      templateId: tpl.id,
      userId: user.id,
      content: parsed.data.content,
    },
  });
  revalidatePath(`/templates/${tpl.id}`);
  revalidatePath("/templates");
  return { message: "Документ сохранён" };
}
