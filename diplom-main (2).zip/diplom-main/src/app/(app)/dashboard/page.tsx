import Link from "next/link";
import {
  Users,
  FileText,
  CalendarDays,
  ClipboardList,
  CheckCircle2,
  Clock,
  AlertCircle,
} from "lucide-react";
import { requireAuth } from "@/lib/auth";
import { prisma } from "@/lib/prisma";
import { typeLabel } from "@/lib/applications";

const MONTHS_RU = [
  "января", "февраля", "марта", "апреля", "мая", "июня",
  "июля", "августа", "сентября", "октября", "ноября", "декабря",
];
const WEEKDAYS_RU = [
  "воскресенье", "понедельник", "вторник", "среда", "четверг", "пятница", "суббота",
];

function ruDate(d: Date): string {
  return `${WEEKDAYS_RU[d.getDay()]}, ${d.getDate()} ${MONTHS_RU[d.getMonth()]} ${d.getFullYear()} г.`;
}

export default async function DashboardPage() {
  const { user, session } = await requireAuth();
  const isManager = session.role === "MANAGER";

  const today = new Date();

  const [
    employeesCount,
    newApplicationsCount,
    upcomingEventsCount,
    tasksTotal,
    tasksDone,
    tasksInProgress,
    tasksOverdue,
    latestApplications,
    latestTasks,
  ] = await Promise.all([
    prisma.user.count({ where: { role: "EMPLOYEE", status: "ACTIVE" } }),
    prisma.application.count({
      where: isManager
        ? { status: "SENT" }
        : { userId: user.id, status: "SENT" },
    }),
    prisma.event.count({ where: { startsAt: { gte: today } } }),
    prisma.task.count({
      where: isManager ? {} : { assigneeId: user.id },
    }),
    prisma.task.count({
      where: isManager
        ? { status: "DONE" }
        : { assigneeId: user.id, status: "DONE" },
    }),
    prisma.task.count({
      where: isManager
        ? { status: "IN_PROGRESS" }
        : { assigneeId: user.id, status: "IN_PROGRESS" },
    }),
    prisma.task.count({
      where: {
        ...(isManager ? {} : { assigneeId: user.id }),
        status: { not: "DONE" },
        deadline: { lt: today },
      },
    }),
    prisma.application.findMany({
      where: isManager
        ? { status: "SENT" }
        : { userId: user.id, status: { in: ["CREATED", "SENT"] } },
      include: {
        user: { select: { firstName: true, lastName: true, middleName: true } },
      },
      orderBy: [{ createdAt: "desc" }],
      take: 4,
    }),
    prisma.task.findMany({
      where: isManager ? {} : { assigneeId: user.id },
      orderBy: [{ updatedAt: "desc" }],
      take: 4,
    }),
  ]);

  const fullName = `${user.lastName} ${user.firstName}${user.middleName ? " " + user.middleName : ""}`;

  return (
    <div className="px-5 md:px-10 py-6 md:py-8 space-y-5">
      {/* приветствие */}
      <section className="rounded-2xl bg-gradient-to-br from-brand to-brand-dark text-white px-6 md:px-8 py-6 md:py-7 shadow-card relative overflow-hidden">
        <h1 className="text-xl md:text-2xl font-bold leading-tight relative z-10">
          Добро пожаловать, {fullName}!
        </h1>
        <div className="text-sm md:text-base opacity-90 mt-1 relative z-10">
          {ruDate(today)}
        </div>
        {/* мягкий декор */}
        <div
          className="absolute -right-10 -bottom-10 w-48 h-48 rounded-full opacity-15"
          style={{ background: "radial-gradient(circle, white 0%, transparent 70%)" }}
          aria-hidden
        />
      </section>

      {/* счётчики */}
      <section className="grid grid-cols-2 lg:grid-cols-4 gap-3 md:gap-4">
        <StatCard
          icon={Users}
          value={employeesCount}
          label="Сотрудников"
          href="/employees"
        />
        <StatCard
          icon={FileText}
          value={newApplicationsCount}
          label={isManager ? "Новых заявлений" : "Моих заявлений"}
          href="/applications"
        />
        <StatCard
          icon={CalendarDays}
          value={upcomingEventsCount}
          label="Предстоящих событий"
          href="/events"
        />
        <StatCard
          icon={ClipboardList}
          value={tasksTotal}
          label="Всего задач"
          href="/tasks"
        />
      </section>

      {/* статус задач */}
      <section className="grid grid-cols-1 md:grid-cols-3 gap-3 md:gap-4">
        <StatusCard
          icon={CheckCircle2}
          iconBg="bg-accent-soft"
          iconColor="text-brand-dark"
          value={tasksDone}
          label="Завершено задач"
        />
        <StatusCard
          icon={Clock}
          iconBg="bg-amber-100"
          iconColor="text-warning"
          value={tasksInProgress}
          label="В работе"
        />
        <StatusCard
          icon={AlertCircle}
          iconBg="bg-red-100"
          iconColor="text-danger"
          value={tasksOverdue}
          label="Просрочено"
        />
      </section>

      {/* списки */}
      <section className="grid grid-cols-1 lg:grid-cols-2 gap-4">
        <Panel
          title={isManager ? "Новые заявления" : "Мои заявления"}
          allHref="/applications"
        >
          {latestApplications.length === 0 ? (
            <Empty text="Заявлений нет" />
          ) : (
            <ul className="divide-y divide-border-soft">
              {latestApplications.map((a) => (
                <li key={a.id}>
                  <Link
                    href={`/applications/${a.id}`}
                    className="flex items-center justify-between gap-3 py-3 hover:bg-muted/40 -mx-2 px-2 rounded-lg transition"
                  >
                    <div className="min-w-0">
                      <div className="font-medium text-foreground truncate">
                        {a.user.lastName} {a.user.firstName}
                        {a.user.middleName ? ` ${a.user.middleName}` : ""}
                      </div>
                      <div className="text-xs text-text-soft mt-0.5">
                        {typeLabel(a.type)} ·{" "}
                        {a.createdAt.toLocaleDateString("ru-RU")}
                      </div>
                    </div>
                    <span className="shrink-0 inline-flex items-center px-2.5 py-0.5 rounded-md bg-accent-soft text-brand-dark text-xs font-medium">
                      Новое
                    </span>
                  </Link>
                </li>
              ))}
            </ul>
          )}
        </Panel>

        <Panel title="Последние задачи" allHref="/tasks">
          {latestTasks.length === 0 ? (
            <Empty text="Задач нет" />
          ) : (
            <ul className="space-y-3">
              {latestTasks.map((t) => {
                const statusLabel =
                  t.status === "DONE"
                    ? "Готово"
                    : t.status === "IN_PROGRESS"
                      ? "В работе"
                      : "Новое";
                const statusClass =
                  t.status === "DONE"
                    ? "bg-accent-soft text-brand-dark"
                    : t.status === "IN_PROGRESS"
                      ? "bg-amber-100 text-amber-700"
                      : "bg-muted text-text-soft";
                return (
                  <li key={t.id}>
                    <Link
                      href="/tasks"
                      className="block hover:bg-muted/40 -mx-2 px-2 py-2 rounded-lg transition"
                    >
                      <div className="flex items-center justify-between gap-3 mb-1.5">
                        <div className="font-medium text-foreground truncate">
                          {t.title}
                        </div>
                        <span
                          className={`shrink-0 inline-flex items-center px-2.5 py-0.5 rounded-md text-xs font-medium ${statusClass}`}
                        >
                          {statusLabel}
                        </span>
                      </div>
                      <div className="flex items-center gap-2">
                        <div className="flex-1 h-1.5 bg-muted rounded-full overflow-hidden">
                          <div
                            className={`h-full rounded-full transition-all ${
                              t.progress >= 100
                                ? "bg-brand"
                                : t.progress > 0
                                  ? "bg-warning"
                                  : "bg-border"
                            }`}
                            style={{ width: `${Math.max(t.progress, 4)}%` }}
                          />
                        </div>
                        <span className="text-xs text-text-soft w-9 text-right">
                          {t.progress}%
                        </span>
                      </div>
                    </Link>
                  </li>
                );
              })}
            </ul>
          )}
        </Panel>
      </section>
    </div>
  );
}

function StatCard({
  icon: Icon,
  value,
  label,
  href,
}: {
  icon: typeof Users;
  value: number;
  label: string;
  href: string;
}) {
  return (
    <Link
      href={href}
      className="rounded-2xl border border-border-soft bg-surface p-4 md:p-5 flex flex-col gap-3 hover:shadow-chip hover:-translate-y-0.5 transition"
    >
      <div className="w-10 h-10 rounded-xl bg-accent-soft text-brand-dark flex items-center justify-center">
        <Icon size={18} />
      </div>
      <div>
        <div className="text-2xl md:text-3xl font-bold text-foreground leading-tight">
          {value}
        </div>
        <div className="text-sm text-text-soft mt-0.5">{label}</div>
      </div>
    </Link>
  );
}

function StatusCard({
  icon: Icon,
  iconBg,
  iconColor,
  value,
  label,
}: {
  icon: typeof CheckCircle2;
  iconBg: string;
  iconColor: string;
  value: number;
  label: string;
}) {
  return (
    <div className="rounded-2xl border border-border-soft bg-surface p-4 md:p-5 flex items-center gap-4">
      <div
        className={`w-11 h-11 rounded-full ${iconBg} flex items-center justify-center ${iconColor}`}
      >
        <Icon size={22} />
      </div>
      <div>
        <div className="text-2xl md:text-3xl font-bold text-foreground leading-tight">
          {value}
        </div>
        <div className="text-sm text-text-soft mt-0.5">{label}</div>
      </div>
    </div>
  );
}

function Panel({
  title,
  allHref,
  children,
}: {
  title: string;
  allHref: string;
  children: React.ReactNode;
}) {
  return (
    <div className="rounded-2xl border border-border-soft bg-surface p-5">
      <div className="flex items-center justify-between mb-2">
        <h2 className="font-semibold text-foreground">{title}</h2>
        <Link
          href={allHref}
          className="text-sm text-brand hover:text-brand-hover font-medium"
        >
          Все →
        </Link>
      </div>
      {children}
    </div>
  );
}

function Empty({ text }: { text: string }) {
  return (
    <div className="text-center text-text-soft text-sm py-8">{text}</div>
  );
}
