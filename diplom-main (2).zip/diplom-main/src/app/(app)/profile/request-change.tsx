"use client";

import { useActionState, useState } from "react";
import { Send } from "lucide-react";
import { Button } from "@/components/ui/button";
import { Modal } from "@/components/ui/modal";
import { Field } from "@/components/ui/field";
import { Input } from "@/components/ui/input";
import { Select } from "@/components/ui/select";
import { Textarea } from "@/components/ui/textarea";
import {
  createApplicationAction,
  type CreateFormState,
} from "../applications/actions";

const FIELDS = [
  { value: "ФИО", label: "ФИО" },
  { value: "Контактный телефон", label: "Контактный телефон" },
  { value: "Электронная почта", label: "Электронная почта" },
  { value: "Должность", label: "Должность" },
  { value: "Отдел", label: "Отдел" },
  { value: "Прочее", label: "Прочее" },
];

// обёртка
async function submitProfileChange(
  prev: CreateFormState,
  formData: FormData,
): Promise<CreateFormState> {
  const field = String(formData.get("field") ?? "").trim();
  const newValue = String(formData.get("newValue") ?? "").trim();
  const reason = String(formData.get("reason") ?? "").trim();

  if (!field) {
    return { message: "Выберите поле для изменения" };
  }
  if (!newValue) {
    return { message: "Укажите новое значение" };
  }
  if (reason.length < 5) {
    return { message: "Опишите причину (не менее 5 символов)" };
  }

  const subject = `Изменение данных: ${field} → ${newValue}`.slice(0, 200);
  const text = `Поле: ${field}\nНовое значение: ${newValue}\n\nПричина: ${reason}`;

  const fd = new FormData();
  fd.append("type", "PROFILE_CHANGE");
  fd.append("action", "send");
  fd.append("subject", subject);
  fd.append("text", text);

  return createApplicationAction(prev, fd);
}

export function RequestChangeButton() {
  const [open, setOpen] = useState(false);
  const [field, setField] = useState<string>(FIELDS[0].value);
  const [newValue, setNewValue] = useState<string>("");
  const [reason, setReason] = useState<string>("");

  const [state, action, pending] = useActionState<CreateFormState, FormData>(
    submitProfileChange,
    undefined,
  );

  const resetForm = () => {
    setField(FIELDS[0].value);
    setNewValue("");
    setReason("");
  };

  return (
    <>
      <Button variant="soft" size="lg" onClick={() => setOpen(true)}>
        <Send size={16} /> Запросить изменения
      </Button>
      <Modal
        open={open}
        onClose={() => {
          setOpen(false);
          resetForm();
        }}
        maxWidth="max-w-md"
      >
        <form action={action} className="p-6 space-y-4">
          <h2 className="text-lg font-semibold text-foreground text-center">
            Запрос изменений личных данных
          </h2>
          <div className="text-xs text-text-muted text-center -mt-2">
            Заявка будет направлена руководителю
          </div>

          <Field label="Какое поле изменить">
            <Select
              name="field"
              value={field}
              onChange={(e) => setField(e.target.value)}
            >
              {FIELDS.map((f) => (
                <option key={f.value} value={f.value}>
                  {f.label}
                </option>
              ))}
            </Select>
          </Field>

          <Field label="Новое значение">
            <Input
              name="newValue"
              value={newValue}
              onChange={(e) => setNewValue(e.target.value)}
              placeholder="Укажите, на что поменять"
              maxLength={200}
            />
          </Field>

          <Field label="Причина">
            <Textarea
              name="reason"
              value={reason}
              onChange={(e) => setReason(e.target.value)}
              placeholder="Объясните, почему требуются изменения"
              maxLength={2000}
            />
          </Field>

          {state?.message && (
            <div className="rounded-xl bg-red-50 border border-red-200 px-4 py-3 text-sm text-danger">
              {state.message}
            </div>
          )}

          <div className="flex justify-center">
            <Button type="submit" disabled={pending}>
              <Send size={15} />
              {pending ? "Отправляем…" : "Отправить запрос"}
            </Button>
          </div>
        </form>
      </Modal>
    </>
  );
}
