import { Phone, Mail, Calendar, Building2, Briefcase, User } from "lucide-react";
import { requireAuth } from "@/lib/auth";
import { PageShell } from "@/components/ui/page-shell";
import { RequestChangeButton } from "./request-change";

export default async function ProfilePage() {
  const { user, session } = await requireAuth();
  const initials = `${user.lastName[0] ?? ""}${user.firstName[0] ?? ""}`.toUpperCase();
  const fullName = `${user.lastName} ${user.firstName} ${user.middleName ?? ""}`.trim();
  const roleLabel = session.role === "MANAGER" ? "Руководитель" : "Сотрудник";

  const rows = [
    { icon: Phone, label: "Контактный телефон", value: user.phone ?? "—" },
    { icon: Mail, label: "Электронная почта", value: user.email },
    { icon: Building2, label: "Отдел", value: user.department?.name ?? "—" },
    { icon: Briefcase, label: "Должность", value: user.position ?? "—" },
    { icon: User, label: "Роль", value: roleLabel },
    {
      icon: Calendar,
      label: "Дата приёма",
      value: user.hireDate
        ? user.hireDate.toLocaleDateString("ru-RU")
        : user.createdAt.toLocaleDateString("ru-RU"),
    },
  ];

  return (
    <PageShell title="Личный кабинет" titleAlign="center">
      <div className="flex flex-col items-center gap-3 mb-8">
        <div className="w-28 h-28 rounded-full bg-muted text-text-soft flex items-center justify-center text-3xl font-semibold shadow-inner">
          {initials || "ФОТО"}
        </div>
        <div className="text-center">
          <div className="text-2xl font-semibold text-foreground">{fullName}</div>
          <div className="text-sm text-text-soft mt-1">{roleLabel}</div>
        </div>
      </div>

      <dl className="grid grid-cols-1 sm:grid-cols-2 gap-x-8 gap-y-4 max-w-3xl mx-auto">
        {rows.map(({ icon: Icon, label, value }) => (
          <div key={label} className="flex items-start gap-3 py-2 border-b border-border-soft">
            <span className="mt-1 text-text-soft">
              <Icon size={16} />
            </span>
            <div className="flex-1">
              <dt className="text-xs text-text-muted">{label}</dt>
              <dd className="text-sm text-foreground mt-0.5">{value}</dd>
            </div>
          </div>
        ))}
      </dl>

      {session.role === "EMPLOYEE" ? (
        <div className="mt-8 flex justify-center">
          <RequestChangeButton />
        </div>
      ) : (
        <div className="mt-8 flex justify-center">
          <div className="text-center text-xs text-text-muted max-w-md">
            Изменения личных данных руководителя вносятся через отдел кадров.
          </div>
        </div>
      )}
    </PageShell>
  );
}
