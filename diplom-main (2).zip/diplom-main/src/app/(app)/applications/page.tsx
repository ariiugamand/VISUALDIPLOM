import { prisma } from "@/lib/prisma";
import { requireAuth } from "@/lib/auth";
import { PageShell } from "@/components/ui/page-shell";
import { type ApplicationStatus } from "@/lib/applications";
import { ApplicationsClient } from "./applications-client";

export default async function ApplicationsPage(props: PageProps<"/applications">) {
  const { user, session } = await requireAuth();
  const searchParams = await props.searchParams;
  const tabRaw = typeof searchParams.tab === "string" ? searchParams.tab : undefined;
  const isManager = session.role === "MANAGER";

  const defaultTab = isManager ? "incoming" : "all";
  const tab = tabRaw ?? defaultTab;

  let statusFilter: ApplicationStatus[] | undefined;
  if (isManager) {
    if (tab === "incoming") statusFilter = ["SENT"];
    else if (tab === "archive") statusFilter = ["APPROVED", "REJECTED"];
  } else {
    if (tab === "drafts") statusFilter = ["CREATED"];
    else if (tab === "sent") statusFilter = ["SENT"];
    else if (tab === "resolved") statusFilter = ["APPROVED", "REJECTED"];
  }

  const apps = await prisma.application.findMany({
    where: {
      ...(isManager
        ? { status: { in: statusFilter ?? ["SENT", "APPROVED", "REJECTED"] } }
        : { userId: user.id, ...(statusFilter && { status: { in: statusFilter } }) }),
    },
    include: {
      user: {
        select: {
          firstName: true,
          lastName: true,
          middleName: true,
          position: true,
          email: true,
        },
      },
      attachments: { orderBy: { createdAt: "asc" } },
    },
    orderBy: [{ createdAt: "desc" }],
  });

  const reviewerIds = Array.from(
    new Set(apps.map((a) => a.reviewedById).filter((v): v is string => !!v)),
  );
  const reviewers =
    reviewerIds.length > 0
      ? await prisma.user.findMany({
          where: { id: { in: reviewerIds } },
          select: { id: true, firstName: true, lastName: true },
        })
      : [];
  const reviewerMap = new Map(reviewers.map((r) => [r.id, r]));

  const items = apps.map((a) => ({
    id: a.id,
    userId: a.userId,
    type: a.type,
    subject: a.subject,
    text: a.text,
    status: a.status,
    createdAt: a.createdAt.toISOString(),
    startDate: a.startDate ? a.startDate.toISOString() : null,
    endDate: a.endDate ? a.endDate.toISOString() : null,
    managerComment: a.managerComment,
    reviewedAt: a.reviewedAt ? a.reviewedAt.toISOString() : null,
    user: a.user,
    reviewer: a.reviewedById
      ? (() => {
          const r = reviewerMap.get(a.reviewedById);
          return r ? { firstName: r.firstName, lastName: r.lastName } : null;
        })()
      : null,
    attachments: a.attachments.map((at) => ({
      id: at.id,
      filename: at.filename,
      size: at.size,
    })),
  }));

  const employeeTabs = [
    { key: "all", label: "Все" },
    { key: "drafts", label: "Черновики" },
    { key: "sent", label: "Отправленные" },
    { key: "resolved", label: "Рассмотренные" },
  ];
  const managerTabs = [
    { key: "incoming", label: "Новые" },
    { key: "archive", label: "Архив" },
  ];
  const tabs = isManager ? managerTabs : employeeTabs;

  return (
    <PageShell title={isManager ? "Заявления сотрудников" : "Мои документы"}>
      <ApplicationsClient
        items={items}
        currentUserId={user.id}
        isManager={isManager}
        tab={tab}
        tabs={tabs}
      />
    </PageShell>
  );
}
