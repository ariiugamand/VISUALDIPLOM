import Link from "next/link";
import { ArrowLeft } from "lucide-react";
import { requireAuth } from "@/lib/auth";
import { PageShell } from "@/components/ui/page-shell";
import { ApplicationCreateForm } from "./create-form";

const VALID_TYPES = new Set([
  "VACATION",
  "SICK_LEAVE",
  "SCHEDULE_CHANGE",
  "PROFILE_CHANGE",
  "OTHER",
]);

export default async function NewApplicationPage(props: PageProps<"/applications/new">) {
  await requireAuth();
  const searchParams = await props.searchParams;
  const typeRaw = typeof searchParams.type === "string" ? searchParams.type : undefined;
  const dateRaw = typeof searchParams.date === "string" ? searchParams.date : undefined;

  const initialType = typeRaw && VALID_TYPES.has(typeRaw) ? typeRaw : undefined;
  const initialDate =
    dateRaw && /^\d{4}-\d{2}-\d{2}$/.test(dateRaw) ? dateRaw : undefined;

  return (
    <div>
      <div className="px-6 md:px-10 pt-6">
        <Link
          href="/applications"
          className="inline-flex items-center gap-1.5 text-sm text-text-soft hover:text-foreground"
        >
          <ArrowLeft size={14} /> К списку
        </Link>
      </div>
      <PageShell title="Новое заявление" titleAlign="center">
        <ApplicationCreateForm initialType={initialType} initialDate={initialDate} />
      </PageShell>
    </div>
  );
}
