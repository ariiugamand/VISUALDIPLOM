"use client";

import { useActionState, useRef, useState } from "react";
import Link from "next/link";
import { Paperclip, Send, Save, X } from "lucide-react";
import {
  createApplicationAction,
  type CreateFormState,
} from "../actions";
import { Field } from "@/components/ui/field";
import { Input } from "@/components/ui/input";
import { Select } from "@/components/ui/select";
import { Textarea } from "@/components/ui/textarea";
import { Button } from "@/components/ui/button";
import { APPLICATION_TYPES } from "@/lib/applications";

const MAX_FILES = 5;
const MAX_SIZE = 10 * 1024 * 1024;

function fmtSize(bytes: number): string {
  if (bytes < 1024) return `${bytes} Б`;
  if (bytes < 1024 * 1024) return `${(bytes / 1024).toFixed(0)} КБ`;
  return `${(bytes / (1024 * 1024)).toFixed(1)} МБ`;
}

type Props = {
  initialType?: string;
  initialDate?: string;
};

export function ApplicationCreateForm({ initialType, initialDate }: Props = {}) {
  const [state, action, pending] = useActionState<CreateFormState, FormData>(
    createApplicationAction,
    undefined,
  );
  const [intent, setIntent] = useState<"save" | "send">("send");
  const [type, setType] = useState<string>(initialType ?? "VACATION");
  const [files, setFiles] = useState<File[]>([]);
  const [clientError, setClientError] = useState<string | null>(null);
  const fileInputRef = useRef<HTMLInputElement>(null);

  const showDates = type === "VACATION" || type === "SICK_LEAVE" || type === "SCHEDULE_CHANGE";

  const addFiles = (picked: FileList | null) => {
    if (!picked) return;
    const newOnes: File[] = [];
    for (let i = 0; i < picked.length; i++) {
      const f = picked[i];
      if (f.size > MAX_SIZE) {
        setClientError(`Файл «${f.name}» больше 10 МБ`);
        continue;
      }
      if (files.length + newOnes.length >= MAX_FILES) {
        setClientError(`Можно прикрепить не более ${MAX_FILES} файлов`);
        break;
      }
      // дубль
      if (
        files.some((e) => e.name === f.name && e.size === f.size) ||
        newOnes.some((e) => e.name === f.name && e.size === f.size)
      ) {
        continue;
      }
      newOnes.push(f);
    }
    if (newOnes.length > 0) {
      setFiles((prev) => [...prev, ...newOnes]);
      setClientError(null);
    }
    if (fileInputRef.current) fileInputRef.current.value = "";
  };

  // синк с input
  const onSubmit = (e: React.FormEvent<HTMLFormElement>) => {
    if (fileInputRef.current) {
      const dt = new DataTransfer();
      files.forEach((f) => dt.items.add(f));
      fileInputRef.current.files = dt.files;
    }
    void e;
  };

  return (
    <form action={action} onSubmit={onSubmit} className="space-y-4 max-w-2xl mx-auto">
      <input type="hidden" name="action" value={intent} />

      <Field label="Тип заявления" error={state?.errors?.type?.[0]}>
        <Select
          name="type"
          value={type}
          onChange={(e) => setType(e.target.value)}
        >
          {APPLICATION_TYPES.map((t) => (
            <option key={t.value} value={t.value}>
              {t.label}
            </option>
          ))}
        </Select>
      </Field>

      <Field label="Тема" error={state?.errors?.subject?.[0]}>
        <Input name="subject" placeholder="Краткое название" required maxLength={200} />
      </Field>

      {showDates && (
        <div className="grid grid-cols-1 sm:grid-cols-2 gap-3">
          <Field label="Дата" error={state?.errors?.startDate?.[0]}>
            <Input name="startDate" type="date" defaultValue={initialDate} />
          </Field>
          <Field
            label="Конец"
            hint="*если применимо"
            error={state?.errors?.endDate?.[0]}
          >
            <Input name="endDate" type="date" />
          </Field>
        </div>
      )}

      <Field label="Причина" error={state?.errors?.text?.[0]}>
        <Textarea
          name="text"
          placeholder="Расскажите подробно, что нужно"
          required
          maxLength={4000}
        />
      </Field>

      <div>
        <div className="flex items-center justify-between mb-2">
          <span className="text-sm font-medium text-text-soft">
            Вложения{" "}
            <span className="text-xs text-text-muted font-normal">
              (до {MAX_FILES} файлов · до 10 МБ каждый)
            </span>
          </span>
          <Button
            type="button"
            variant="soft"
            size="sm"
            onClick={() => fileInputRef.current?.click()}
            disabled={files.length >= MAX_FILES}
          >
            <Paperclip size={14} /> Прикрепить
          </Button>
        </div>
        <input
          ref={fileInputRef}
          type="file"
          name="attachments"
          multiple
          className="hidden"
          accept="image/*,.pdf,.doc,.docx,.xls,.xlsx,.txt"
          onChange={(e) => addFiles(e.target.files)}
        />
        {files.length > 0 ? (
          <ul className="space-y-1.5">
            {files.map((f, idx) => (
              <li
                key={`${f.name}-${idx}`}
                className="flex items-center gap-2 px-3 py-2 rounded-xl bg-muted/60 border border-border-soft text-sm"
              >
                <Paperclip size={14} className="text-text-soft shrink-0" />
                <span className="flex-1 min-w-0 truncate">{f.name}</span>
                <span className="text-xs text-text-muted">{fmtSize(f.size)}</span>
                <button
                  type="button"
                  onClick={() => setFiles((prev) => prev.filter((_, i) => i !== idx))}
                  className="w-6 h-6 flex items-center justify-center rounded-full text-text-soft hover:bg-border hover:text-danger transition"
                  aria-label="Убрать"
                >
                  <X size={14} />
                </button>
              </li>
            ))}
          </ul>
        ) : (
          <div className="text-xs text-text-muted px-1">Файлы не прикреплены</div>
        )}
        {clientError && <div className="text-xs text-danger mt-1.5 pl-1">{clientError}</div>}
      </div>

      {state?.message && (
        <div className="rounded-2xl bg-red-50 border border-red-200 px-4 py-3 text-sm text-danger">
          {state.message}
        </div>
      )}

      <div className="flex flex-col sm:flex-row gap-2 justify-center pt-2">
        <Button
          type="submit"
          variant="secondary"
          size="lg"
          disabled={pending}
          onClick={() => setIntent("save")}
        >
          <Save size={16} /> Сохранить черновик
        </Button>
        <Button
          type="submit"
          size="lg"
          disabled={pending}
          onClick={() => setIntent("send")}
        >
          <Send size={16} /> Создать заявление
        </Button>
      </div>

      <div className="text-center pt-1">
        <Link
          href="/templates"
          className="text-sm text-text-soft hover:text-brand underline-offset-2 hover:underline transition"
        >
          перейти к шаблонам
        </Link>
      </div>
    </form>
  );
}
