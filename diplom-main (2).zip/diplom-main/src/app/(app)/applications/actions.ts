"use server";

import { z } from "zod";
import { revalidatePath } from "next/cache";
import { redirect } from "next/navigation";
import { prisma } from "@/lib/prisma";
import { requireAuth, requireRole } from "@/lib/auth";
import {
  MAX_FILES_PER_APPLICATION,
  deleteApplicationFiles,
  isAllowedFile,
  saveApplicationFile,
} from "@/lib/uploads";

const createSchema = z
  .object({
    type: z.enum(["VACATION", "SICK_LEAVE", "SCHEDULE_CHANGE", "PROFILE_CHANGE", "OTHER"]),
    subject: z.string().min(3, { error: "Тема не может быть короче 3 символов" }).max(200).trim(),
    text: z.string().min(5, { error: "Опишите заявление подробнее" }).max(4000).trim(),
    startDate: z.string().trim().optional().or(z.literal("")),
    endDate: z.string().trim().optional().or(z.literal("")),
    action: z.enum(["save", "send"]),
  })
  .refine(
    (v) => {
      if (!v.startDate || !v.endDate) return true;
      return new Date(v.startDate) <= new Date(v.endDate);
    },
    { error: "Дата окончания раньше даты начала", path: ["endDate"] },
  );

export type CreateFormState =
  | { errors?: Record<string, string[] | undefined>; message?: string }
  | undefined;

export async function createApplicationAction(
  _prev: CreateFormState,
  formData: FormData,
): Promise<CreateFormState> {
  const { user } = await requireAuth();

  const parsed = createSchema.safeParse({
    type: formData.get("type"),
    subject: formData.get("subject"),
    text: formData.get("text"),
    startDate: formData.get("startDate") ?? "",
    endDate: formData.get("endDate") ?? "",
    action: formData.get("action") ?? "save",
  });

  if (!parsed.success) {
    return { errors: parsed.error.flatten().fieldErrors };
  }

  const data = parsed.data;

  // файлы
  const rawFiles = formData.getAll("attachments");
  const files: File[] = rawFiles.filter(
    (f): f is File => f instanceof File && f.size > 0,
  );
  if (files.length > MAX_FILES_PER_APPLICATION) {
    return { message: `Можно прикрепить не более ${MAX_FILES_PER_APPLICATION} файлов` };
  }
  for (const f of files) {
    const err = isAllowedFile(f);
    if (err) return { message: err };
  }

  const created = await prisma.application.create({
    data: {
      userId: user.id,
      type: data.type,
      subject: data.subject,
      text: data.text,
      startDate: data.startDate ? new Date(data.startDate) : null,
      endDate: data.endDate ? new Date(data.endDate) : null,
      status: data.action === "send" ? "SENT" : "CREATED",
    },
  });

  for (const f of files) {
    const saved = await saveApplicationFile(created.id, f);
    await prisma.applicationAttachment.create({
      data: {
        applicationId: created.id,
        filename: f.name,
        url: saved.relativePath,
        size: f.size,
        mimeType: f.type || null,
      },
    });
  }

  revalidatePath("/applications");
  redirect("/applications");
}

export async function sendApplicationAction(formData: FormData): Promise<void> {
  const { user } = await requireAuth();
  const id = formData.get("id");
  if (typeof id !== "string") return;

  await prisma.application.updateMany({
    where: { id, userId: user.id, status: "CREATED" },
    data: { status: "SENT" },
  });
  revalidatePath("/applications");
  revalidatePath(`/applications/${id}`);
}

export async function deleteApplicationAction(formData: FormData): Promise<void> {
  const { user } = await requireAuth();
  const id = formData.get("id");
  if (typeof id !== "string") return;

  const removed = await prisma.application.deleteMany({
    where: { id, userId: user.id, status: { in: ["CREATED", "SENT"] } },
  });
  if (removed.count > 0) {
    await deleteApplicationFiles(id).catch(() => {});
  }
  revalidatePath("/applications");
}

export async function bulkDeleteApplicationsAction(formData: FormData): Promise<void> {
  const { user } = await requireAuth();
  const idsRaw = formData.getAll("ids");
  const ids = idsRaw.filter((v): v is string => typeof v === "string" && v.length > 0);
  if (ids.length === 0) return;

  const toRemove = await prisma.application.findMany({
    where: { id: { in: ids }, userId: user.id, status: { in: ["CREATED", "SENT"] } },
    select: { id: true },
  });
  if (toRemove.length === 0) return;

  await prisma.application.deleteMany({
    where: { id: { in: toRemove.map((a) => a.id) }, userId: user.id },
  });
  await Promise.all(toRemove.map((a) => deleteApplicationFiles(a.id).catch(() => {})));
  revalidatePath("/applications");
}

const reviewSchema = z.object({
  id: z.string().min(1),
  decision: z.enum(["APPROVED", "REJECTED"]),
  comment: z.string().max(2000).trim().optional().or(z.literal("")),
});

export type ReviewFormState =
  | { errors?: Record<string, string[] | undefined>; message?: string }
  | undefined;

export async function reviewApplicationAction(
  _prev: ReviewFormState,
  formData: FormData,
): Promise<ReviewFormState> {
  const { user } = await requireRole("MANAGER");

  const parsed = reviewSchema.safeParse({
    id: formData.get("id"),
    decision: formData.get("decision"),
    comment: formData.get("comment") ?? "",
  });

  if (!parsed.success) {
    return { errors: parsed.error.flatten().fieldErrors };
  }

  const { id, decision, comment } = parsed.data;

  const app = await prisma.application.findUnique({
    where: { id },
    select: { status: true, type: true, text: true, userId: true },
  });
  if (!app) return { message: "Заявление не найдено" };
  if (app.status !== "SENT") {
    return { message: "Заявление уже обработано" };
  }

  // автоприменение изменений профиля
  let autoNote: string | null = null;
  if (decision === "APPROVED" && app.type === "PROFILE_CHANGE") {
    const parsed = parseProfileChangeText(app.text);
    if (parsed.field && parsed.newValue) {
      const result = await applyProfileChange(
        app.userId,
        parsed.field,
        parsed.newValue,
      );
      if (!result.ok) {
        autoNote = `⚠️ ${result.error}`;
      }
    } else {
      autoNote = "⚠️ Не удалось распознать поле/значение — изменения не применены";
    }
  }

  const finalComment = [comment, autoNote].filter(Boolean).join("\n\n") || null;

  await prisma.application.update({
    where: { id },
    data: {
      status: decision,
      managerComment: finalComment,
      reviewedAt: new Date(),
      reviewedById: user.id,
    },
  });

  revalidatePath("/applications");
  revalidatePath(`/applications/${id}`);
  revalidatePath("/profile");
  revalidatePath("/employees");
}

// парсер текста
function parseProfileChangeText(text: string): {
  field: string | null;
  newValue: string | null;
} {
  const fieldMatch = text.match(/^Поле:\s*(.+)$/m);
  const valueMatch = text.match(/^Новое значение:\s*(.+)$/m);
  return {
    field: fieldMatch?.[1]?.trim() ?? null,
    newValue: valueMatch?.[1]?.trim() ?? null,
  };
}

// применить изменение
async function applyProfileChange(
  userId: string,
  field: string,
  newValue: string,
): Promise<{ ok: true } | { ok: false; error: string }> {
  const value = newValue.trim();
  if (!value) return { ok: false, error: "Новое значение пустое" };

  try {
    switch (field) {
      case "ФИО": {
        const parts = value.split(/\s+/);
        const lastName = parts[0] ?? "";
        const firstName = parts[1] ?? "";
        const middleName = parts.slice(2).join(" ") || null;
        if (!lastName || !firstName) {
          return { ok: false, error: "ФИО должно содержать хотя бы фамилию и имя" };
        }
        await prisma.user.update({
          where: { id: userId },
          data: { lastName, firstName, middleName },
        });
        return { ok: true };
      }
      case "Контактный телефон": {
        await prisma.user.update({
          where: { id: userId },
          data: { phone: value },
        });
        return { ok: true };
      }
      case "Электронная почта": {
        await prisma.user.update({
          where: { id: userId },
          data: { email: value.toLowerCase() },
        });
        return { ok: true };
      }
      case "Должность": {
        await prisma.user.update({
          where: { id: userId },
          data: { position: value },
        });
        return { ok: true };
      }
      case "Отдел": {
        const dept = await prisma.department.findFirst({
          where: { name: value },
        });
        if (!dept) {
          return {
            ok: false,
            error: `Отдел «${value}» не найден — изменение не применено`,
          };
        }
        await prisma.user.update({
          where: { id: userId },
          data: { departmentId: dept.id },
        });
        return { ok: true };
      }
      case "Прочее":
        return {
          ok: false,
          error: "Поле «Прочее» применяется вручную через отдел кадров",
        };
      default:
        return { ok: false, error: `Неизвестное поле «${field}»` };
    }
  } catch (e) {
    // уникальные поля
    const msg = e instanceof Error ? e.message : String(e);
    if (msg.toLowerCase().includes("unique")) {
      return {
        ok: false,
        error: `Значение уже используется другим сотрудником — изменение не применено`,
      };
    }
    return { ok: false, error: `Не удалось применить: ${msg}` };
  }
}
