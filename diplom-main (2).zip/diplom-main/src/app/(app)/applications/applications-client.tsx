"use client";

import { useEffect, useMemo, useState, useTransition } from "react";
import Link from "next/link";
import { useRouter } from "next/navigation";
import {
  CheckSquare,
  ChevronDown,
  Inbox,
  Plus,
  Square,
  Trash2,
} from "lucide-react";
import { Modal } from "@/components/ui/modal";
import { Button } from "@/components/ui/button";
import {
  APPLICATION_TYPES,
  statusBadgeClasses,
  statusLabel,
  typeLabel,
} from "@/lib/applications";
import { ApplicationDetail, type ApplicationDetailDto } from "./application-detail";
import { bulkDeleteApplicationsAction } from "./actions";
import { ApplicationCreateForm } from "./new/create-form";

type ListItem = ApplicationDetailDto & {
  userId: string;
};

type Props = {
  items: ListItem[];
  currentUserId: string;
  isManager: boolean;
  tab: string;
  tabs: Array<{ key: string; label: string }>;
};

export function ApplicationsClient({ items, currentUserId, isManager, tab, tabs }: Props) {
  const router = useRouter();
  const [pending, start] = useTransition();
  const [typeFilter, setTypeFilter] = useState<string>("ALL");
  const [typeOpen, setTypeOpen] = useState(false);
  const [selected, setSelected] = useState<Set<string>>(new Set());
  const [selectMode, setSelectMode] = useState(false);
  const [activeId, setActiveId] = useState<string | null>(null);
  const [createOpen, setCreateOpen] = useState(false);

  const filtered = useMemo(() => {
    if (typeFilter === "ALL") return items;
    return items.filter((i) => i.type === typeFilter);
  }, [items, typeFilter]);

  const deletableIds = useMemo(
    () =>
      new Set(
        filtered
          .filter(
            (a) =>
              a.userId === currentUserId &&
              (a.status === "CREATED" || a.status === "SENT"),
          )
          .map((a) => a.id),
      ),
    [filtered, currentUserId],
  );

  const allSelectable = filtered.filter((a) => deletableIds.has(a.id));
  const allSelected =
    allSelectable.length > 0 && allSelectable.every((a) => selected.has(a.id));

  const toggle = (id: string) => {
    const next = new Set(selected);
    if (next.has(id)) next.delete(id);
    else next.add(id);
    setSelected(next);
  };

  const onDelete = () => {
    if (selected.size === 0) return;
    if (!confirm(`Удалить выбранные заявления (${selected.size})?`)) return;
    const fd = new FormData();
    selected.forEach((id) => fd.append("ids", id));
    start(async () => {
      await bulkDeleteApplicationsAction(fd);
      setSelected(new Set());
      setSelectMode(false);
      router.refresh();
    });
  };

  const active = activeId ? items.find((i) => i.id === activeId) ?? null : null;

  // автозакрытие
  useEffect(() => {
    if (activeId && !active) {
      setActiveId(null);
    }
  }, [activeId, active]);

  return (
    <div>
      {!isManager && (
        <div className="mb-4">
          <Button onClick={() => setCreateOpen(true)}>
            <Plus size={16} /> Создать заявление
          </Button>
        </div>
      )}

      {/* вкладки */}
      <div className="flex flex-wrap items-center gap-2 mb-3">
        <div className="flex flex-wrap gap-1.5">
          {tabs.map((t) => (
            <Link
              key={t.key}
              href={`/applications?tab=${t.key}`}
              className={`px-3.5 py-1.5 rounded-full text-sm transition ${
                tab === t.key
                  ? "bg-brand text-white font-medium"
                  : "bg-muted text-text-soft hover:bg-border"
              }`}
            >
              {t.label}
            </Link>
          ))}
        </div>

        {items.length > 0 && (
          <div className="relative ml-auto">
            <button
              type="button"
              onClick={() => setTypeOpen((v) => !v)}
              className={`inline-flex items-center gap-1.5 px-3 py-1.5 rounded-lg text-sm font-medium transition ${
                typeFilter === "ALL"
                  ? "border border-border-soft bg-surface text-text-soft hover:bg-muted"
                  : "border border-brand/40 bg-accent-soft/40 text-brand-dark"
              }`}
            >
              <span>
                {typeFilter === "ALL" ? "Тип заявления" : typeLabel(typeFilter)}
              </span>
              <ChevronDown
                size={14}
                className={`transition-transform ${typeOpen ? "rotate-180" : ""}`}
              />
            </button>
            {typeOpen && (
              <>
                <div
                  className="fixed inset-0 z-10"
                  onClick={() => setTypeOpen(false)}
                  aria-hidden
                />
                <div className="absolute right-0 top-10 z-20 w-60 rounded-xl border border-border-soft bg-surface shadow-card p-1.5">
                  <FilterItem
                    active={typeFilter === "ALL"}
                    onClick={() => {
                      setTypeFilter("ALL");
                      setTypeOpen(false);
                    }}
                  >
                    Все типы
                  </FilterItem>
                  {APPLICATION_TYPES.map((t) => (
                    <FilterItem
                      key={t.value}
                      active={typeFilter === t.value}
                      onClick={() => {
                        setTypeFilter(t.value);
                        setTypeOpen(false);
                      }}
                    >
                      {t.label}
                    </FilterItem>
                  ))}
                </div>
              </>
            )}
          </div>
        )}
      </div>

      {/* выбор */}
      {items.length > 0 && !isManager && allSelectable.length > 0 && (
        <div className="flex flex-wrap items-center gap-2 mb-3">
          <button
            type="button"
            onClick={() => {
              if (allSelected) {
                setSelected(new Set());
                setSelectMode(false);
              } else {
                setSelectMode(true);
                setSelected(new Set(allSelectable.map((a) => a.id)));
              }
            }}
            className="inline-flex items-center gap-1.5 text-sm text-text-soft hover:text-foreground transition"
          >
            {allSelected ? (
              <CheckSquare size={16} className="text-brand" />
            ) : (
              <Square size={16} />
            )}
            <span>{allSelected ? "Снять выделение" : "Выбрать все"}</span>
          </button>
          {selectMode && (
            <span className="text-sm text-text-soft">
              Выбрано: {selected.size}
            </span>
          )}
          <div className="ml-auto flex items-center gap-2">
            {selectMode && selected.size > 0 && (
              <button
                type="button"
                onClick={onDelete}
                disabled={pending}
                className="inline-flex items-center gap-1.5 px-3 py-2 rounded-lg border border-danger/50 bg-danger-soft/20 text-danger text-sm font-medium hover:bg-danger-soft/40 transition disabled:opacity-60"
              >
                <Trash2 size={14} />
                {pending ? "Удаляем…" : "Удалить"}
              </button>
            )}
          </div>
        </div>
      )}

      {/* список */}
      {filtered.length === 0 ? (
        <EmptyState isManager={isManager} />
      ) : (
        <div className="space-y-3">
          {filtered.map((a) => {
            const canSelect = !isManager && deletableIds.has(a.id);
            const checked = selected.has(a.id);
            return (
              <div
                key={a.id}
                className={`rounded-2xl border bg-surface p-4 transition ${
                  checked ? "border-brand/50" : "border-border-soft"
                } hover:shadow-chip cursor-pointer`}
                onClick={(e) => {
                  // чекбокс
                  if (selectMode && canSelect) {
                    e.preventDefault();
                    toggle(a.id);
                  } else {
                    setActiveId(a.id);
                  }
                }}
              >
                <div className="flex items-start gap-3">
                  {!isManager && selectMode && (
                    <div className="pt-0.5">
                      {canSelect ? (
                        checked ? (
                          <CheckSquare size={18} className="text-brand" />
                        ) : (
                          <Square size={18} className="text-text-soft" />
                        )
                      ) : (
                        <Square size={18} className="text-border" />
                      )}
                    </div>
                  )}
                  <div className="flex-1 min-w-0">
                    <div className="flex flex-wrap items-start justify-between gap-3">
                      <div className="min-w-0 flex-1">
                        <div className="flex items-center gap-2 text-xs text-text-soft mb-1">
                          <span>{typeLabel(a.type)}</span>
                          <span>·</span>
                          <span>{new Date(a.createdAt).toLocaleDateString("ru-RU")}</span>
                          {isManager && (
                            <>
                              <span>·</span>
                              <span>
                                {a.user.lastName} {a.user.firstName}
                              </span>
                            </>
                          )}
                        </div>
                        <div className="text-base font-medium text-foreground line-clamp-1">
                          {a.subject}
                        </div>
                        <div className="text-sm text-text-soft line-clamp-2 mt-0.5">
                          {a.text}
                        </div>
                      </div>
                      <span
                        className={`shrink-0 inline-block px-3 py-1 text-xs rounded-md font-medium ${statusBadgeClasses(
                          a.status,
                        )}`}
                      >
                        {statusLabel(a.status)}
                      </span>
                    </div>
                  </div>
                </div>
              </div>
            );
          })}
        </div>
      )}

      {/* детали */}
      <Modal
        open={activeId !== null}
        onClose={() => setActiveId(null)}
        maxWidth="max-w-lg"
      >
        {active && (
          <ApplicationDetail
            app={active}
            isAuthor={active.userId === currentUserId}
            isManager={isManager}
            variant="modal"
          />
        )}
      </Modal>

      {/* создание */}
      <Modal
        open={createOpen}
        onClose={() => setCreateOpen(false)}
        maxWidth="max-w-xl"
      >
        <div className="p-6">
          <div className="text-xl font-semibold text-foreground text-center mb-5 pr-6">
            Оформить заявление
          </div>
          <ApplicationCreateForm />
        </div>
      </Modal>
    </div>
  );
}

function FilterItem({
  active,
  onClick,
  children,
}: {
  active: boolean;
  onClick: () => void;
  children: React.ReactNode;
}) {
  return (
    <button
      type="button"
      onClick={onClick}
      className={`w-full text-left px-3 py-2 rounded-lg text-sm transition ${
        active ? "bg-accent-soft text-brand-dark font-medium" : "text-foreground hover:bg-muted"
      }`}
    >
      {children}
    </button>
  );
}

function EmptyState({ isManager }: { isManager: boolean }) {
  return (
    <div className="flex flex-col items-center justify-center py-14 gap-3 text-center">
      <div className="w-14 h-14 rounded-full bg-accent-soft text-brand-dark flex items-center justify-center">
        <Inbox size={26} />
      </div>
      <div className="text-foreground font-medium">
        {isManager ? "Новых заявлений нет" : "У вас пока нет заявлений"}
      </div>
      {!isManager && (
        <Link href="/applications/new">
          <Button variant="soft" size="sm">
            <Plus size={14} /> Создать первое
          </Button>
        </Link>
      )}
    </div>
  );
}
