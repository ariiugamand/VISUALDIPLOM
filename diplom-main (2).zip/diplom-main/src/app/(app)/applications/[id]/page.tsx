import Link from "next/link";
import { notFound } from "next/navigation";
import { ArrowLeft } from "lucide-react";
import { prisma } from "@/lib/prisma";
import { requireAuth } from "@/lib/auth";
import { PageShell } from "@/components/ui/page-shell";
import { typeLabel } from "@/lib/applications";
import { ApplicationDetail, type ApplicationDetailDto } from "../application-detail";

export default async function ApplicationDetailPage(props: PageProps<"/applications/[id]">) {
  const { user, session } = await requireAuth();
  const { id } = await props.params;
  const isManager = session.role === "MANAGER";

  const app = await prisma.application.findUnique({
    where: { id },
    include: {
      user: {
        select: {
          firstName: true,
          lastName: true,
          middleName: true,
          position: true,
          email: true,
        },
      },
      attachments: { orderBy: { createdAt: "asc" } },
    },
  });
  if (!app) notFound();

  const isAuthor = app.userId === user.id;
  if (!isAuthor && !isManager) notFound();

  const reviewer = app.reviewedById
    ? await prisma.user.findUnique({
        where: { id: app.reviewedById },
        select: { firstName: true, lastName: true },
      })
    : null;

  const dto: ApplicationDetailDto = {
    id: app.id,
    type: app.type,
    subject: app.subject,
    text: app.text,
    status: app.status,
    createdAt: app.createdAt.toISOString(),
    startDate: app.startDate ? app.startDate.toISOString() : null,
    endDate: app.endDate ? app.endDate.toISOString() : null,
    managerComment: app.managerComment,
    reviewedAt: app.reviewedAt ? app.reviewedAt.toISOString() : null,
    user: app.user,
    reviewer,
    attachments: app.attachments.map((a) => ({
      id: a.id,
      filename: a.filename,
      size: a.size,
    })),
  };

  return (
    <div>
      <div className="px-6 md:px-10 pt-6">
        <Link
          href="/applications"
          className="inline-flex items-center gap-1.5 text-sm text-text-soft hover:text-foreground"
        >
          <ArrowLeft size={14} /> К списку
        </Link>
      </div>
      <PageShell title={app.subject} subtitle={typeLabel(app.type)}>
        <ApplicationDetail app={dto} isAuthor={isAuthor} isManager={isManager} variant="page" />
      </PageShell>
    </div>
  );
}
