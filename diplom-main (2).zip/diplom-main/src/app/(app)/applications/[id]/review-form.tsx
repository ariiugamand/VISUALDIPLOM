"use client";

import { useActionState, useState } from "react";
import { Check, X } from "lucide-react";
import { reviewApplicationAction, type ReviewFormState } from "../actions";
import { Field } from "@/components/ui/field";
import { Textarea } from "@/components/ui/textarea";
import { Button } from "@/components/ui/button";

export function ReviewForm({ id }: { id: string }) {
  const [state, action, pending] = useActionState<ReviewFormState, FormData>(
    reviewApplicationAction,
    undefined,
  );
  const [decision, setDecision] = useState<"APPROVED" | "REJECTED">("APPROVED");

  return (
    <form action={action} className="space-y-4">
      <input type="hidden" name="id" value={id} />
      <input type="hidden" name="decision" value={decision} />

      <Field label="Комментарий (опционально для одобрения, обязательно для отказа)" error={state?.errors?.comment?.[0]}>
        <Textarea name="comment" placeholder="Обоснование решения" maxLength={2000} />
      </Field>

      {state?.message && (
        <div className="rounded-2xl bg-red-50 border border-red-200 px-4 py-3 text-sm text-danger">
          {state.message}
        </div>
      )}

      <div className="flex flex-col sm:flex-row gap-2 justify-end">
        <Button
          type="submit"
          variant="danger"
          disabled={pending}
          onClick={() => setDecision("REJECTED")}
        >
          <X size={16} /> Отклонить
        </Button>
        <Button
          type="submit"
          disabled={pending}
          onClick={() => setDecision("APPROVED")}
        >
          <Check size={16} /> Одобрить
        </Button>
      </div>
    </form>
  );
}
