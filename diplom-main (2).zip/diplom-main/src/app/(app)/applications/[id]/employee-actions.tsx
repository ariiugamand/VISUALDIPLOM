"use client";

import { useTransition } from "react";
import { Send, Trash2 } from "lucide-react";
import { sendApplicationAction, deleteApplicationAction } from "../actions";
import { Button } from "@/components/ui/button";

export function SendButton({ id }: { id: string }) {
  const [pending, start] = useTransition();
  return (
    <form
      onSubmit={(e) => {
        e.preventDefault();
        const fd = new FormData(e.currentTarget);
        start(() => sendApplicationAction(fd));
      }}
    >
      <input type="hidden" name="id" value={id} />
      <Button type="submit" disabled={pending}>
        <Send size={15} /> {pending ? "Отправляем…" : "Отправить на рассмотрение"}
      </Button>
    </form>
  );
}

export function DeleteButton({ id }: { id: string }) {
  const [pending, start] = useTransition();
  return (
    <form
      onSubmit={(e) => {
        e.preventDefault();
        if (!confirm("Удалить заявление? Действие необратимо.")) return;
        const fd = new FormData(e.currentTarget);
        start(() => deleteApplicationAction(fd));
      }}
    >
      <input type="hidden" name="id" value={id} />
      <Button type="submit" variant="secondary" disabled={pending}>
        <Trash2 size={15} /> {pending ? "Удаляем…" : "Удалить"}
      </Button>
    </form>
  );
}
