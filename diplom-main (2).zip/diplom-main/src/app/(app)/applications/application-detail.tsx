import { Calendar, User, Clock, Paperclip, Download, CheckCircle2, XCircle } from "lucide-react";
import { typeLabel, statusLabel, statusBadgeClasses } from "@/lib/applications";
import { ReviewForm } from "./[id]/review-form";
import { SendButton, DeleteButton } from "./[id]/employee-actions";

function fmtFileSize(bytes: number): string {
  if (bytes < 1024) return `${bytes} Б`;
  if (bytes < 1024 * 1024) return `${(bytes / 1024).toFixed(0)} КБ`;
  return `${(bytes / (1024 * 1024)).toFixed(1)} МБ`;
}

function fmtShortDate(d: Date | string): string {
  const dt = typeof d === "string" ? new Date(d) : d;
  return dt.toLocaleDateString("ru-RU", {
    day: "2-digit",
    month: "2-digit",
    year: "2-digit",
  });
}

export type ApplicationDetailDto = {
  id: string;
  type: string;
  subject: string;
  text: string;
  status: string;
  createdAt: string;
  startDate: string | null;
  endDate: string | null;
  managerComment: string | null;
  reviewedAt: string | null;
  user: {
    firstName: string;
    lastName: string;
    middleName: string | null;
    position: string | null;
    email: string;
  };
  reviewer: { firstName: string; lastName: string } | null;
  attachments: Array<{
    id: string;
    filename: string;
    size: number;
  }>;
};

type Props = {
  app: ApplicationDetailDto;
  isAuthor: boolean;
  isManager: boolean;
  variant?: "page" | "modal";
};

export function ApplicationDetail({ app, isAuthor, isManager, variant = "page" }: Props) {
  const canSend = isAuthor && app.status === "CREATED";
  const canDelete = isAuthor && (app.status === "CREATED" || app.status === "SENT");
  const canReview = isManager && app.status === "SENT";

  const isDecision = app.status === "APPROVED" || app.status === "REJECTED";

  const title = `Заявление ${typeLabelLower(app.type)} от ${fmtShortDate(app.createdAt)}`;

  const bodyPad = variant === "modal" ? "p-6" : "";

  return (
    <div className={bodyPad}>
      {variant === "modal" && (
        <div className="text-lg font-semibold text-foreground text-center mb-4 pr-6">
          {title}
        </div>
      )}

      {variant === "page" && (
        <div className="flex flex-wrap items-center gap-3 mb-6 text-sm text-text-soft">
          <span
            className={`inline-block px-3 py-1 text-xs rounded-md font-medium ${statusBadgeClasses(
              app.status,
            )}`}
          >
            {statusLabel(app.status)}
          </span>
          <div className="flex items-center gap-1.5">
            <User size={14} />
            <span>
              {app.user.lastName} {app.user.firstName} {app.user.middleName ?? ""}
            </span>
          </div>
          <div className="flex items-center gap-1.5">
            <Clock size={14} />
            <span>Создано {new Date(app.createdAt).toLocaleDateString("ru-RU")}</span>
          </div>
          {(app.startDate || app.endDate) && (
            <div className="flex items-center gap-1.5">
              <Calendar size={14} />
              <span>
                {app.startDate ? new Date(app.startDate).toLocaleDateString("ru-RU") : "—"} —{" "}
                {app.endDate ? new Date(app.endDate).toLocaleDateString("ru-RU") : "—"}
              </span>
            </div>
          )}
        </div>
      )}

      <dl className="space-y-2.5 text-sm">
        <InfoRow label="Тема" value={app.subject} />
        <InfoRow label="Тип" value={typeLabel(app.type)} />
        <InfoRow label="Причина" value={app.text} multiline />
        {app.startDate && (
          <InfoRow
            label={app.type === "VACATION" ? "Дата отпуска" : app.type === "SICK_LEAVE" ? "Дата больничного" : "Дата начала"}
            value={
              app.endDate
                ? `${fmtShortDate(app.startDate)} — ${fmtShortDate(app.endDate)}`
                : fmtShortDate(app.startDate)
            }
          />
        )}
        <AttachmentsRow attachments={app.attachments} />
        <InfoRow label="Комментарий" value="—" />
      </dl>

      {isDecision && (
        <div className="mt-5 pt-4 border-t border-border-soft">
          <div className="text-xs text-text-soft uppercase tracking-wide font-medium mb-2">
            Резолюция
          </div>
          <div className="flex items-center gap-2 mb-2">
            {app.status === "APPROVED" ? (
              <span className="inline-flex items-center gap-1.5 px-3 py-1 rounded-md bg-accent-soft text-brand-dark text-xs font-medium">
                <CheckCircle2 size={13} /> Решено · Одобрено
              </span>
            ) : (
              <span className="inline-flex items-center gap-1.5 px-3 py-1 rounded-md bg-red-50 text-danger text-xs font-medium border border-red-200">
                <XCircle size={13} /> Решено · Отклонено
              </span>
            )}
          </div>
          <div className="text-sm text-foreground">
            {app.status === "APPROVED" ? "Заявление одобрено" : "Заявление отклонено"}
            {app.reviewer ? (
              <>
                {" "}
                руководителем отдела {app.reviewer.lastName[0] ?? ""}.{app.reviewer.firstName[0] ?? ""}.{" "}
                {app.reviewer.lastName}
              </>
            ) : null}
            {app.reviewedAt && <> от {fmtShortDate(app.reviewedAt)}</>}
          </div>
          {app.managerComment && (
            <div className="mt-3 rounded-xl border border-border-soft bg-muted/40 p-3 text-sm text-foreground whitespace-pre-wrap">
              {app.managerComment}
            </div>
          )}
        </div>
      )}

      {(canSend || canDelete) && (
        <div className="mt-6 flex flex-wrap gap-2 justify-end">
          {canSend && <SendButton id={app.id} />}
          {canDelete && <DeleteButton id={app.id} />}
        </div>
      )}

      {canReview && (
        <div className="mt-6 pt-6 border-t border-border-soft">
          <div className="text-sm font-medium text-foreground mb-3">Обработка заявления</div>
          <ReviewForm id={app.id} />
        </div>
      )}
    </div>
  );
}

function typeLabelLower(type: string): string {
  const map: Record<string, string> = {
    VACATION: "на отпуск",
    SICK_LEAVE: "на больничный",
    SCHEDULE_CHANGE: "на изменение графика",
    PROFILE_CHANGE: "на изменение данных",
    OTHER: "",
  };
  return map[type] ?? "";
}

function InfoRow({
  label,
  value,
  multiline,
}: {
  label: string;
  value: string;
  multiline?: boolean;
}) {
  return (
    <div className="flex gap-3">
      <dt className="text-text-soft w-28 shrink-0">{label}:</dt>
      <dd
        className={`text-foreground flex-1 min-w-0 ${multiline ? "whitespace-pre-wrap" : ""}`}
      >
        {value}
      </dd>
    </div>
  );
}

function AttachmentsRow({
  attachments,
}: {
  attachments: ApplicationDetailDto["attachments"];
}) {
  if (attachments.length === 0) {
    return <InfoRow label="Вложения" value="—" />;
  }
  return (
    <div className="flex gap-3">
      <dt className="text-text-soft w-28 shrink-0 pt-1">Вложения:</dt>
      <dd className="flex-1 min-w-0 space-y-1.5">
        {attachments.map((att) => (
          <a
            key={att.id}
            href={`/api/attachments/${att.id}`}
            className="flex items-center gap-2 px-3 py-1.5 rounded-lg bg-surface border border-border-soft text-sm hover:bg-muted transition group"
          >
            <Paperclip size={14} className="text-text-soft shrink-0" />
            <span className="flex-1 min-w-0 truncate text-brand group-hover:text-brand-hover">
              {att.filename}
            </span>
            <span className="text-xs text-text-muted shrink-0">{fmtFileSize(att.size)}</span>
            <Download size={14} className="text-text-soft group-hover:text-brand shrink-0" />
          </a>
        ))}
      </dd>
    </div>
  );
}
