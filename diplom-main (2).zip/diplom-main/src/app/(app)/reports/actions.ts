"use server";

import { z } from "zod";
import { revalidatePath } from "next/cache";
import { redirect } from "next/navigation";
import { prisma } from "@/lib/prisma";
import { requireAuth } from "@/lib/auth";
import { REPORT_TYPES } from "@/lib/reports";
import {
  MAX_FILES_PER_REPORT,
  deleteReportFiles,
  isAllowedFile,
  saveReportFile,
} from "@/lib/uploads";

const schema = z.object({
  title: z.string().min(3, { error: "Введите название" }).max(200).trim(),
  type: z.enum(REPORT_TYPES),
  content: z.string().min(5, { error: "Заполните содержимое" }).max(20000).trim(),
  action: z.enum(["save", "send"]),
});

export type ReportFormState =
  | { errors?: Record<string, string[] | undefined>; message?: string }
  | undefined;

export async function createReportAction(
  _prev: ReportFormState,
  formData: FormData,
): Promise<ReportFormState> {
  const { user } = await requireAuth();
  const parsed = schema.safeParse({
    title: formData.get("title"),
    type: formData.get("type"),
    content: formData.get("content"),
    action: formData.get("action") ?? "save",
  });
  if (!parsed.success) return { errors: parsed.error.flatten().fieldErrors };

  // файлы
  const rawFiles = formData.getAll("attachments");
  const files: File[] = rawFiles.filter(
    (f): f is File => f instanceof File && f.size > 0,
  );
  if (files.length > MAX_FILES_PER_REPORT) {
    return { message: `Можно прикрепить не более ${MAX_FILES_PER_REPORT} файлов` };
  }
  for (const f of files) {
    const err = isAllowedFile(f);
    if (err) return { message: err };
  }

  const created = await prisma.report.create({
    data: {
      title: parsed.data.title,
      type: parsed.data.type,
      content: parsed.data.content,
      status: parsed.data.action === "send" ? "IN_REVIEW" : "DRAFT",
      authorId: user.id,
    },
  });

  for (const f of files) {
    const saved = await saveReportFile(created.id, f);
    await prisma.reportAttachment.create({
      data: {
        reportId: created.id,
        filename: f.name,
        url: saved.relativePath,
        size: f.size,
        mimeType: f.type || null,
      },
    });
  }

  revalidatePath("/reports");
  redirect("/reports");
}

export async function submitReportAction(formData: FormData): Promise<void> {
  const { user } = await requireAuth();
  const id = formData.get("id");
  if (typeof id !== "string") return;
  await prisma.report.updateMany({
    where: { id, authorId: user.id, status: "DRAFT" },
    data: { status: "IN_REVIEW" },
  });
  revalidatePath("/reports");
}

export async function approveReportAction(formData: FormData): Promise<void> {
  const { session } = await requireAuth();
  if (session.role !== "MANAGER") return;
  const id = formData.get("id");
  if (typeof id !== "string") return;
  await prisma.report.updateMany({
    where: { id, status: "IN_REVIEW" },
    data: { status: "SUBMITTED" },
  });
  revalidatePath("/reports");
}

export async function deleteReportAction(formData: FormData): Promise<void> {
  const { user, session } = await requireAuth();
  const id = formData.get("id");
  if (typeof id !== "string") return;
  const removed = await prisma.report.deleteMany({
    where: { id, ...(session.role === "MANAGER" ? {} : { authorId: user.id }) },
  });
  if (removed.count > 0) {
    await deleteReportFiles(id).catch(() => {});
  }
  revalidatePath("/reports");
}
