"use client";

import { useTransition } from "react";
import { useRouter } from "next/navigation";
import { Send, Check, Trash2 } from "lucide-react";
import {
  submitReportAction,
  approveReportAction,
  deleteReportAction,
} from "./actions";

type Props = {
  id: string;
  status: string;
  isAuthor: boolean;
  isManager: boolean;
};

export function ReportRowActions({ id, status, isAuthor, isManager }: Props) {
  const router = useRouter();
  const [pending, start] = useTransition();

  const onSubmit = () => {
    const fd = new FormData();
    fd.append("id", id);
    start(async () => {
      await submitReportAction(fd);
      router.refresh();
    });
  };

  const onApprove = () => {
    const fd = new FormData();
    fd.append("id", id);
    start(async () => {
      await approveReportAction(fd);
      router.refresh();
    });
  };

  const onDelete = () => {
    if (!confirm("Удалить отчёт?")) return;
    const fd = new FormData();
    fd.append("id", id);
    start(async () => {
      await deleteReportAction(fd);
      router.refresh();
    });
  };

  const btn = "w-8 h-8 flex items-center justify-center rounded-full hover:bg-muted transition disabled:opacity-50";

  return (
    <>
      {isAuthor && status === "DRAFT" && (
        <button
          onClick={onSubmit}
          disabled={pending}
          className={`${btn} text-info`}
          aria-label="Отправить на проверку"
          title="Отправить на проверку"
        >
          <Send size={14} />
        </button>
      )}
      {isManager && status === "IN_REVIEW" && (
        <button
          onClick={onApprove}
          disabled={pending}
          className={`${btn} text-brand`}
          aria-label="Одобрить"
          title="Одобрить и отправить"
        >
          <Check size={14} />
        </button>
      )}
      {(isAuthor || isManager) && (
        <button
          onClick={onDelete}
          disabled={pending}
          className={`${btn} text-text-soft hover:text-danger`}
          aria-label="Удалить"
          title="Удалить"
        >
          <Trash2 size={14} />
        </button>
      )}
    </>
  );
}
