import Link from "next/link";
import { notFound } from "next/navigation";
import { ArrowLeft, User, Calendar, FileText, Paperclip, Download } from "lucide-react";
import { prisma } from "@/lib/prisma";
import { requireAuth } from "@/lib/auth";
import { PageShell } from "@/components/ui/page-shell";
import { reportStatusLabel, reportStatusBadge } from "@/lib/reports";
import { ReportDetailActions } from "./detail-actions";

function fmtFileSize(bytes: number): string {
  if (bytes < 1024) return `${bytes} Б`;
  if (bytes < 1024 * 1024) return `${(bytes / 1024).toFixed(0)} КБ`;
  return `${(bytes / (1024 * 1024)).toFixed(1)} МБ`;
}

export default async function ReportPage(props: PageProps<"/reports/[id]">) {
  const { user, session } = await requireAuth();
  const { id } = await props.params;
  const isManager = session.role === "MANAGER";

  const report = await prisma.report.findUnique({
    where: { id },
    include: {
      author: { select: { firstName: true, lastName: true, position: true } },
      attachments: { orderBy: { createdAt: "asc" } },
    },
  });
  if (!report) notFound();

  const isAuthor = report.authorId === user.id;
  if (!isAuthor && !isManager) notFound();

  return (
    <div>
      <div className="px-5 md:px-10 pt-6">
        <Link
          href="/reports"
          className="inline-flex items-center gap-1.5 text-sm text-text-soft hover:text-foreground"
        >
          <ArrowLeft size={14} /> К отчётам
        </Link>
      </div>
      <PageShell title={report.title} subtitle={report.type}>
        <div className="flex flex-wrap items-center gap-4 mb-5 text-sm">
          <span
            className={`inline-block px-2.5 py-0.5 text-xs rounded-md font-medium ${reportStatusBadge(report.status)}`}
          >
            {reportStatusLabel(report.status)}
          </span>
          <div className="flex items-center gap-1.5 text-text-soft">
            <User size={14} />
            <span>
              {report.author.lastName} {report.author.firstName}
              {report.author.position && (
                <span className="text-text-muted"> · {report.author.position}</span>
              )}
            </span>
          </div>
          <div className="flex items-center gap-1.5 text-text-soft">
            <Calendar size={14} />
            <span>
              Обновлён{" "}
              {report.updatedAt.toLocaleDateString("ru-RU", {
                day: "numeric",
                month: "long",
                year: "numeric",
              })}
            </span>
          </div>
        </div>

        {report.content ? (
          <div className="rounded-xl bg-surface border border-border-soft p-5 whitespace-pre-wrap text-sm text-foreground leading-relaxed">
            {report.content}
          </div>
        ) : (
          <div className="flex flex-col items-center justify-center py-10 gap-3 text-center">
            <div className="w-14 h-14 rounded-full bg-muted text-text-soft flex items-center justify-center">
              <FileText size={26} />
            </div>
            <div className="text-text-soft text-sm">Отчёт пуст</div>
          </div>
        )}

        {report.attachments.length > 0 && (
          <div className="mt-5">
            <div className="text-xs text-text-soft uppercase tracking-wide font-medium mb-2">
              Вложения ({report.attachments.length})
            </div>
            <ul className="space-y-1.5">
              {report.attachments.map((att) => (
                <li key={att.id}>
                  <a
                    href={`/api/attachments/${att.id}`}
                    className="flex items-center gap-2 px-3 py-2 rounded-xl bg-surface border border-border-soft text-sm hover:bg-muted transition group"
                  >
                    <Paperclip size={14} className="text-text-soft shrink-0" />
                    <span className="flex-1 min-w-0 truncate text-brand group-hover:text-brand-hover">
                      {att.filename}
                    </span>
                    <span className="text-xs text-text-muted shrink-0">
                      {fmtFileSize(att.size)}
                    </span>
                    <Download
                      size={14}
                      className="text-text-soft group-hover:text-brand shrink-0"
                    />
                  </a>
                </li>
              ))}
            </ul>
          </div>
        )}

        <div className="mt-6 flex flex-wrap gap-2 justify-end">
          <ReportDetailActions
            id={report.id}
            status={report.status}
            isAuthor={isAuthor}
            isManager={isManager}
          />
        </div>
      </PageShell>
    </div>
  );
}
