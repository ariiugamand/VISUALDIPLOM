"use client";

import { useTransition } from "react";
import { useRouter } from "next/navigation";
import { Send, Check, Trash2 } from "lucide-react";
import { Button } from "@/components/ui/button";
import {
  submitReportAction,
  approveReportAction,
  deleteReportAction,
} from "../actions";

type Props = {
  id: string;
  status: string;
  isAuthor: boolean;
  isManager: boolean;
};

export function ReportDetailActions({ id, status, isAuthor, isManager }: Props) {
  const router = useRouter();
  const [pending, start] = useTransition();

  const call = (action: (fd: FormData) => Promise<void>) => {
    const fd = new FormData();
    fd.append("id", id);
    start(async () => {
      await action(fd);
      router.refresh();
    });
  };

  return (
    <>
      {isAuthor && status === "DRAFT" && (
        <Button onClick={() => call(submitReportAction)} disabled={pending}>
          <Send size={15} /> Отправить на проверку
        </Button>
      )}
      {isManager && status === "IN_REVIEW" && (
        <Button onClick={() => call(approveReportAction)} disabled={pending}>
          <Check size={15} /> Одобрить
        </Button>
      )}
      {(isAuthor || isManager) && (
        <Button
          variant="secondary"
          onClick={() => {
            if (!confirm("Удалить отчёт?")) return;
            call(deleteReportAction);
            router.push("/reports");
          }}
          disabled={pending}
        >
          <Trash2 size={15} /> Удалить
        </Button>
      )}
    </>
  );
}
