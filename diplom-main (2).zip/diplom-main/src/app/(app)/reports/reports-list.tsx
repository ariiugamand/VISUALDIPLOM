"use client";

import { useMemo, useState } from "react";
import Link from "next/link";
import { FileText, Search } from "lucide-react";
import { Input } from "@/components/ui/input";
import { reportStatusLabel, reportStatusBadge } from "@/lib/reports";
import { ReportRowActions } from "./row-actions";

type ReportItem = {
  id: string;
  title: string;
  type: string;
  status: string;
  authorId: string;
  updatedAt: string;
  author: { firstName: string; lastName: string };
};

type Props = {
  reports: ReportItem[];
  currentUserId: string;
  isManager: boolean;
};

export function ReportsList({ reports, currentUserId, isManager }: Props) {
  const [query, setQuery] = useState("");

  const filtered = useMemo(() => {
    const q = query.trim().toLowerCase();
    if (!q) return reports;
    return reports.filter(
      (r) =>
        r.title.toLowerCase().includes(q) ||
        r.type.toLowerCase().includes(q) ||
        `${r.author.lastName} ${r.author.firstName}`
          .toLowerCase()
          .includes(q),
    );
  }, [reports, query]);

  return (
    <>
      <div className="mb-5">
        <Input
          value={query}
          onChange={(e) => setQuery(e.target.value)}
          placeholder="Поиск по названию, типу или автору"
          leadingIcon={<Search size={16} />}
        />
      </div>

      {filtered.length === 0 ? (
        <div className="flex flex-col items-center justify-center py-14 gap-3 text-center">
          <div className="w-14 h-14 rounded-full bg-accent-soft text-brand-dark flex items-center justify-center">
            <FileText size={26} />
          </div>
          <div className="text-foreground font-medium">
            {reports.length === 0 ? "Отчётов пока нет" : "Ничего не найдено"}
          </div>
        </div>
      ) : (
        <div className="rounded-2xl bg-surface border border-border-soft overflow-hidden">
          <div className="overflow-x-auto">
            <table className="w-full text-sm">
              <thead>
                <tr className="border-b border-border-soft bg-muted/30 text-xs uppercase tracking-wide text-text-soft">
                  <th className="text-left px-4 py-3 font-medium">Название</th>
                  <th className="text-left px-4 py-3 font-medium">Тип</th>
                  {isManager && (
                    <th className="text-left px-4 py-3 font-medium">Автор</th>
                  )}
                  <th className="text-left px-4 py-3 font-medium">Обновлён</th>
                  <th className="text-left px-4 py-3 font-medium">Статус</th>
                  <th className="text-right px-4 py-3 font-medium">Действия</th>
                </tr>
              </thead>
              <tbody>
                {filtered.map((r) => (
                  <tr
                    key={r.id}
                    className="border-b border-border-soft last:border-0 hover:bg-muted/30 cursor-pointer"
                  >
                    <td className="px-4 py-3 font-medium text-foreground">
                      <Link href={`/reports/${r.id}`} className="hover:text-brand">
                        {r.title}
                      </Link>
                    </td>
                    <td className="px-4 py-3 text-text-soft">{r.type}</td>
                    {isManager && (
                      <td className="px-4 py-3 text-text-soft">
                        {r.author.lastName} {r.author.firstName[0]}.
                      </td>
                    )}
                    <td className="px-4 py-3 text-text-soft">
                      {new Date(r.updatedAt).toLocaleDateString("ru-RU")}
                    </td>
                    <td className="px-4 py-3">
                      <span
                        className={`inline-block px-3 py-1 text-xs rounded-md font-medium ${reportStatusBadge(
                          r.status,
                        )}`}
                      >
                        {reportStatusLabel(r.status)}
                      </span>
                    </td>
                    <td className="px-4 py-3">
                      <div className="flex items-center justify-end gap-1">
                        <ReportRowActions
                          id={r.id}
                          status={r.status}
                          isAuthor={r.authorId === currentUserId}
                          isManager={isManager}
                        />
                      </div>
                    </td>
                  </tr>
                ))}
              </tbody>
            </table>
          </div>
        </div>
      )}
    </>
  );
}
