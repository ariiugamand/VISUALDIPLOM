"use client";

import { useActionState, useRef, useState } from "react";
import { Paperclip, Save, Send, X } from "lucide-react";
import { Field } from "@/components/ui/field";
import { Input } from "@/components/ui/input";
import { Select } from "@/components/ui/select";
import { Textarea } from "@/components/ui/textarea";
import { Button } from "@/components/ui/button";
import { REPORT_TYPES } from "@/lib/reports";
import { createReportAction, type ReportFormState } from "../actions";

const MAX_FILES = 10;
const MAX_SIZE = 10 * 1024 * 1024;

function fmtSize(bytes: number): string {
  if (bytes < 1024) return `${bytes} Б`;
  if (bytes < 1024 * 1024) return `${(bytes / 1024).toFixed(0)} КБ`;
  return `${(bytes / (1024 * 1024)).toFixed(1)} МБ`;
}

export function ReportCreateForm() {
  const [state, action, pending] = useActionState<ReportFormState, FormData>(
    createReportAction,
    undefined,
  );
  const [intent, setIntent] = useState<"save" | "send">("save");
  const [files, setFiles] = useState<File[]>([]);
  const [clientError, setClientError] = useState<string | null>(null);
  const fileInputRef = useRef<HTMLInputElement>(null);

  const addFiles = (picked: FileList | null) => {
    if (!picked) return;
    const newOnes: File[] = [];
    for (let i = 0; i < picked.length; i++) {
      const f = picked[i];
      if (f.size > MAX_SIZE) {
        setClientError(`Файл «${f.name}» больше 10 МБ`);
        continue;
      }
      if (files.length + newOnes.length >= MAX_FILES) {
        setClientError(`Можно прикрепить не более ${MAX_FILES} файлов`);
        break;
      }
      if (
        files.some((e) => e.name === f.name && e.size === f.size) ||
        newOnes.some((e) => e.name === f.name && e.size === f.size)
      ) {
        continue;
      }
      newOnes.push(f);
    }
    if (newOnes.length > 0) {
      setFiles((prev) => [...prev, ...newOnes]);
      setClientError(null);
    }
    if (fileInputRef.current) fileInputRef.current.value = "";
  };

  const onSubmit = (e: React.FormEvent<HTMLFormElement>) => {
    if (fileInputRef.current) {
      const dt = new DataTransfer();
      files.forEach((f) => dt.items.add(f));
      fileInputRef.current.files = dt.files;
    }
    void e;
  };

  return (
    <form
      action={action}
      onSubmit={onSubmit}
      className="space-y-4 max-w-2xl mx-auto"
    >
      <input type="hidden" name="action" value={intent} />

      <Field label="Название отчёта" error={state?.errors?.title?.[0]}>
        <Input name="title" required maxLength={200} placeholder="Квартальный отчёт Q1" />
      </Field>

      <Field label="Тип" error={state?.errors?.type?.[0]}>
        <Select name="type" defaultValue={REPORT_TYPES[0]}>
          {REPORT_TYPES.map((t) => (
            <option key={t} value={t}>
              {t}
            </option>
          ))}
        </Select>
      </Field>

      <Field label="Содержимое" error={state?.errors?.content?.[0]}>
        <Textarea
          name="content"
          placeholder="Текст отчёта"
          required
          maxLength={20000}
          className="min-h-[260px]"
        />
      </Field>

      <div>
        <div className="flex items-center justify-between mb-2">
          <span className="text-sm font-medium text-text-soft">
            Вложения{" "}
            <span className="text-xs text-text-muted font-normal">
              (до {MAX_FILES} файлов · до 10 МБ каждый)
            </span>
          </span>
          <Button
            type="button"
            variant="soft"
            size="sm"
            onClick={() => fileInputRef.current?.click()}
            disabled={files.length >= MAX_FILES}
          >
            <Paperclip size={14} /> Прикрепить
          </Button>
        </div>
        <input
          ref={fileInputRef}
          type="file"
          name="attachments"
          multiple
          className="hidden"
          accept="image/*,.pdf,.doc,.docx,.xls,.xlsx,.txt"
          onChange={(e) => addFiles(e.target.files)}
        />
        {files.length > 0 ? (
          <ul className="space-y-1.5">
            {files.map((f, idx) => (
              <li
                key={`${f.name}-${idx}`}
                className="flex items-center gap-2 px-3 py-2 rounded-xl bg-muted/60 border border-border-soft text-sm"
              >
                <Paperclip size={14} className="text-text-soft shrink-0" />
                <span className="flex-1 min-w-0 truncate">{f.name}</span>
                <span className="text-xs text-text-muted">{fmtSize(f.size)}</span>
                <button
                  type="button"
                  onClick={() =>
                    setFiles((prev) => prev.filter((_, i) => i !== idx))
                  }
                  className="w-6 h-6 flex items-center justify-center rounded-full text-text-soft hover:bg-border hover:text-danger transition"
                  aria-label="Убрать"
                >
                  <X size={14} />
                </button>
              </li>
            ))}
          </ul>
        ) : (
          <div className="text-xs text-text-muted px-1">
            Фото, документы, таблицы — всё, что подтверждает данные отчёта
          </div>
        )}
        {clientError && (
          <div className="text-xs text-danger mt-1.5 pl-1">{clientError}</div>
        )}
      </div>

      {state?.message && (
        <div className="rounded-2xl bg-red-50 border border-red-200 px-4 py-3 text-sm text-danger">
          {state.message}
        </div>
      )}

      <div className="flex flex-col sm:flex-row gap-2 justify-center pt-2">
        <Button
          type="submit"
          variant="secondary"
          size="lg"
          disabled={pending}
          onClick={() => setIntent("save")}
        >
          <Save size={16} /> Сохранить
        </Button>
        <Button
          type="submit"
          size="lg"
          disabled={pending}
          onClick={() => setIntent("send")}
        >
          <Send size={16} /> Отправить на проверку
        </Button>
      </div>
    </form>
  );
}
