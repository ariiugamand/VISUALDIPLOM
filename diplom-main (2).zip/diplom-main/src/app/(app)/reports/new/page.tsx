import Link from "next/link";
import { ArrowLeft } from "lucide-react";
import { requireAuth } from "@/lib/auth";
import { PageShell } from "@/components/ui/page-shell";
import { ReportCreateForm } from "./create-form";

export default async function NewReportPage() {
  await requireAuth();
  return (
    <div>
      <div className="px-5 md:px-10 pt-6">
        <Link
          href="/reports"
          className="inline-flex items-center gap-1.5 text-sm text-text-soft hover:text-foreground"
        >
          <ArrowLeft size={14} /> К списку
        </Link>
      </div>
      <PageShell title="Создание отчёта" titleAlign="center">
        <ReportCreateForm />
      </PageShell>
    </div>
  );
}
