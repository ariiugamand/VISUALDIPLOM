import Link from "next/link";
import { Plus } from "lucide-react";
import { prisma } from "@/lib/prisma";
import { requireAuth } from "@/lib/auth";
import { PageShell } from "@/components/ui/page-shell";
import { Button } from "@/components/ui/button";
import { ReportsList } from "./reports-list";

export default async function ReportsPage() {
  const { user, session } = await requireAuth();
  const isManager = session.role === "MANAGER";

  const reports = await prisma.report.findMany({
    where: isManager ? {} : { authorId: user.id },
    include: { author: { select: { firstName: true, lastName: true } } },
    orderBy: [{ updatedAt: "desc" }],
  });

  const stats = {
    total: reports.length,
    DRAFT: reports.filter((r) => r.status === "DRAFT").length,
    IN_REVIEW: reports.filter((r) => r.status === "IN_REVIEW").length,
    SUBMITTED: reports.filter((r) => r.status === "SUBMITTED").length,
  };

  const items = reports.map((r) => ({
    id: r.id,
    title: r.title,
    type: r.type,
    status: r.status,
    authorId: r.authorId,
    updatedAt: r.updatedAt.toISOString(),
    author: r.author,
  }));

  return (
    <PageShell
      title="Отчёты"
      subtitle="Создание, анализ и просмотр отчётов"
      actions={
        <Link href="/reports/new">
          <Button>
            <Plus size={16} /> Создать
          </Button>
        </Link>
      }
    >
      <div className="grid grid-cols-2 md:grid-cols-4 gap-3 mb-6">
        <StatCard label="Всего" value={stats.total} highlight />
        <StatCard label="Подготовлено" value={stats.DRAFT} />
        <StatCard label="На проверке" value={stats.IN_REVIEW} />
        <StatCard label="Отправлено" value={stats.SUBMITTED} />
      </div>

      <ReportsList reports={items} currentUserId={user.id} isManager={isManager} />
    </PageShell>
  );
}

function StatCard({
  label,
  value,
  highlight,
}: {
  label: string;
  value: number;
  highlight?: boolean;
}) {
  return (
    <div
      className={`rounded-2xl p-4 border ${
        highlight
          ? "bg-brand text-white border-brand shadow-[0_4px_12px_-4px_rgb(47_122_92_/_0.3)]"
          : "bg-surface border-border-soft"
      }`}
    >
      <div className={`text-xs ${highlight ? "text-white/80" : "text-text-soft"}`}>
        {label}
      </div>
      <div className={`text-2xl font-bold mt-1 ${highlight ? "" : "text-foreground"}`}>
        {value}
      </div>
    </div>
  );
}
