"use client";

import { useEffect } from "react";
import { incrementViewsAction } from "../actions";

// +1 просмотр
export function ViewTracker({ articleId }: { articleId: string }) {
  useEffect(() => {
    void incrementViewsAction(articleId);
  }, [articleId]);
  return null;
}
