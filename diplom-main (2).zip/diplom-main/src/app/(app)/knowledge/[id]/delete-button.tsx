"use client";

import { useTransition } from "react";
import { Trash2 } from "lucide-react";
import { deleteArticleAction } from "../actions";
import { Button } from "@/components/ui/button";

export function DeleteArticleButton({ id }: { id: string }) {
  const [pending, start] = useTransition();

  return (
    <form
      onSubmit={(e) => {
        e.preventDefault();
        if (!confirm("Удалить статью? Действие необратимо.")) return;
        const fd = new FormData(e.currentTarget);
        start(() => deleteArticleAction(fd));
      }}
    >
      <input type="hidden" name="id" value={id} />
      <Button type="submit" variant="danger" size="sm" disabled={pending}>
        <Trash2 size={14} /> {pending ? "Удаляем…" : "Удалить"}
      </Button>
    </form>
  );
}
