import Link from "next/link";
import { notFound } from "next/navigation";
import { ArrowLeft, Eye, Pencil } from "lucide-react";
import { prisma } from "@/lib/prisma";
import { requireAuth } from "@/lib/auth";
import { PageShell } from "@/components/ui/page-shell";
import { Button } from "@/components/ui/button";
import { DeleteArticleButton } from "./delete-button";
import { ViewTracker } from "./view-tracker";

export default async function ArticlePage(props: PageProps<"/knowledge/[id]">) {
  const { session } = await requireAuth();
  const { id } = await props.params;
  const isManager = session.role === "MANAGER";

  const article = await prisma.knowledgeArticle.findUnique({
    where: { id },
    include: { author: { select: { firstName: true, lastName: true } } },
  });
  if (!article) notFound();

  return (
    <div>
      <ViewTracker articleId={article.id} />
      <div className="px-6 md:px-10 pt-6 flex items-center justify-between">
        <Link
          href="/knowledge"
          className="inline-flex items-center gap-1.5 text-sm text-text-soft hover:text-foreground"
        >
          <ArrowLeft size={14} /> К базе знаний
        </Link>
        {isManager && (
          <div className="flex items-center gap-2">
            <Link href={`/knowledge/${article.id}/edit`}>
              <Button variant="secondary" size="sm">
                <Pencil size={14} /> Редактировать
              </Button>
            </Link>
            <DeleteArticleButton id={article.id} />
          </div>
        )}
      </div>
      <PageShell title={article.title} subtitle={article.category}>
        <div className="flex items-center gap-4 text-xs text-text-soft mb-6">
          <span>
            {article.author.lastName} {article.author.firstName}
          </span>
          <span>·</span>
          <span>Обновлено {article.updatedAt.toLocaleDateString("ru-RU")}</span>
          <span>·</span>
          <span className="flex items-center gap-1">
            <Eye size={12} /> {article.views}
          </span>
        </div>
        <div className="prose prose-sm max-w-none text-foreground whitespace-pre-wrap leading-relaxed">
          {article.content}
        </div>
      </PageShell>
    </div>
  );
}
