import Link from "next/link";
import { notFound } from "next/navigation";
import { ArrowLeft } from "lucide-react";
import { prisma } from "@/lib/prisma";
import { requireRole } from "@/lib/auth";
import { PageShell } from "@/components/ui/page-shell";
import { ArticleForm } from "../../article-form";
import { updateArticleAction } from "../../actions";

export default async function EditArticlePage(props: PageProps<"/knowledge/[id]/edit">) {
  await requireRole("MANAGER");
  const { id } = await props.params;

  const article = await prisma.knowledgeArticle.findUnique({ where: { id } });
  if (!article) notFound();

  return (
    <div>
      <div className="px-6 md:px-10 pt-6">
        <Link
          href={`/knowledge/${id}`}
          className="inline-flex items-center gap-1.5 text-sm text-text-soft hover:text-foreground"
        >
          <ArrowLeft size={14} /> К статье
        </Link>
      </div>
      <PageShell title="Редактирование статьи" titleAlign="center">
        <ArticleForm
          action={updateArticleAction}
          submitLabel="Сохранить"
          initial={{
            id: article.id,
            title: article.title,
            category: article.category,
            excerpt: article.excerpt,
            content: article.content,
          }}
        />
      </PageShell>
    </div>
  );
}
