import Link from "next/link";
import { Plus, BookOpen, Eye } from "lucide-react";
import { prisma } from "@/lib/prisma";
import { requireAuth } from "@/lib/auth";
import { PageShell } from "@/components/ui/page-shell";
import { Button } from "@/components/ui/button";
import { KNOWLEDGE_CATEGORIES } from "@/lib/knowledge";

export default async function KnowledgePage(props: PageProps<"/knowledge">) {
  const { session } = await requireAuth();
  const searchParams = await props.searchParams;
  const categoryRaw =
    typeof searchParams.category === "string" ? searchParams.category : undefined;
  const isManager = session.role === "MANAGER";

  const where = categoryRaw && categoryRaw !== "all" ? { category: categoryRaw } : {};
  const articles = await prisma.knowledgeArticle.findMany({
    where,
    include: { author: { select: { firstName: true, lastName: true } } },
    orderBy: [{ updatedAt: "desc" }],
  });

  return (
    <PageShell
      title="База знаний"
      actions={
        isManager && (
          <Link href="/knowledge/new">
            <Button>
              <Plus size={16} /> Добавить статью
            </Button>
          </Link>
        )
      }
    >
      <div className="flex flex-wrap gap-2 mb-6">
        <Link
          href="/knowledge"
          className={`px-4 py-1.5 rounded-full text-sm transition ${
            !categoryRaw || categoryRaw === "all"
              ? "bg-brand text-white font-medium"
              : "bg-muted text-text-soft hover:bg-border"
          }`}
        >
          Все
        </Link>
        {KNOWLEDGE_CATEGORIES.map((c) => (
          <Link
            key={c}
            href={`/knowledge?category=${encodeURIComponent(c)}`}
            className={`px-4 py-1.5 rounded-full text-sm transition ${
              categoryRaw === c
                ? "bg-brand text-white font-medium"
                : "bg-muted text-text-soft hover:bg-border"
            }`}
          >
            {c}
          </Link>
        ))}
      </div>

      {articles.length === 0 ? (
        <div className="flex flex-col items-center justify-center py-14 gap-3 text-center">
          <div className="w-14 h-14 rounded-full bg-accent-soft text-brand-dark flex items-center justify-center">
            <BookOpen size={26} />
          </div>
          <div className="text-foreground font-medium">Статей пока нет</div>
          {isManager && (
            <Link href="/knowledge/new">
              <Button variant="soft" size="sm">
                <Plus size={14} /> Создать первую
              </Button>
            </Link>
          )}
        </div>
      ) : (
        <div className="grid grid-cols-1 md:grid-cols-2 lg:grid-cols-3 gap-4">
          {articles.map((a) => (
            <Link
              key={a.id}
              href={`/knowledge/${a.id}`}
              className="flex flex-col gap-2 rounded-2xl border border-border-soft bg-surface p-5 hover:shadow-chip hover:-translate-y-0.5 transition"
            >
              <div className="text-xs text-brand font-medium">{a.category}</div>
              <div className="text-base font-semibold text-foreground line-clamp-2">
                {a.title}
              </div>
              <div className="text-sm text-text-soft line-clamp-3 flex-1">{a.excerpt}</div>
              <div className="flex items-center justify-between text-xs text-text-muted pt-2 border-t border-border-soft">
                <span>
                  {a.author.lastName} {a.author.firstName[0]}.
                </span>
                <span className="flex items-center gap-1">
                  <Eye size={12} /> {a.views}
                </span>
              </div>
            </Link>
          ))}
        </div>
      )}
    </PageShell>
  );
}
