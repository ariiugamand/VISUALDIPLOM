"use client";

import { useActionState } from "react";
import { Field } from "@/components/ui/field";
import { Input } from "@/components/ui/input";
import { Select } from "@/components/ui/select";
import { Textarea } from "@/components/ui/textarea";
import { Button } from "@/components/ui/button";
import { KNOWLEDGE_CATEGORIES } from "@/lib/knowledge";
import type { ArticleFormState } from "./actions";

type Props = {
  action: (state: ArticleFormState, formData: FormData) => Promise<ArticleFormState>;
  submitLabel: string;
  initial?: {
    id?: string;
    title?: string;
    category?: string;
    excerpt?: string;
    content?: string;
  };
};

export function ArticleForm({ action, submitLabel, initial }: Props) {
  const [state, formAction, pending] = useActionState<ArticleFormState, FormData>(
    action,
    undefined,
  );

  return (
    <form action={formAction} className="space-y-4 max-w-3xl mx-auto">
      {initial?.id && <input type="hidden" name="id" value={initial.id} />}

      <Field label="Заголовок" error={state?.errors?.title?.[0]}>
        <Input name="title" required defaultValue={initial?.title ?? ""} maxLength={200} />
      </Field>

      <Field label="Категория" error={state?.errors?.category?.[0]}>
        <Select name="category" defaultValue={initial?.category ?? KNOWLEDGE_CATEGORIES[0]}>
          {KNOWLEDGE_CATEGORIES.map((c) => (
            <option key={c} value={c}>
              {c}
            </option>
          ))}
        </Select>
      </Field>

      <Field
        label="Краткое описание"
        hint="Отображается на карточке в списке. Если оставить пустым — возьмётся из текста."
        error={state?.errors?.excerpt?.[0]}
      >
        <Input name="excerpt" defaultValue={initial?.excerpt ?? ""} maxLength={500} />
      </Field>

      <Field label="Содержимое" error={state?.errors?.content?.[0]}>
        <Textarea
          name="content"
          required
          defaultValue={initial?.content ?? ""}
          maxLength={20000}
          className="min-h-[260px]"
        />
      </Field>

      {state?.message && (
        <div className="rounded-2xl bg-red-50 border border-red-200 px-4 py-3 text-sm text-danger">
          {state.message}
        </div>
      )}

      <div className="flex justify-center pt-2">
        <Button type="submit" disabled={pending} size="lg">
          {pending ? "Сохраняем…" : submitLabel}
        </Button>
      </div>
    </form>
  );
}
