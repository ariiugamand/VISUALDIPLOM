"use server";

import { z } from "zod";
import { revalidatePath } from "next/cache";
import { redirect } from "next/navigation";
import { prisma } from "@/lib/prisma";
import { requireAuth, requireRole } from "@/lib/auth";
import { KNOWLEDGE_CATEGORIES } from "@/lib/knowledge";

const schema = z.object({
  title: z.string().min(3, { error: "Введите заголовок" }).max(200).trim(),
  category: z.enum(KNOWLEDGE_CATEGORIES),
  excerpt: z.string().max(500).trim().optional().or(z.literal("")),
  content: z.string().min(10, { error: "Статья слишком короткая" }).max(20000).trim(),
});

export type ArticleFormState =
  | { errors?: Record<string, string[] | undefined>; message?: string }
  | undefined;

export async function createArticleAction(
  _prev: ArticleFormState,
  formData: FormData,
): Promise<ArticleFormState> {
  const { user } = await requireRole("MANAGER");

  const parsed = schema.safeParse({
    title: formData.get("title"),
    category: formData.get("category"),
    excerpt: formData.get("excerpt") ?? "",
    content: formData.get("content"),
  });

  if (!parsed.success) return { errors: parsed.error.flatten().fieldErrors };

  const article = await prisma.knowledgeArticle.create({
    data: {
      title: parsed.data.title,
      category: parsed.data.category,
      excerpt: parsed.data.excerpt || parsed.data.content.slice(0, 200),
      content: parsed.data.content,
      authorId: user.id,
    },
  });

  revalidatePath("/knowledge");
  redirect(`/knowledge/${article.id}`);
}

export async function updateArticleAction(
  _prev: ArticleFormState,
  formData: FormData,
): Promise<ArticleFormState> {
  await requireRole("MANAGER");
  const id = formData.get("id");
  if (typeof id !== "string") return { message: "Некорректный id" };

  const parsed = schema.safeParse({
    title: formData.get("title"),
    category: formData.get("category"),
    excerpt: formData.get("excerpt") ?? "",
    content: formData.get("content"),
  });
  if (!parsed.success) return { errors: parsed.error.flatten().fieldErrors };

  await prisma.knowledgeArticle.update({
    where: { id },
    data: {
      title: parsed.data.title,
      category: parsed.data.category,
      excerpt: parsed.data.excerpt || parsed.data.content.slice(0, 200),
      content: parsed.data.content,
    },
  });

  revalidatePath("/knowledge");
  revalidatePath(`/knowledge/${id}`);
  redirect(`/knowledge/${id}`);
}

export async function deleteArticleAction(formData: FormData): Promise<void> {
  await requireRole("MANAGER");
  const id = formData.get("id");
  if (typeof id !== "string") return;
  await prisma.knowledgeArticle.delete({ where: { id } });
  revalidatePath("/knowledge");
  redirect("/knowledge");
}

export async function incrementViewsAction(articleId: string): Promise<void> {
  await requireAuth();
  await prisma.knowledgeArticle
    .update({
      where: { id: articleId },
      data: { views: { increment: 1 } },
    })
    .catch(() => {});
}
