"use client";

import { useTransition } from "react";
import { useRouter } from "next/navigation";
import { CheckCheck } from "lucide-react";
import { Button } from "@/components/ui/button";
import { markAllReadAction } from "./actions";

export function MarkAllReadButton() {
  const router = useRouter();
  const [pending, start] = useTransition();
  return (
    <Button
      variant="secondary"
      size="sm"
      onClick={() => start(async () => {
        await markAllReadAction();
        router.refresh();
      })}
      disabled={pending}
    >
      <CheckCheck size={14} /> Прочитать все
    </Button>
  );
}
