import { Bell, CheckCheck, Circle } from "lucide-react";
import { prisma } from "@/lib/prisma";
import { requireAuth } from "@/lib/auth";
import { PageShell } from "@/components/ui/page-shell";
import { MarkAllReadButton } from "./mark-buttons";

export default async function NotificationsPage() {
  const { user } = await requireAuth();
  const notifications = await prisma.notification.findMany({
    where: { userId: user.id },
    orderBy: [{ createdAt: "desc" }],
  });
  const hasUnread = notifications.some((n) => n.readAt === null);

  return (
    <PageShell
      title="Уведомления"
      actions={hasUnread ? <MarkAllReadButton /> : undefined}
    >
      {notifications.length === 0 ? (
        <div className="flex flex-col items-center justify-center py-14 gap-3 text-center">
          <div className="w-14 h-14 rounded-full bg-accent-soft text-brand-dark flex items-center justify-center">
            <Bell size={26} />
          </div>
          <div className="text-foreground font-medium">Уведомлений нет</div>
          <p className="text-sm text-text-soft">
            Здесь будут появляться важные события: новые задачи, заявления и мероприятия
          </p>
        </div>
      ) : (
        <div className="space-y-2">
          {notifications.map((n) => {
            const unread = n.readAt === null;
            return (
              <div
                key={n.id}
                className={`flex items-start gap-3 p-4 rounded-xl border ${
                  unread
                    ? "bg-accent-soft/20 border-accent-soft"
                    : "bg-surface border-border-soft"
                }`}
              >
                <div className="mt-0.5 shrink-0">
                  {unread ? (
                    <Circle size={10} className="text-brand fill-brand" />
                  ) : (
                    <CheckCheck size={14} className="text-text-muted" />
                  )}
                </div>
                <div className="flex-1 min-w-0">
                  <div className="font-medium text-foreground">{n.title}</div>
                  {n.body && (
                    <div className="text-sm text-text-soft mt-0.5">{n.body}</div>
                  )}
                  <div className="text-xs text-text-muted mt-1">
                    {n.createdAt.toLocaleString("ru-RU")}
                  </div>
                </div>
              </div>
            );
          })}
        </div>
      )}
    </PageShell>
  );
}
