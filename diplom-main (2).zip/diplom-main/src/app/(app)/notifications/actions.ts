"use server";

import { revalidatePath } from "next/cache";
import { prisma } from "@/lib/prisma";
import { requireAuth } from "@/lib/auth";

export async function markAllReadAction(): Promise<void> {
  const { user } = await requireAuth();
  await prisma.notification.updateMany({
    where: { userId: user.id, readAt: null },
    data: { readAt: new Date() },
  });
  revalidatePath("/notifications");
}

export async function markReadAction(formData: FormData): Promise<void> {
  const { user } = await requireAuth();
  const id = formData.get("id");
  if (typeof id !== "string") return;
  await prisma.notification.updateMany({
    where: { id, userId: user.id },
    data: { readAt: new Date() },
  });
  revalidatePath("/notifications");
}
