"use server";

import { z } from "zod";
import { revalidatePath } from "next/cache";
import { redirect } from "next/navigation";
import { prisma } from "@/lib/prisma";
import { requireAuth, requireRole } from "@/lib/auth";
import {
  MAX_FILES_PER_TASK,
  deleteTaskFiles,
  isAllowedFile,
  saveTaskFile,
} from "@/lib/uploads";

const createSchema = z.object({
  title: z.string().min(3, { error: "Введите название" }).max(200).trim(),
  description: z.string().max(2000).trim().optional().or(z.literal("")),
  goal: z.string().max(500).trim().optional().or(z.literal("")),
  assigneeId: z.string().min(1, { error: "Выберите исполнителя" }),
  deadline: z.string().optional().or(z.literal("")),
});

export type TaskFormState =
  | { errors?: Record<string, string[] | undefined>; message?: string }
  | undefined;

export async function createTaskAction(
  _prev: TaskFormState,
  formData: FormData,
): Promise<TaskFormState> {
  const { user } = await requireRole("MANAGER");
  const parsed = createSchema.safeParse({
    title: formData.get("title"),
    description: formData.get("description") ?? "",
    goal: formData.get("goal") ?? "",
    assigneeId: formData.get("assigneeId"),
    deadline: formData.get("deadline") ?? "",
  });
  if (!parsed.success) return { errors: parsed.error.flatten().fieldErrors };

  const assignee = await prisma.user.findUnique({
    where: { id: parsed.data.assigneeId },
    select: { id: true },
  });
  if (!assignee) return { message: "Исполнитель не найден" };

  await prisma.task.create({
    data: {
      title: parsed.data.title,
      description: parsed.data.description || null,
      goal: parsed.data.goal || null,
      createdById: user.id,
      assigneeId: parsed.data.assigneeId,
      deadline: parsed.data.deadline ? new Date(parsed.data.deadline) : null,
      status: "TODO",
      progress: 0,
    },
  });
  revalidatePath("/tasks");
  redirect("/tasks");
}

export async function deleteTaskAction(formData: FormData): Promise<void> {
  await requireRole("MANAGER");
  const id = formData.get("id");
  if (typeof id !== "string") return;
  await prisma.task.delete({ where: { id } });
  await deleteTaskFiles(id).catch(() => {});
  revalidatePath("/tasks");
}

const COMPLETION_TYPES = ["FULL", "PARTIAL", "BLOCKED"] as const;

const submitCompletionSchema = z.object({
  taskId: z.string().min(1, { error: "Выберите задачу" }),
  completionType: z.enum(COMPLETION_TYPES, { error: "Выберите тип" }),
  progress: z.coerce.number().int().min(0).max(100).optional(),
  comment: z.string().max(2000).trim().optional().or(z.literal("")),
});

export type SubmitCompletionState =
  | { errors?: Record<string, string[] | undefined>; message?: string; ok?: boolean }
  | undefined;

export async function submitTaskCompletionAction(
  _prev: SubmitCompletionState,
  formData: FormData,
): Promise<SubmitCompletionState> {
  const { user } = await requireAuth();

  const parsed = submitCompletionSchema.safeParse({
    taskId: formData.get("taskId"),
    completionType: formData.get("completionType"),
    progress: formData.get("progress") ?? undefined,
    comment: formData.get("comment") ?? "",
  });
  if (!parsed.success) {
    return { errors: parsed.error.flatten().fieldErrors };
  }

  const task = await prisma.task.findUnique({
    where: { id: parsed.data.taskId },
    select: { id: true, assigneeId: true, status: true },
  });
  if (!task) return { message: "Задача не найдена" };
  if (task.assigneeId !== user.id) return { message: "Это не ваша задача" };
  if (task.status === "DONE") return { message: "Задача уже выполнена" };

  // файлы
  const rawFiles = formData.getAll("attachments");
  const files: File[] = rawFiles.filter(
    (f): f is File => f instanceof File && f.size > 0,
  );
  if (files.length > MAX_FILES_PER_TASK) {
    return { message: `Можно прикрепить не более ${MAX_FILES_PER_TASK} файлов` };
  }
  for (const f of files) {
    const err = isAllowedFile(f);
    if (err) return { message: err };
  }

  // прогресс
  const fallback =
    parsed.data.completionType === "FULL"
      ? 100
      : parsed.data.completionType === "PARTIAL"
        ? 50
        : 0;
  const progress =
    typeof parsed.data.progress === "number" ? parsed.data.progress : fallback;
  const status =
    progress >= 100 ? "DONE" : progress > 0 ? "IN_PROGRESS" : "TODO";

  const typeLabel =
    parsed.data.completionType === "FULL"
      ? "Выполнено полностью"
      : parsed.data.completionType === "PARTIAL"
        ? "Выполнено частично"
        : "Не смог выполнить";
  const resultText = parsed.data.comment
    ? `${typeLabel}. ${parsed.data.comment}`
    : typeLabel;

  await prisma.task.update({
    where: { id: task.id },
    data: {
      progress,
      status,
      result: resultText,
      completedAt: progress >= 100 ? new Date() : null,
    },
  });

  for (const f of files) {
    const saved = await saveTaskFile(task.id, f);
    await prisma.taskAttachment.create({
      data: {
        taskId: task.id,
        filename: f.name,
        url: saved.relativePath,
        size: f.size,
        mimeType: f.type || null,
      },
    });
  }

  revalidatePath("/tasks");
  return { ok: true };
}

const progressSchema = z.object({
  id: z.string().min(1),
  progress: z.coerce.number().int().min(0).max(100),
  result: z.string().max(2000).trim().optional().or(z.literal("")),
});

export async function updateProgressAction(
  _prev: TaskFormState,
  formData: FormData,
): Promise<TaskFormState> {
  const { user } = await requireAuth();
  const parsed = progressSchema.safeParse({
    id: formData.get("id"),
    progress: formData.get("progress"),
    result: formData.get("result") ?? "",
  });
  if (!parsed.success) return { errors: parsed.error.flatten().fieldErrors };

  const task = await prisma.task.findUnique({ where: { id: parsed.data.id } });
  if (!task) return { message: "Задача не найдена" };
  if (task.assigneeId !== user.id) return { message: "Это не ваша задача" };

  const progress = parsed.data.progress;
  const status = progress >= 100 ? "DONE" : progress > 0 ? "IN_PROGRESS" : "TODO";

  await prisma.task.update({
    where: { id: parsed.data.id },
    data: {
      progress,
      status,
      result: parsed.data.result || null,
      completedAt: progress >= 100 ? new Date() : null,
    },
  });
  revalidatePath("/tasks");
  return undefined;
}
