import Link from "next/link";
import { Plus, CheckCircle2 } from "lucide-react";
import { prisma } from "@/lib/prisma";
import { requireAuth } from "@/lib/auth";
import { PageShell } from "@/components/ui/page-shell";
import { Button } from "@/components/ui/button";
import { TaskCard } from "./task-card";
import { SubmitCompletionButton } from "./submit-completion-button";

export default async function TasksPage() {
  const { user, session } = await requireAuth();
  const isManager = session.role === "MANAGER";

  const tasks = await prisma.task.findMany({
    where: isManager ? {} : { assigneeId: user.id },
    include: { assignee: { select: { firstName: true, lastName: true } } },
    orderBy: [{ status: "asc" }, { deadline: "asc" }, { createdAt: "desc" }],
  });

  const total = tasks.length;
  const done = tasks.filter((t) => t.status === "DONE").length;
  const totalProgress = total === 0 ? 0 : Math.round((done / total) * 100);

  const openTasks = tasks
    .map((t, i) => ({ ...t, index: i + 1 }))
    .filter((t) => t.assigneeId === user.id && t.status !== "DONE")
    .map((t) => ({
      id: t.id,
      title: t.title,
      index: t.index,
      progress: t.progress,
    }));

  return (
    <PageShell
      title="Задачи"
      subtitle={
        total > 0 ? (
          <>
            Общий процент выполнения:{" "}
            <span className="text-brand font-semibold">{totalProgress}%</span>
          </>
        ) : undefined
      }
      actions={
        isManager ? (
          <Link href="/tasks/new">
            <Button>
              <Plus size={16} /> Создать задачу
            </Button>
          </Link>
        ) : undefined
      }
    >
      {tasks.length === 0 ? (
        <div className="flex flex-col items-center justify-center py-14 gap-3 text-center">
          <div className="w-14 h-14 rounded-full bg-accent-soft text-brand-dark flex items-center justify-center">
            <CheckCircle2 size={26} />
          </div>
          <div className="text-foreground font-medium">
            {isManager ? "Задач пока нет" : "У вас нет активных задач"}
          </div>
        </div>
      ) : (
        <>
          <div className="space-y-3">
            {tasks.map((t, i) => (
              <TaskCard
                key={t.id}
                task={{
                  id: t.id,
                  index: i + 1,
                  title: t.title,
                  description: t.description,
                  goal: t.goal,
                  progress: t.progress,
                  status: t.status,
                  deadline: t.deadline?.toISOString() ?? null,
                  assigneeName: t.assignee
                    ? `${t.assignee.lastName} ${t.assignee.firstName}`
                    : null,
                  result: t.result,
                }}
                isManager={isManager}
              />
            ))}
          </div>
          {!isManager && <SubmitCompletionButton tasks={openTasks} />}
        </>
      )}
    </PageShell>
  );
}
