import Link from "next/link";
import { ArrowLeft } from "lucide-react";
import { prisma } from "@/lib/prisma";
import { requireRole } from "@/lib/auth";
import { PageShell } from "@/components/ui/page-shell";
import { TaskCreateForm } from "./create-form";

export default async function NewTaskPage() {
  await requireRole("MANAGER");
  const employees = await prisma.user.findMany({
    where: { role: "EMPLOYEE", status: "ACTIVE" },
    orderBy: [{ lastName: "asc" }],
    select: { id: true, firstName: true, lastName: true, position: true },
  });

  return (
    <div>
      <div className="px-5 md:px-10 pt-6">
        <Link
          href="/tasks"
          className="inline-flex items-center gap-1.5 text-sm text-text-soft hover:text-foreground"
        >
          <ArrowLeft size={14} /> К задачам
        </Link>
      </div>
      <PageShell title="Создание задачи" titleAlign="center">
        <TaskCreateForm
          employees={employees.map((e) => ({
            id: e.id,
            name: `${e.lastName} ${e.firstName}${e.position ? ` · ${e.position}` : ""}`,
          }))}
        />
      </PageShell>
    </div>
  );
}
