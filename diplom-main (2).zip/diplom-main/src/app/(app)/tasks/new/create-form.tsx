"use client";

import { useActionState } from "react";
import { Field } from "@/components/ui/field";
import { Input } from "@/components/ui/input";
import { Select } from "@/components/ui/select";
import { Textarea } from "@/components/ui/textarea";
import { Button } from "@/components/ui/button";
import { createTaskAction, type TaskFormState } from "../actions";

type Employee = { id: string; name: string };

export function TaskCreateForm({ employees }: { employees: Employee[] }) {
  const [state, action, pending] = useActionState<TaskFormState, FormData>(
    createTaskAction,
    undefined,
  );

  return (
    <form action={action} className="space-y-4 max-w-2xl mx-auto">
      <Field label="Название задачи" error={state?.errors?.title?.[0]}>
        <Input name="title" required maxLength={200} placeholder="Подготовить отчёт" />
      </Field>
      <Field label="Описание" error={state?.errors?.description?.[0]}>
        <Textarea name="description" placeholder="Что нужно сделать" />
      </Field>
      <Field label="Цель (опционально)" error={state?.errors?.goal?.[0]}>
        <Input name="goal" maxLength={500} placeholder="Ожидаемый результат" />
      </Field>
      <div className="grid grid-cols-1 sm:grid-cols-2 gap-3">
        <Field label="Исполнитель" error={state?.errors?.assigneeId?.[0]}>
          <Select name="assigneeId" required defaultValue="">
            <option value="" disabled>
              Выберите сотрудника
            </option>
            {employees.map((e) => (
              <option key={e.id} value={e.id}>
                {e.name}
              </option>
            ))}
          </Select>
        </Field>
        <Field label="Дедлайн" error={state?.errors?.deadline?.[0]}>
          <Input name="deadline" type="date" />
        </Field>
      </div>
      {state?.message && (
        <div className="rounded-2xl bg-red-50 border border-red-200 px-4 py-3 text-sm text-danger">
          {state.message}
        </div>
      )}
      <div className="flex justify-center pt-2">
        <Button type="submit" size="lg" disabled={pending}>
          {pending ? "Создаём…" : "Создать задачу"}
        </Button>
      </div>
    </form>
  );
}
