"use client";

import { useTransition } from "react";
import { useRouter } from "next/navigation";
import { CheckCircle2, Trash2, Target, User } from "lucide-react";
import { Button } from "@/components/ui/button";
import { deleteTaskAction } from "./actions";

type TaskDto = {
  id: string;
  index: number;
  title: string;
  description: string | null;
  goal: string | null;
  progress: number;
  status: string;
  deadline: string | null;
  assigneeName: string | null;
  result: string | null;
};

type Props = {
  task: TaskDto;
  isManager: boolean;
};

export function TaskCard({ task, isManager }: Props) {
  const router = useRouter();
  const [deletePending, startDelete] = useTransition();

  const onDelete = () => {
    if (!confirm("Удалить задачу?")) return;
    const fd = new FormData();
    fd.append("id", task.id);
    startDelete(async () => {
      await deleteTaskAction(fd);
      router.refresh();
    });
  };

  const deadlineText = task.deadline
    ? new Date(task.deadline).toLocaleDateString("ru-RU", {
        day: "numeric",
        month: "long",
      })
    : null;

  const isDone = task.status === "DONE";

  return (
    <div className="rounded-2xl bg-surface border border-border-soft p-5 hover:shadow-chip transition">
      <div className="flex items-start gap-3 mb-3">
        <div className="flex-1 min-w-0">
          <div className="flex items-center justify-between gap-3 mb-1">
            <div className="font-semibold text-foreground">
              Задача №{task.index}: {task.title}
            </div>
            {deadlineText && (
              <div className="text-sm text-text-soft shrink-0">{deadlineText}</div>
            )}
          </div>
          {task.description && (
            <div className="text-sm text-text-soft">{task.description}</div>
          )}
          {task.goal && (
            <div className="flex items-center gap-1.5 text-sm text-text-soft mt-1">
              <Target size={14} />
              <span>Цель: {task.goal}</span>
            </div>
          )}
          {isManager && task.assigneeName && (
            <div className="flex items-center gap-1.5 text-sm text-text-soft mt-1">
              <User size={14} />
              <span>{task.assigneeName}</span>
            </div>
          )}
          {task.result && (
            <div className="mt-2 text-xs text-text-muted italic">
              Отчёт: {task.result}
            </div>
          )}
        </div>
      </div>
      <div className="flex items-center gap-3">
        <div className="flex items-center gap-2 text-sm text-text-soft">Прогресс</div>
        <div className="flex-1 h-2 bg-muted rounded-full overflow-hidden">
          <div
            className="h-full bg-brand rounded-full transition-all"
            style={{ width: `${task.progress}%` }}
          />
        </div>
        <div className="text-sm font-semibold text-foreground w-12 text-right">
          {task.progress}%
        </div>
      </div>
      {(isDone || isManager) && (
        <div className="mt-4 flex items-center justify-end gap-2">
          {isDone && (
            <span className="inline-flex items-center gap-1.5 text-sm text-brand-dark font-medium">
              <CheckCircle2 size={15} /> Выполнено
            </span>
          )}
          {isManager && (
            <Button
              variant="secondary"
              size="sm"
              onClick={onDelete}
              disabled={deletePending}
            >
              <Trash2 size={14} /> Удалить
            </Button>
          )}
        </div>
      )}
    </div>
  );
}
