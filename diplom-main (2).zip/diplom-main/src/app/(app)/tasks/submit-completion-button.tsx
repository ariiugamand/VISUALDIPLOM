"use client";

import { useActionState, useEffect, useRef, useState } from "react";
import { useRouter } from "next/navigation";
import { CheckCircle2, Paperclip, X } from "lucide-react";
import { Button } from "@/components/ui/button";
import { Modal } from "@/components/ui/modal";
import { Field } from "@/components/ui/field";
import { Select } from "@/components/ui/select";
import { Textarea } from "@/components/ui/textarea";
import {
  submitTaskCompletionAction,
  type SubmitCompletionState,
} from "./actions";

const MAX_FILES = 3;
const MAX_SIZE = 10 * 1024 * 1024;

function fmtSize(bytes: number): string {
  if (bytes < 1024) return `${bytes} Б`;
  if (bytes < 1024 * 1024) return `${(bytes / 1024).toFixed(0)} КБ`;
  return `${(bytes / (1024 * 1024)).toFixed(1)} МБ`;
}

type TaskOpt = { id: string; title: string; index: number; progress: number };

function typeFromProgress(p: number): string {
  if (p >= 100) return "FULL";
  if (p <= 0) return "BLOCKED";
  return "PARTIAL";
}

type Props = {
  tasks: TaskOpt[];
};

export function SubmitCompletionButton({ tasks }: Props) {
  const router = useRouter();
  const [open, setOpen] = useState(false);
  const [state, action, pending] = useActionState<SubmitCompletionState, FormData>(
    submitTaskCompletionAction,
    undefined,
  );
  const initialTask = tasks[0];
  const initialProgress = initialTask?.progress ?? 0;

  const [taskId, setTaskId] = useState<string>(initialTask?.id ?? "");
  const [completionType, setCompletionType] = useState<string>(
    typeFromProgress(initialProgress),
  );
  const [progress, setProgress] = useState<number>(initialProgress);
  const [files, setFiles] = useState<File[]>([]);
  const [clientError, setClientError] = useState<string | null>(null);
  const fileInputRef = useRef<HTMLInputElement>(null);

  const currentTask = tasks.find((t) => t.id === taskId) ?? initialTask;
  const currentSavedProgress = currentTask?.progress ?? 0;

  const onTaskChange = (value: string) => {
    setTaskId(value);
    // из задачи
    const t = tasks.find((x) => x.id === value);
    const p = t?.progress ?? 0;
    setProgress(p);
    setCompletionType(typeFromProgress(p));
  };

  const onTypeChange = (value: string) => {
    setCompletionType(value);
    // автоподстановка
    if (value === "FULL") setProgress(100);
    else if (value === "PARTIAL") {
      // частичный
      setProgress((p) => (p > 0 && p < 100 ? p : 50));
    } else if (value === "BLOCKED") setProgress(0);
  };

  const onProgressChange = (value: number) => {
    setProgress(value);
    // синк типа
    if (value >= 100) setCompletionType("FULL");
    else if (value <= 0) setCompletionType("BLOCKED");
    else setCompletionType("PARTIAL");
  };

  // закрытие
  useEffect(() => {
    if (state?.ok) {
      setOpen(false);
      setFiles([]);
      setClientError(null);
      router.refresh();
    }
  }, [state, router]);

  // дефолт
  useEffect(() => {
    if (open && !taskId && tasks.length > 0) {
      setTaskId(tasks[0].id);
    }
  }, [open, taskId, tasks]);

  if (tasks.length === 0) return null;

  const addFiles = (picked: FileList | null) => {
    if (!picked) return;
    const newOnes: File[] = [];
    for (let i = 0; i < picked.length; i++) {
      const f = picked[i];
      if (f.size > MAX_SIZE) {
        setClientError(`Файл «${f.name}» больше 10 МБ`);
        continue;
      }
      if (files.length + newOnes.length >= MAX_FILES) {
        setClientError(`Можно прикрепить не более ${MAX_FILES} файлов`);
        break;
      }
      if (
        files.some((e) => e.name === f.name && e.size === f.size) ||
        newOnes.some((e) => e.name === f.name && e.size === f.size)
      ) {
        continue;
      }
      newOnes.push(f);
    }
    if (newOnes.length > 0) {
      setFiles((prev) => [...prev, ...newOnes]);
      setClientError(null);
    }
    if (fileInputRef.current) fileInputRef.current.value = "";
  };

  const onSubmit = (e: React.FormEvent<HTMLFormElement>) => {
    // синк
    if (fileInputRef.current) {
      const dt = new DataTransfer();
      files.forEach((f) => dt.items.add(f));
      fileInputRef.current.files = dt.files;
    }
    void e;
  };

  return (
    <>
      <div className="mt-6 flex justify-center">
        <Button onClick={() => setOpen(true)} size="lg">
          <CheckCircle2 size={16} /> Отметить выполнение
        </Button>
      </div>

      <Modal open={open} onClose={() => setOpen(false)} maxWidth="max-w-md">
        <form action={action} onSubmit={onSubmit} className="p-6 space-y-4">
          <h2 className="text-xl font-semibold text-foreground text-center">
            Выполнение задачи
          </h2>

          <Field label="Задача" error={state?.errors?.taskId?.[0]}>
            <Select
              name="taskId"
              value={taskId}
              onChange={(e) => onTaskChange(e.target.value)}
            >
              {tasks.map((t) => (
                <option key={t.id} value={t.id}>
                  №{t.index}: {t.title}
                </option>
              ))}
            </Select>
          </Field>

          <Field label="Тип" error={state?.errors?.completionType?.[0]}>
            <Select
              name="completionType"
              value={completionType}
              onChange={(e) => onTypeChange(e.target.value)}
            >
              <option value="FULL">Выполнено полностью</option>
              <option value="PARTIAL">Выполнено частично</option>
              <option value="BLOCKED">Не смог выполнить</option>
            </Select>
          </Field>

          <Field
            label={`Прогресс: ${progress}%${
              progress !== currentSavedProgress
                ? ` (сейчас ${currentSavedProgress}%)`
                : ""
            }`}
            error={state?.errors?.progress?.[0]}
          >
            <div className="flex items-center gap-3">
              <input
                type="range"
                name="progress"
                min={0}
                max={100}
                step={5}
                value={progress}
                onChange={(e) => onProgressChange(Number(e.target.value))}
                className="flex-1 accent-brand"
              />
              <div className="w-12 text-right text-sm font-semibold text-foreground">
                {progress}%
              </div>
            </div>
            {progress < currentSavedProgress && (
              <div className="mt-1 text-xs text-warning">
                Новое значение ниже текущего — прогресс будет уменьшен
              </div>
            )}
          </Field>

          <Field label="Комментарий" error={state?.errors?.comment?.[0]}>
            <Textarea
              name="comment"
              placeholder="Опишите коротко, что сделано"
              maxLength={2000}
            />
          </Field>

          <div>
            <div className="flex items-center justify-between mb-2">
              <span className="text-sm font-medium text-text-soft">Вложение</span>
            </div>
            <button
              type="button"
              onClick={() => fileInputRef.current?.click()}
              disabled={files.length >= MAX_FILES}
              className="w-full flex items-center justify-center gap-2 py-3 rounded-xl bg-accent-soft/60 text-brand-dark text-sm font-medium hover:bg-accent-soft transition disabled:opacity-50 disabled:cursor-not-allowed"
            >
              <Paperclip size={16} /> Выбрать файл
            </button>
            <input
              ref={fileInputRef}
              type="file"
              name="attachments"
              multiple
              className="hidden"
              accept="image/*,.pdf,.doc,.docx,.xls,.xlsx,.txt"
              onChange={(e) => addFiles(e.target.files)}
            />
            {files.length > 0 && (
              <ul className="mt-2 space-y-1.5">
                {files.map((f, idx) => (
                  <li
                    key={`${f.name}-${idx}`}
                    className="flex items-center gap-2 px-3 py-2 rounded-xl bg-muted/60 border border-border-soft text-sm"
                  >
                    <Paperclip size={14} className="text-text-soft shrink-0" />
                    <span className="flex-1 min-w-0 truncate">{f.name}</span>
                    <span className="text-xs text-text-muted">{fmtSize(f.size)}</span>
                    <button
                      type="button"
                      onClick={() =>
                        setFiles((prev) => prev.filter((_, i) => i !== idx))
                      }
                      className="w-6 h-6 flex items-center justify-center rounded-full text-text-soft hover:bg-border hover:text-danger transition"
                      aria-label="Убрать"
                    >
                      <X size={14} />
                    </button>
                  </li>
                ))}
              </ul>
            )}
            {clientError && (
              <div className="text-xs text-danger mt-1.5 pl-1">{clientError}</div>
            )}
          </div>

          {state?.message && (
            <div className="rounded-2xl bg-red-50 border border-red-200 px-4 py-3 text-sm text-danger">
              {state.message}
            </div>
          )}

          <div className="flex justify-center pt-1">
            <Button type="submit" size="lg" disabled={pending}>
              {pending ? "Отправляем…" : "Отправить"}
            </Button>
          </div>

          <div className="text-xs text-text-muted text-center">
            *задача отметится после проверки руководителем
          </div>
        </form>
      </Modal>
    </>
  );
}
