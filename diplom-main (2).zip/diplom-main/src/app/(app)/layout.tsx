import { requireAuth } from "@/lib/auth";
import { prisma } from "@/lib/prisma";
import { Topbar } from "@/components/nav/topbar";
import { MobileTabBar } from "@/components/nav/mobile-tabbar";

export default async function AppLayout({ children }: { children: React.ReactNode }) {
  const { user, session } = await requireAuth();

  const unreadCount = await prisma.notification.count({
    where: { userId: user.id, readAt: null },
  });

  return (
    <div className="flex flex-col h-screen">
      <Topbar
        firstName={user.firstName}
        lastName={user.lastName}
        position={user.position}
        role={session.role}
        unreadCount={unreadCount}
      />
      <main className="flex-1 overflow-y-auto bg-background pb-16 md:pb-0">
        {children}
      </main>
      <MobileTabBar role={session.role} />
    </div>
  );
}
