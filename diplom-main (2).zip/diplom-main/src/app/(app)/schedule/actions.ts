"use server";

import { revalidatePath } from "next/cache";
import { prisma } from "@/lib/prisma";
import { requireRole } from "@/lib/auth";
import type { ShiftType } from "@/lib/schedule";

type EntryInput = { userId: string; date: string; shiftType: ShiftType | "CLEAR" };

export async function saveScheduleAction(
  entries: EntryInput[],
): Promise<{ ok: boolean; message?: string }> {
  await requireRole("MANAGER");

  for (const e of entries) {
    const date = new Date(e.date);
    if (Number.isNaN(date.getTime())) continue;
    if (e.shiftType === "CLEAR") {
      await prisma.scheduleEntry
        .delete({ where: { userId_date: { userId: e.userId, date } } })
        .catch(() => {});
      continue;
    }
    await prisma.scheduleEntry.upsert({
      where: { userId_date: { userId: e.userId, date } },
      update: { shiftType: e.shiftType },
      create: { userId: e.userId, date, shiftType: e.shiftType },
    });
  }

  revalidatePath("/schedule");
  revalidatePath("/schedule/edit");
  return { ok: true };
}

export async function generateMonthWorkdaysAction(
  year: number,
  month: number,
): Promise<{ ok: boolean; message?: string }> {
  await requireRole("MANAGER");

  const users = await prisma.user.findMany({
    where: { role: "EMPLOYEE", status: "ACTIVE" },
    select: { id: true },
  });

  const days = new Date(year, month + 1, 0).getDate();
  const ops: Promise<unknown>[] = [];
  for (const u of users) {
    for (let d = 1; d <= days; d++) {
      const date = new Date(year, month, d);
      const wd = date.getDay();
      const shiftType = wd === 0 || wd === 6 ? "WEEKEND" : "WORK";
      ops.push(
        prisma.scheduleEntry.upsert({
          where: { userId_date: { userId: u.id, date } },
          update: { shiftType },
          create: { userId: u.id, date, shiftType },
        }),
      );
    }
  }
  await Promise.all(ops);

  revalidatePath("/schedule");
  revalidatePath("/schedule/edit");
  return { ok: true };
}
