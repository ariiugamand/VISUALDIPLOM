"use client";

import { useMemo, useState } from "react";
import Link from "next/link";
import { useRouter } from "next/navigation";
import { Calendar, Star, Clock, Coffee, AlertCircle, Pencil } from "lucide-react";
import {
  MONTHS_RU,
  SHIFT_TYPES,
  WEEKDAYS_RU,
  daysInMonth,
  weekdayIndex,
  shiftTypeInfo,
} from "@/lib/schedule";
import { Modal } from "@/components/ui/modal";
import { Button } from "@/components/ui/button";

type EntryDto = {
  date: string;
  shiftType: string;
  shiftStart?: string | null;
  shiftEnd?: string | null;
  breakStart?: string | null;
  breakEnd?: string | null;
  note?: string | null;
};

type EventDto = {
  id: string;
  title: string;
  startsAt: string;
  importance: string;
};

type Props = {
  entries: EntryDto[];
  events: EventDto[];
  year: number;
  month: number;
};

function fmtTime(s: string): string {
  const d = new Date(s);
  return d.toLocaleTimeString("ru-RU", { hour: "2-digit", minute: "2-digit" });
}

function calcHours(start?: string | null, end?: string | null): string | null {
  if (!start || !end) return null;
  const [sh, sm] = start.split(":").map(Number);
  const [eh, em] = end.split(":").map(Number);
  const mins = eh * 60 + em - (sh * 60 + sm);
  if (mins <= 0) return null;
  const h = Math.floor(mins / 60);
  const m = mins % 60;
  return m === 0 ? `${h} ч` : `${h} ч ${m} мин`;
}

export function EmployeeSchedule({ entries, events, year, month }: Props) {
  const router = useRouter();
  const days = daysInMonth(year, month);
  const [activeDay, setActiveDay] = useState<number | null>(null);

  const entryByDay = useMemo(() => {
    const m = new Map<number, EntryDto>();
    for (const e of entries) m.set(new Date(e.date).getDate(), e);
    return m;
  }, [entries]);

  const eventsByDay = useMemo(() => {
    const m = new Map<number, EventDto[]>();
    for (const ev of events) {
      const d = new Date(ev.startsAt).getDate();
      const arr = m.get(d) ?? [];
      arr.push(ev);
      m.set(d, arr);
    }
    return m;
  }, [events]);

  const firstDayOffset = weekdayIndex(new Date(year, month, 1));
  const totalCells = firstDayOffset + days;
  const rows = Math.ceil(totalCells / 7);

  const today = new Date();
  const isCurrentMonth = today.getFullYear() === year && today.getMonth() === month;
  const todayEvents = isCurrentMonth
    ? (eventsByDay.get(today.getDate()) ?? [])
    : [];

  const stats = useMemo(() => {
    const counts: Record<string, number> = {};
    for (const e of entries) counts[e.shiftType] = (counts[e.shiftType] ?? 0) + 1;
    return counts;
  }, [entries]);
  const workCount = stats.WORK ?? 0;
  const vacationCount = (stats.VACATION ?? 0) + (stats.WEEKEND ?? 0);
  const sickCount = stats.SICK ?? 0;

  const changeMonth = (delta: number) => {
    let m = month + delta;
    let y = year;
    if (m < 0) { m = 11; y--; }
    if (m > 11) { m = 0; y++; }
    router.push(`?y=${y}&m=${m}`);
  };

  const active = activeDay !== null ? entryByDay.get(activeDay) : null;
  const activeEvents = activeDay !== null ? (eventsByDay.get(activeDay) ?? []) : [];
  const activeDate = activeDay !== null ? new Date(year, month, activeDay) : null;
  const activeHours = active ? calcHours(active.shiftStart, active.shiftEnd) : null;

  const scheduleChangeHref =
    activeDate
      ? `/applications/new?type=SCHEDULE_CHANGE&date=${activeDate.toISOString().slice(0, 10)}`
      : "/applications/new";

  return (
    <div className="space-y-5">
      <div className="flex items-center justify-between gap-3">
        <div className="inline-flex items-center gap-2 px-3 py-2 rounded-lg bg-surface border border-border-soft text-sm">
          <Calendar size={16} className="text-text-soft" />
          <span className="text-text-soft">Месяц:</span>
          <span className="font-medium">
            {MONTHS_RU[month]} {year}
          </span>
          <div className="flex items-center gap-1 ml-1">
            <button
              type="button"
              onClick={() => changeMonth(-1)}
              className="w-6 h-6 rounded hover:bg-muted text-text-soft"
              aria-label="Предыдущий"
            >
              ‹
            </button>
            <button
              type="button"
              onClick={() => changeMonth(1)}
              className="w-6 h-6 rounded hover:bg-muted text-text-soft"
              aria-label="Следующий"
            >
              ›
            </button>
          </div>
        </div>
      </div>

      <div className="rounded-xl bg-surface border border-border-soft px-4 py-3 text-sm text-center">
        {todayEvents.length === 0 ? (
          <span className="text-text-soft">На сегодня событий не запланировано</span>
        ) : (
          <div className="space-y-1">
            <div className="text-text-soft text-xs">Сегодня</div>
            {todayEvents.map((ev) => (
              <div key={ev.id} className="font-medium text-foreground">
                {ev.title} · {fmtTime(ev.startsAt)}
              </div>
            ))}
          </div>
        )}
      </div>

      <div className="rounded-2xl bg-surface border border-border-soft p-4 md:p-5">
        <div className="grid grid-cols-7 gap-1 md:gap-2 mb-2">
          {WEEKDAYS_RU.map((w) => (
            <div key={w} className="text-center text-xs text-text-soft font-medium py-1">
              {w}
            </div>
          ))}
        </div>
        <div className="grid grid-cols-7 gap-1.5 md:gap-2">
          {Array.from({ length: rows * 7 }).map((_, i) => {
            const dayNumber = i - firstDayOffset + 1;
            if (dayNumber < 1 || dayNumber > days) return <div key={i} />;
            const entry = entryByDay.get(dayNumber);
            const info = entry ? shiftTypeInfo(entry.shiftType) : null;
            const isToday = isCurrentMonth && today.getDate() === dayNumber;
            const hasEvent = (eventsByDay.get(dayNumber) ?? []).length > 0;
            const isFilled = isToday && info;
            const color = info?.color ?? "var(--border)";
            return (
              <div key={i} className="flex items-center justify-center relative">
                <button
                  type="button"
                  onClick={() => setActiveDay(dayNumber)}
                  className="w-9 h-9 md:w-11 md:h-11 rounded-full flex items-center justify-center text-sm font-medium transition hover:scale-105"
                  style={{
                    border: `2px solid ${color}`,
                    background: isFilled ? color : "transparent",
                    color: isFilled ? "#ffffff" : info ? color : "var(--text-muted)",
                  }}
                  title={info?.label}
                >
                  {dayNumber}
                </button>
                {hasEvent && (
                  <Star
                    size={10}
                    className="absolute -top-0.5 -right-0.5 text-warning fill-warning"
                    aria-hidden
                  />
                )}
              </div>
            );
          })}
        </div>
      </div>

      <div className="rounded-2xl bg-surface border border-border-soft p-4 md:p-5 divide-y divide-border-soft">
        <div className="flex items-center justify-between py-2 first:pt-0">
          <span className="text-text-soft">Всего смен</span>
          <span className="font-semibold text-foreground text-lg">{workCount}</span>
        </div>
        <div className="flex items-center justify-between py-2">
          <span className="text-text-soft">Выходные / отпуск</span>
          <span className="font-semibold text-foreground text-lg">{vacationCount}</span>
        </div>
        <div className="flex items-center justify-between py-2 last:pb-0">
          <span className="text-text-soft">Больничный / отгулы</span>
          <span className="font-semibold text-foreground text-lg">{sickCount}</span>
        </div>
      </div>

      <div className="flex flex-wrap gap-2 text-xs">
        {SHIFT_TYPES.map((s) => (
          <div
            key={s.value}
            className="inline-flex items-center gap-1.5 px-3 py-1.5 rounded-md bg-surface border border-border-soft"
          >
            <span className="w-2.5 h-2.5 rounded-full" style={{ backgroundColor: s.color }} />
            <span className="text-text-soft">{s.label}</span>
          </div>
        ))}
      </div>

      <Modal open={activeDay !== null} onClose={() => setActiveDay(null)} maxWidth="max-w-md">
        {activeDate && (
          <div className="p-6">
            <div className="text-lg font-semibold text-foreground mb-3">
              {activeDate.toLocaleDateString("ru-RU", {
                day: "numeric",
                month: "long",
                year: "numeric",
              })}
            </div>
            {active ? (
              <div className="space-y-2 text-sm">
                <div className="flex items-center gap-2">
                  <div
                    className="w-2.5 h-2.5 rounded-full shrink-0"
                    style={{ backgroundColor: shiftTypeInfo(active.shiftType)?.color }}
                  />
                  <span className="font-medium text-foreground">
                    {shiftTypeInfo(active.shiftType)?.label}
                  </span>
                </div>
                {active.shiftStart && active.shiftEnd && (
                  <div className="flex items-center gap-2 text-text-soft">
                    <Clock size={14} />
                    <span>
                      {active.shiftStart}–{active.shiftEnd}
                    </span>
                    {activeHours && <span className="text-text-muted">· {activeHours}</span>}
                  </div>
                )}
                {active.breakStart && active.breakEnd && (
                  <div className="flex items-center gap-2 text-text-soft">
                    <Coffee size={14} />
                    <span>
                      Обед: {active.breakStart}–{active.breakEnd}
                    </span>
                  </div>
                )}
                {active.note && (
                  <div className="flex items-start gap-2 text-text-soft pt-1">
                    <AlertCircle size={14} className="mt-0.5" />
                    <span>{active.note}</span>
                  </div>
                )}
              </div>
            ) : (
              <div className="text-sm text-text-soft">На этот день смена не назначена</div>
            )}

            {activeEvents.length > 0 && (
              <div className="mt-4 pt-4 border-t border-border-soft">
                <div className="text-xs text-text-muted uppercase tracking-wide font-medium mb-2">
                  События в этот день
                </div>
                <ul className="space-y-1.5 text-sm">
                  {activeEvents.map((ev) => (
                    <li key={ev.id} className="flex items-center gap-2">
                      <Star
                        size={12}
                        className="text-warning fill-warning shrink-0"
                        aria-hidden
                      />
                      <span className="text-foreground flex-1">{ev.title}</span>
                      <span className="text-text-soft text-xs">{fmtTime(ev.startsAt)}</span>
                    </li>
                  ))}
                </ul>
              </div>
            )}

            <div className="mt-6 flex justify-center">
              <Link href={scheduleChangeHref}>
                <Button>
                  <Pencil size={14} /> Изменение графика
                </Button>
              </Link>
            </div>
          </div>
        )}
      </Modal>
    </div>
  );
}
