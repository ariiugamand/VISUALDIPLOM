import Link from "next/link";
import { ArrowLeft } from "lucide-react";
import { prisma } from "@/lib/prisma";
import { requireRole } from "@/lib/auth";
import { PageShell } from "@/components/ui/page-shell";
import { ScheduleMatrix } from "../schedule-matrix";

function parseIntSafe(v: unknown, def: number): number {
  if (typeof v !== "string") return def;
  const n = Number(v);
  return Number.isFinite(n) ? n : def;
}

export default async function EditSchedulePage(props: PageProps<"/schedule/edit">) {
  await requireRole("MANAGER");
  const searchParams = await props.searchParams;
  const now = new Date();
  const year = parseIntSafe(searchParams.y, now.getFullYear());
  const month = parseIntSafe(searchParams.m, now.getMonth());
  const start = new Date(year, month, 1);
  const end = new Date(year, month + 1, 1);

  const [employees, rawEntries] = await Promise.all([
    prisma.user.findMany({
      where: { role: "EMPLOYEE", status: "ACTIVE" },
      orderBy: [{ lastName: "asc" }, { firstName: "asc" }],
      select: { id: true, lastName: true, firstName: true },
    }),
    prisma.scheduleEntry.findMany({ where: { date: { gte: start, lt: end } } }),
  ]);
  const entries = rawEntries.map((e) => ({
    userId: e.userId,
    date: e.date.toISOString(),
    shiftType: e.shiftType,
  }));

  return (
    <div>
      <div className="px-5 md:px-10 pt-6">
        <Link
          href={`/schedule?y=${year}&m=${month}`}
          className="inline-flex items-center gap-1.5 text-sm text-text-soft hover:text-foreground"
        >
          <ArrowLeft size={14} /> К просмотру графика
        </Link>
      </div>
      <PageShell title="Рабочий график" subtitle="Редактирование">
        <ScheduleMatrix
          employees={employees}
          entries={entries}
          year={year}
          month={month}
          editable
        />
      </PageShell>
    </div>
  );
}
