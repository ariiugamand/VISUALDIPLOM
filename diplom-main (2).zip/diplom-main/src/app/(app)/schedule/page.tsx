import { prisma } from "@/lib/prisma";
import { requireAuth } from "@/lib/auth";
import { PageShell } from "@/components/ui/page-shell";
import { ScheduleMatrix } from "./schedule-matrix";
import { EmployeeSchedule } from "./employee-schedule";

function parseIntSafe(v: unknown, def: number): number {
  if (typeof v !== "string") return def;
  const n = Number(v);
  return Number.isFinite(n) ? n : def;
}

export default async function SchedulePage(props: PageProps<"/schedule">) {
  const { user, session } = await requireAuth();
  const searchParams = await props.searchParams;
  const now = new Date();
  const year = parseIntSafe(searchParams.y, now.getFullYear());
  const month = parseIntSafe(searchParams.m, now.getMonth());
  const start = new Date(year, month, 1);
  const end = new Date(year, month + 1, 1);

  if (session.role === "MANAGER") {
    const [employees, rawEntries] = await Promise.all([
      prisma.user.findMany({
        where: { role: "EMPLOYEE", status: "ACTIVE" },
        orderBy: [{ lastName: "asc" }, { firstName: "asc" }],
        select: { id: true, lastName: true, firstName: true },
      }),
      prisma.scheduleEntry.findMany({
        where: { date: { gte: start, lt: end } },
      }),
    ]);
    const entries = rawEntries.map((e) => ({
      userId: e.userId,
      date: e.date.toISOString(),
      shiftType: e.shiftType,
    }));

    return (
      <PageShell title="Просмотр графика" subtitle="Рабочий график">
        <ScheduleMatrix
          employees={employees}
          entries={entries}
          year={year}
          month={month}
        />
      </PageShell>
    );
  }

  // сотрудник
  const [rawEntries, monthEvents] = await Promise.all([
    prisma.scheduleEntry.findMany({
      where: { userId: user.id, date: { gte: start, lt: end } },
    }),
    prisma.event.findMany({
      where: { startsAt: { gte: start, lt: end } },
      orderBy: [{ startsAt: "asc" }],
    }),
  ]);

  const entries = rawEntries.map((e) => ({
    date: e.date.toISOString(),
    shiftType: e.shiftType,
    shiftStart: e.shiftStart,
    shiftEnd: e.shiftEnd,
    breakStart: e.breakStart,
    breakEnd: e.breakEnd,
    note: e.note,
  }));
  const events = monthEvents.map((ev) => ({
    id: ev.id,
    title: ev.title,
    startsAt: ev.startsAt.toISOString(),
    importance: ev.importance,
  }));

  return (
    <PageShell title="График работы" subtitle="Ваши смены на месяц">
      <EmployeeSchedule entries={entries} events={events} year={year} month={month} />
    </PageShell>
  );
}
