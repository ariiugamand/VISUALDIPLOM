"use client";

import { useMemo, useState, useTransition } from "react";
import { useRouter } from "next/navigation";
import Link from "next/link";
import { Calendar, Sparkles, Save, Plus } from "lucide-react";
import {
  MONTHS_RU,
  SHIFT_TYPES,
  WEEKDAYS_RU,
  type ShiftType,
  daysInMonth,
  shiftTypeInfo,
  weekdayIndex,
} from "@/lib/schedule";
import { Button } from "@/components/ui/button";
import { Select } from "@/components/ui/select";
import { Modal } from "@/components/ui/modal";
import { saveScheduleAction, generateMonthWorkdaysAction } from "./actions";

type EmployeeDto = { id: string; lastName: string; firstName: string };
type EntryDto = { userId: string; date: string; shiftType: string };

type Props = {
  employees: EmployeeDto[];
  entries: EntryDto[];
  year: number;
  month: number;
  editable?: boolean;
};

const KEY = (u: string, d: number) => `${u}|${d}`;

export function ScheduleMatrix({ employees, entries, year, month, editable = false }: Props) {
  const router = useRouter();
  const [pending, start] = useTransition();
  const [selectedType, setSelectedType] = useState<ShiftType | "CLEAR">("WORK");
  const [pendingChanges, setPendingChanges] = useState<Map<string, ShiftType | "CLEAR">>(
    new Map(),
  );
  const [sortOrder, setSortOrder] = useState<"asc" | "desc">("asc");
  const [detailEmployee, setDetailEmployee] = useState<EmployeeDto | null>(null);

  const sortedEmployees = useMemo(() => {
    const copy = [...employees];
    copy.sort((a, b) =>
      `${a.lastName} ${a.firstName}`.localeCompare(
        `${b.lastName} ${b.firstName}`,
        "ru",
      ),
    );
    return sortOrder === "asc" ? copy : copy.reverse();
  }, [employees, sortOrder]);

  const days = daysInMonth(year, month);
  const entryMap = useMemo(() => {
    const m = new Map<string, string>();
    for (const e of entries) {
      const d = new Date(e.date);
      m.set(KEY(e.userId, d.getDate()), e.shiftType);
    }
    return m;
  }, [entries]);

  const getCell = (userId: string, day: number): ShiftType | "CLEAR" | null => {
    const pk = KEY(userId, day);
    if (pendingChanges.has(pk)) return pendingChanges.get(pk)!;
    return (entryMap.get(pk) as ShiftType | undefined) ?? null;
  };

  const onCellClick = (userId: string, day: number) => {
    if (!editable) return;
    const pk = KEY(userId, day);
    const current = getCell(userId, day);
    const next = current === selectedType ? "CLEAR" : selectedType;
    setPendingChanges((prev) => {
      const n = new Map(prev);
      n.set(pk, next);
      return n;
    });
  };

  const onSave = () => {
    if (pendingChanges.size === 0) return;
    const payload = Array.from(pendingChanges.entries()).map(([k, shiftType]) => {
      const [userId, dayStr] = k.split("|");
      const d = Number(dayStr);
      const date = new Date(year, month, d).toISOString();
      return { userId, date, shiftType };
    });
    start(async () => {
      await saveScheduleAction(payload);
      setPendingChanges(new Map());
      router.refresh();
    });
  };

  const onGenerate = () => {
    if (!confirm("Сгенерировать стандартный график на месяц (пн–пт — рабочий, сб–вс — выходной)? Существующие записи перезапишутся.")) return;
    start(async () => {
      await generateMonthWorkdaysAction(year, month);
      setPendingChanges(new Map());
      router.refresh();
    });
  };

  const changeMonth = (delta: number) => {
    let m = month + delta;
    let y = year;
    if (m < 0) { m = 11; y--; }
    if (m > 11) { m = 0; y++; }
    router.push(`?y=${y}&m=${m}`);
  };

  return (
    <div className="space-y-5">
      <div className="flex flex-wrap items-center gap-2 justify-between">
        <div className="flex items-center gap-2">
          <div className="inline-flex items-center gap-2 px-3 py-2 rounded-full bg-surface border border-border-soft text-sm">
            <Calendar size={16} className="text-text-soft" />
            <span className="text-text-soft">Месяц:</span>
            <span className="font-medium">{MONTHS_RU[month]}</span>
            <div className="flex items-center gap-1 ml-1">
              <button
                type="button"
                onClick={() => changeMonth(-1)}
                className="w-6 h-6 rounded-full hover:bg-muted text-text-soft"
                aria-label="Предыдущий месяц"
              >
                ‹
              </button>
              <button
                type="button"
                onClick={() => changeMonth(1)}
                className="w-6 h-6 rounded-full hover:bg-muted text-text-soft"
                aria-label="Следующий месяц"
              >
                ›
              </button>
            </div>
          </div>
          {editable && (
            <Select
              value={selectedType}
              onChange={(e) => setSelectedType(e.target.value as ShiftType | "CLEAR")}
              className="w-auto"
            >
              {SHIFT_TYPES.map((s) => (
                <option key={s.value} value={s.value}>
                  {s.label}
                </option>
              ))}
              <option value="CLEAR">Очистить ячейку</option>
            </Select>
          )}
        </div>

        <div className="flex items-center gap-2">
          <Select
            value={sortOrder}
            onChange={(e) => setSortOrder(e.target.value as "asc" | "desc")}
            className="w-28"
          >
            <option value="asc">А–Я</option>
            <option value="desc">Я–А</option>
          </Select>
          {editable ? (
            <>
              <Button variant="secondary" size="sm" onClick={onGenerate} disabled={pending}>
                <Sparkles size={14} /> Сгенерировать на месяц
              </Button>
              <Button
                size="sm"
                onClick={onSave}
                disabled={pending || pendingChanges.size === 0}
              >
                <Save size={14} />
                {pending ? "Сохраняем…" : `Сохранить${pendingChanges.size > 0 ? ` (${pendingChanges.size})` : ""}`}
              </Button>
            </>
          ) : (
            <Link href={`/schedule/edit?y=${year}&m=${month}`}>
              <Button size="sm">
                <Plus size={14} /> Составить график
              </Button>
            </Link>
          )}
        </div>
      </div>

      <div className="text-xs text-text-muted md:hidden">
        💡 Нажмите на имя сотрудника, чтобы открыть его календарь, или прокрутите таблицу вправо, чтобы увидеть все дни
      </div>

      <div className="overflow-x-auto rounded-2xl border border-border-soft bg-surface relative">
        <table className="border-collapse text-xs w-full min-w-[960px]">
          <thead>
            <tr>
              <th className="sticky left-0 z-10 bg-surface border-b border-r border-border-soft px-3 py-2 text-left font-medium text-text-soft min-w-[180px]">
                ФИО
              </th>
              {Array.from({ length: days }, (_, i) => i + 1).map((d) => {
                const date = new Date(year, month, d);
                const isWeekend = date.getDay() === 0 || date.getDay() === 6;
                return (
                  <th
                    key={d}
                    className={`border-b border-r border-border-soft w-8 py-1.5 font-medium text-text-soft ${
                      isWeekend ? "bg-muted/40" : ""
                    }`}
                  >
                    {d}
                  </th>
                );
              })}
            </tr>
          </thead>
          <tbody>
            {sortedEmployees.map((u) => (
              <tr key={u.id} className="hover:bg-muted/20">
                <td className="sticky left-0 z-10 bg-surface border-r border-b border-border-soft px-3 py-2 text-foreground">
                  <button
                    type="button"
                    onClick={() => setDetailEmployee(u)}
                    className="truncate text-left hover:text-brand transition w-full"
                    title="Открыть календарь сотрудника"
                  >
                    {u.lastName} {u.firstName}
                  </button>
                </td>
                {Array.from({ length: days }, (_, i) => i + 1).map((d) => {
                  const val = getCell(u.id, d);
                  const info = val && val !== "CLEAR" ? SHIFT_TYPES.find((s) => s.value === val) : null;
                  const isPending = pendingChanges.has(KEY(u.id, d));
                  return (
                    <td
                      key={d}
                      onClick={() => onCellClick(u.id, d)}
                      className={`border-r border-b border-border-soft w-8 h-9 p-0 text-center ${
                        editable ? "cursor-pointer hover:bg-accent-soft/30" : ""
                      } ${isPending ? "ring-2 ring-brand/40 ring-inset" : ""}`}
                    >
                      {info && (
                        <span
                          className="inline-block w-2.5 h-2.5 rounded-full"
                          style={{ backgroundColor: info.color }}
                          title={info.label}
                        />
                      )}
                    </td>
                  );
                })}
              </tr>
            ))}
            {employees.length === 0 && (
              <tr>
                <td className="text-center text-text-soft py-10" colSpan={days + 1}>
                  Нет сотрудников
                </td>
              </tr>
            )}
          </tbody>
        </table>
      </div>

      <div className="flex flex-wrap gap-4 text-xs text-text-soft">
        {SHIFT_TYPES.map((s) => (
          <div key={s.value} className="inline-flex items-center gap-1.5">
            <span
              className="inline-block w-2.5 h-2.5 rounded-full"
              style={{ backgroundColor: s.color }}
            />
            <span>{s.label}</span>
          </div>
        ))}
      </div>

      <Modal
        open={detailEmployee !== null}
        onClose={() => setDetailEmployee(null)}
        maxWidth="max-w-lg"
      >
        {detailEmployee && (
          <EmployeeCalendar
            employee={detailEmployee}
            entries={entries}
            year={year}
            month={month}
          />
        )}
      </Modal>
    </div>
  );
}

// календарь
function EmployeeCalendar({
  employee,
  entries,
  year,
  month,
}: {
  employee: EmployeeDto;
  entries: EntryDto[];
  year: number;
  month: number;
}) {
  const days = daysInMonth(year, month);
  const firstDayOffset = weekdayIndex(new Date(year, month, 1));
  const totalCells = firstDayOffset + days;
  const rows = Math.ceil(totalCells / 7);

  const entryByDay = useMemo(() => {
    const m = new Map<number, string>();
    for (const e of entries) {
      if (e.userId !== employee.id) continue;
      m.set(new Date(e.date).getDate(), e.shiftType);
    }
    return m;
  }, [entries, employee.id]);

  const counts = useMemo(() => {
    const c: Record<string, number> = {};
    for (const [, v] of entryByDay) c[v] = (c[v] ?? 0) + 1;
    return c;
  }, [entryByDay]);
  const workCount = counts.WORK ?? 0;
  const weekendCount = (counts.WEEKEND ?? 0) + (counts.VACATION ?? 0);
  const sickCount = counts.SICK ?? 0;

  return (
    <div className="p-6">
      <div className="mb-1 text-xs text-text-soft uppercase tracking-wide font-medium">
        График сотрудника
      </div>
      <div className="text-xl font-semibold text-foreground mb-1">
        {employee.lastName} {employee.firstName}
      </div>
      <div className="text-sm text-text-soft mb-4">
        {MONTHS_RU[month]} {year}
      </div>

      <div className="rounded-2xl border border-border-soft p-3 bg-surface">
        <div className="grid grid-cols-7 gap-1 mb-2">
          {WEEKDAYS_RU.map((w) => (
            <div
              key={w}
              className="text-center text-[11px] text-text-soft font-medium py-1"
            >
              {w}
            </div>
          ))}
        </div>
        <div className="grid grid-cols-7 gap-1.5">
          {Array.from({ length: rows * 7 }).map((_, i) => {
            const dayNumber = i - firstDayOffset + 1;
            if (dayNumber < 1 || dayNumber > days) return <div key={i} />;
            const st = entryByDay.get(dayNumber);
            const info = st ? shiftTypeInfo(st) : null;
            const color = info?.color ?? "var(--border)";
            return (
              <div
                key={i}
                className="flex items-center justify-center"
                title={info?.label}
              >
                <div
                  className="w-9 h-9 rounded-full flex items-center justify-center text-xs font-medium"
                  style={{
                    border: `2px solid ${color}`,
                    color: info ? color : "var(--text-muted)",
                  }}
                >
                  {dayNumber}
                </div>
              </div>
            );
          })}
        </div>
      </div>

      <div className="mt-4 rounded-xl bg-muted/40 border border-border-soft divide-y divide-border-soft text-sm">
        <div className="flex items-center justify-between px-3 py-2">
          <span className="text-text-soft">Смены</span>
          <span className="font-semibold text-foreground">{workCount}</span>
        </div>
        <div className="flex items-center justify-between px-3 py-2">
          <span className="text-text-soft">Выходные / отпуск</span>
          <span className="font-semibold text-foreground">{weekendCount}</span>
        </div>
        <div className="flex items-center justify-between px-3 py-2">
          <span className="text-text-soft">Больничные</span>
          <span className="font-semibold text-foreground">{sickCount}</span>
        </div>
      </div>

      <div className="mt-3 flex flex-wrap gap-2 text-xs">
        {SHIFT_TYPES.map((s) => (
          <div
            key={s.value}
            className="inline-flex items-center gap-1.5 px-2.5 py-1 rounded-md bg-surface border border-border-soft"
          >
            <span
              className="w-2 h-2 rounded-full"
              style={{ backgroundColor: s.color }}
            />
            <span className="text-text-soft">{s.label}</span>
          </div>
        ))}
      </div>
    </div>
  );
}
