import Link from "next/link";
import { ResetForm } from "./reset-form";

export default function ForgotPasswordPage() {
  return (
    <div>
      <h1 className="text-2xl font-bold text-center text-foreground">Сброс пароля</h1>
      <p className="mt-1.5 text-sm text-text-soft text-center">
        Введите email и код для смены пароля
      </p>
      <div className="mt-6">
        <ResetForm />
      </div>
      <div className="mt-6 text-center">
        <Link
          href="/login"
          className="text-brand hover:text-brand-hover text-sm font-medium"
        >
          ← Вернуться ко входу
        </Link>
      </div>
    </div>
  );
}
