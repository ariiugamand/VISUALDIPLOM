"use client";

import { useActionState } from "react";
import { resetPasswordAction, type ResetFormState } from "@/app/actions/password";
import { Input } from "@/components/ui/input";
import { Button } from "@/components/ui/button";

export function ResetForm() {
  const [state, action, pending] = useActionState<ResetFormState, FormData>(
    resetPasswordAction,
    undefined,
  );

  return (
    <form action={action} className="space-y-3">
      <div>
        <Input
          name="email"
          type="email"
          variant="pill"
          placeholder="Электронная почта"
          required
          className="py-3"
        />
        {state?.errors?.email?.[0] && (
          <p className="mt-1 text-xs text-danger pl-4">{state.errors.email[0]}</p>
        )}
      </div>
      <div>
        <Input
          name="code"
          variant="pill"
          placeholder="Код подтверждения"
          required
          className="py-3"
        />
        <p className="mt-1 text-xs text-text-muted pl-4">
          Для теста используйте код 0000
        </p>
        {state?.errors?.code?.[0] && (
          <p className="mt-1 text-xs text-danger pl-4">{state.errors.code[0]}</p>
        )}
      </div>
      <div>
        <Input
          name="password"
          type="password"
          variant="pill"
          placeholder="Новый пароль"
          required
          className="py-3"
        />
        {state?.errors?.password?.[0] && (
          <p className="mt-1 text-xs text-danger pl-4">{state.errors.password[0]}</p>
        )}
      </div>
      <div>
        <Input
          name="passwordConfirm"
          type="password"
          variant="pill"
          placeholder="Повторите пароль"
          required
          className="py-3"
        />
        {state?.errors?.passwordConfirm?.[0] && (
          <p className="mt-1 text-xs text-danger pl-4">
            {state.errors.passwordConfirm[0]}
          </p>
        )}
      </div>

      {state?.message && (
        <div className="rounded-2xl bg-red-50 border border-red-200 px-4 py-3 text-sm text-danger">
          {state.message}
        </div>
      )}

      <Button type="submit" disabled={pending} className="w-full" size="lg">
        {pending ? "Сохраняем…" : "Сменить пароль"}
      </Button>
    </form>
  );
}
