import { BrandLogo } from "@/components/brand/logo";

export default function AuthLayout({ children }: { children: React.ReactNode }) {
  return (
    <div className="relative min-h-screen flex flex-col bg-surface overflow-hidden">
      <header className="relative z-20 h-16 border-b border-border-soft bg-surface flex items-center px-6">
        <BrandLogo />
        <div className="ml-3 hidden sm:block h-6 w-px bg-border" />
        <div className="ml-3 hidden sm:block text-sm text-text-soft">Кадровая система</div>
      </header>

      <main className="relative z-10 flex-1 flex items-start md:items-center justify-center p-5 md:p-6">
        <div className="w-full max-w-md pt-4 md:pt-0">
          <div className="md:rounded-[28px] md:bg-surface md:px-8 md:py-10 md:border md:border-border-soft md:shadow-[0_24px_64px_-16px_rgb(47_122_92_/_0.18),0_8px_24px_-12px_rgb(47_122_92_/_0.12)]">
            {children}
          </div>
        </div>
      </main>

      <AuthWaveDecoration />
    </div>
  );
}

// волны
function AuthWaveDecoration() {
  return (
    <div
      aria-hidden
      className="pointer-events-none absolute inset-x-0 bottom-0 z-0 overflow-hidden h-[45vh] md:h-[55vh]"
    >
      <svg
        width="393"
        height="363"
        viewBox="0 0 393 363"
        preserveAspectRatio="none"
        className="absolute inset-0 w-full h-full"
      >
        <g>
          <path
            d="M238.5 284.5C325.5 252.534 338.87 133.4 393.5 48.2259V0C327.5 159.5 209 83 139 160.6C238.5 200.5 193.639 227.695 238.5 284.5Z"
            fill="url(#authWave0)"
          />
          <path
            d="M0 362.953H393.5V48.2259C338.87 133.4 325.5 252.534 238.5 284.5C117 321 196.75 362.953 0 362.953Z"
            fill="url(#authWave1)"
          />
          <path
            d="M0 362.953C196.75 362.953 117 321 238.5 284.5C155 215 33 308 0 186.617V362.953Z"
            fill="url(#authWave2)"
          />
          <path
            d="M0 186.617C33 308 155 215 238.5 284.5C193.639 227.695 238.5 200.5 139 160.6C58 137 35.6096 94.6228 0 33.3452V186.617Z"
            fill="url(#authWave3)"
          />
        </g>
        <defs>
          <linearGradient
            id="authWave0"
            x1="196.75"
            y1="0"
            x2="196.75"
            y2="362.953"
            gradientUnits="userSpaceOnUse"
          >
            <stop stopColor="#EFE8E2" stopOpacity="0.31" />
            <stop offset="1" stopColor="#40916C" />
          </linearGradient>
          <linearGradient
            id="authWave1"
            x1="196.75"
            y1="0"
            x2="196.75"
            y2="362.953"
            gradientUnits="userSpaceOnUse"
          >
            <stop stopColor="#DEE7E0" />
            <stop offset="0.668269" stopColor="#9FC5B2" />
            <stop offset="1" stopColor="#5A9F7F" />
          </linearGradient>
          <linearGradient
            id="authWave2"
            x1="196.75"
            y1="0"
            x2="196.75"
            y2="362.953"
            gradientUnits="userSpaceOnUse"
          >
            <stop offset="0.509615" stopColor="#DEE7E0" />
            <stop offset="1" stopColor="#5A9F7F" />
          </linearGradient>
          <linearGradient
            id="authWave3"
            x1="208"
            y1="14"
            x2="208"
            y2="367"
            gradientUnits="userSpaceOnUse"
          >
            <stop stopColor="#DEE7E0" />
            <stop offset="1" stopColor="#5A9F7F" />
          </linearGradient>
        </defs>
      </svg>
    </div>
  );
}
