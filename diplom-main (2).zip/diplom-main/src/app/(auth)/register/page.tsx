import Link from "next/link";
import { RegisterForm } from "./register-form";

export default function RegisterPage() {
  return (
    <div>
      <h1 className="text-3xl font-bold text-center text-foreground">Регистрация</h1>
      <div className="mt-6">
        <RegisterForm />
      </div>
      <div className="mt-6 text-center text-sm">
        <Link href="/login" className="text-brand hover:text-brand-hover font-medium">
          Уже есть аккаунт? Войти
        </Link>
      </div>
    </div>
  );
}
