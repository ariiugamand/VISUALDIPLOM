"use client";

import { useActionState, useEffect, useState, type ReactNode } from "react";
import { registerAction, type AuthFormState } from "@/app/actions/auth";
import { Input } from "@/components/ui/input";
import { Button } from "@/components/ui/button";
import { Select } from "@/components/ui/select";

// обёртка
function FieldWrap({
  error,
  children,
}: {
  error?: string;
  children: ReactNode;
}) {
  return (
    <div>
      {children}
      {error && <p className="mt-1 text-xs text-danger pl-4">{error}</p>}
    </div>
  );
}

export function RegisterForm() {
  const [state, action, pending] = useActionState<AuthFormState, FormData>(
    registerAction,
    undefined,
  );

  const [lastName, setLastName] = useState("");
  const [firstName, setFirstName] = useState("");
  const [middleName, setMiddleName] = useState("");
  const [email, setEmail] = useState("");
  const [phone, setPhone] = useState("");
  const [position, setPosition] = useState("");
  const [role, setRole] = useState("EMPLOYEE");
  const [password, setPassword] = useState("");
  const [passwordConfirm, setPasswordConfirm] = useState("");

  // сброс паролей
  useEffect(() => {
    if (state?.errors || state?.message) {
      setPassword("");
      setPasswordConfirm("");
    }
  }, [state]);

  return (
    <form action={action} className="space-y-3">
      <div className="grid grid-cols-2 gap-2">
        <FieldWrap error={state?.errors?.lastName?.[0]}>
          <Input
            name="lastName"
            variant="pill"
            placeholder="Фамилия"
            required
            value={lastName}
            onChange={(e) => setLastName(e.target.value)}
            className="py-3"
          />
        </FieldWrap>
        <FieldWrap error={state?.errors?.firstName?.[0]}>
          <Input
            name="firstName"
            variant="pill"
            placeholder="Имя"
            required
            value={firstName}
            onChange={(e) => setFirstName(e.target.value)}
            className="py-3"
          />
        </FieldWrap>
      </div>
      <FieldWrap error={state?.errors?.middleName?.[0]}>
        <Input
          name="middleName"
          variant="pill"
          placeholder="Отчество"
          value={middleName}
          onChange={(e) => setMiddleName(e.target.value)}
          className="py-3"
        />
      </FieldWrap>
      <FieldWrap error={state?.errors?.email?.[0]}>
        <Input
          name="email"
          type="email"
          variant="pill"
          placeholder="Электронная почта"
          required
          value={email}
          onChange={(e) => setEmail(e.target.value)}
          className="py-3"
        />
      </FieldWrap>
      <FieldWrap error={state?.errors?.phone?.[0]}>
        <Input
          name="phone"
          type="tel"
          variant="pill"
          placeholder="Номер телефона"
          value={phone}
          onChange={(e) => setPhone(e.target.value)}
          className="py-3"
        />
      </FieldWrap>
      <FieldWrap error={state?.errors?.position?.[0]}>
        <Input
          name="position"
          variant="pill"
          placeholder="Должность"
          value={position}
          onChange={(e) => setPosition(e.target.value)}
          className="py-3"
        />
      </FieldWrap>
      <FieldWrap error={state?.errors?.role?.[0]}>
        <Select
          name="role"
          variant="pill"
          value={role}
          onChange={(e) => setRole(e.target.value)}
          className="py-3"
        >
          <option value="EMPLOYEE">Сотрудник</option>
          <option value="MANAGER">Руководитель</option>
        </Select>
      </FieldWrap>
      <div className="grid grid-cols-2 gap-2">
        <FieldWrap error={state?.errors?.password?.[0]}>
          <Input
            name="password"
            type="password"
            variant="pill"
            placeholder="Пароль"
            required
            value={password}
            onChange={(e) => setPassword(e.target.value)}
            className="py-3"
          />
        </FieldWrap>
        <FieldWrap error={state?.errors?.passwordConfirm?.[0]}>
          <Input
            name="passwordConfirm"
            type="password"
            variant="pill"
            placeholder="Повторите пароль"
            required
            value={passwordConfirm}
            onChange={(e) => setPasswordConfirm(e.target.value)}
            className="py-3"
          />
        </FieldWrap>
      </div>

      {state?.message && (
        <div className="rounded-xl bg-red-50 border border-red-200 px-4 py-3 text-sm text-danger">
          {state.message}
        </div>
      )}

      <Button type="submit" disabled={pending} className="w-full" size="lg">
        {pending ? "Создаём…" : "Создать аккаунт"}
      </Button>
    </form>
  );
}
