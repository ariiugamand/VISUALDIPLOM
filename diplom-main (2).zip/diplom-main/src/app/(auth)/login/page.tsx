import Link from "next/link";
import { LoginForm } from "./login-form";

export default async function LoginPage(props: PageProps<"/login">) {
  const searchParams = await props.searchParams;
  const justReset = searchParams.reset === "1";
  return (
    <div>
      <h1 className="text-3xl font-bold text-center text-foreground">Авторизация</h1>
      {justReset && (
        <div className="mt-4 rounded-2xl bg-accent-soft/50 border border-accent-soft px-4 py-3 text-sm text-brand-dark text-center">
          Пароль успешно изменён. Войдите с новым паролем.
        </div>
      )}
      <div className="mt-6">
        <LoginForm />
      </div>
      <div className="mt-6 flex flex-col items-center gap-2 text-sm">
        <Link href="/forgot-password" className="text-text-soft hover:text-brand">
          Забыли пароль?
        </Link>
        <Link href="/register" className="text-brand hover:text-brand-hover font-medium">
          Создать аккаунт
        </Link>
      </div>
    </div>
  );
}
