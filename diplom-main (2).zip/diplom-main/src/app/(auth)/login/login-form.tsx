"use client";

import { useActionState } from "react";
import { loginAction, type AuthFormState } from "@/app/actions/auth";
import { Input } from "@/components/ui/input";
import { Button } from "@/components/ui/button";

export function LoginForm() {
  const [state, action, pending] = useActionState<AuthFormState, FormData>(
    loginAction,
    undefined,
  );

  return (
    <form action={action} className="space-y-3">
      <div>
        <Input
          name="login"
          variant="pill"
          placeholder="Логин, e-mail или номер телефона"
          autoComplete="username"
          required
          className="py-3"
        />
        {state?.errors?.login?.[0] && (
          <p className="mt-1 text-xs text-danger pl-4">{state.errors.login[0]}</p>
        )}
      </div>
      <div>
        <Input
          name="password"
          type="password"
          variant="pill"
          placeholder="Пароль"
          autoComplete="current-password"
          required
          className="py-3"
        />
        {state?.errors?.password?.[0] && (
          <p className="mt-1 text-xs text-danger pl-4">{state.errors.password[0]}</p>
        )}
      </div>

      {state?.message && (
        <div className="rounded-2xl bg-red-50 border border-red-200 px-4 py-3 text-sm text-danger">
          {state.message}
        </div>
      )}

      <Button type="submit" disabled={pending} className="w-full" size="lg">
        {pending ? "Входим…" : "Войти"}
      </Button>
    </form>
  );
}
