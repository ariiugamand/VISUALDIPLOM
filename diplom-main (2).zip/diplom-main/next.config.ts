import type { NextConfig } from "next";

const nextConfig: NextConfig = {
  // dev-индикатор
  devIndicators: false,
};

export default nextConfig;
