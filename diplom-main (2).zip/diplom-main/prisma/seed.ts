import "dotenv/config";
import { PrismaBetterSqlite3 } from "@prisma/adapter-better-sqlite3";
import { PrismaClient } from "../src/generated/prisma/client";
import bcrypt from "bcryptjs";
import path from "node:path";
import fs from "node:fs/promises";
import { randomUUID } from "node:crypto";
import { generateTemplatePdf } from "./generate-template-pdf";

const UPLOADS_ROOT = path.join(process.cwd(), "uploads");
const TEMPLATES_DIR = path.join(UPLOADS_ROOT, "templates");

// PDF к шаблону
async function attachPdfToTemplate(
  templateId: string,
  title: string,
  type: string,
  content: string,
) {
  if (!content.trim()) return;
  const pdf = await generateTemplatePdf({ title, type, body: content });
  const dir = path.join(TEMPLATES_DIR, templateId);
  await fs.mkdir(dir, { recursive: true });
  const safeName = `${title.replace(/[^\wа-яА-ЯёЁ\- ]+/g, "").slice(0, 60).trim().replace(/\s+/g, "_")}.pdf`;
  const storedName = `${randomUUID()}__${safeName}`;
  const fullPath = path.join(dir, storedName);
  await fs.writeFile(fullPath, pdf);
  await prisma.documentTemplate.update({
    where: { id: templateId },
    data: {
      pdfUrl: path.posix.join("templates", templateId, storedName),
      pdfFilename: safeName,
      pdfSize: pdf.byteLength,
    },
  });
}

const url = process.env.DATABASE_URL ?? "file:./prisma/dev.db";
const adapter = new PrismaBetterSqlite3({
  url: url.startsWith("file:") ? url.slice("file:".length) : url,
});
const prisma = new PrismaClient({ adapter, log: ["error"] });

async function main() {
  console.log("Cleaning up existing seed data…");
  await prisma.notification.deleteMany();
  await prisma.taskAttachment.deleteMany();
  await prisma.task.deleteMany();
  await prisma.applicationAttachment.deleteMany();
  await prisma.application.deleteMany();
  await prisma.eventRecipient.deleteMany();
  await prisma.event.deleteMany();
  await prisma.scheduleEntry.deleteMany();
  await prisma.passwordResetToken.deleteMany();
  await prisma.filledDocument.deleteMany();
  await prisma.documentTemplate.deleteMany();
  // файлы шаблонов
  await fs.rm(TEMPLATES_DIR, { recursive: true, force: true });
  await prisma.reportAttachment.deleteMany();
  await prisma.report.deleteMany();
  await prisma.knowledgeArticle.deleteMany();
  await prisma.department.deleteMany();
  await prisma.user.deleteMany();

  console.log("Creating department…");
  const dept = await prisma.department.create({
    data: { name: "Клиентское обслуживание" },
  });

  const password = await bcrypt.hash("demo1234", 10);

  console.log("Creating manager…");
  const manager = await prisma.user.create({
    data: {
      email: "manager@demo.local",
      phone: "+79990000001",
      firstName: "Анна",
      lastName: "Иванова",
      middleName: "Сергеевна",
      position: "Руководитель отдела",
      role: "MANAGER",
      passwordHash: password,
      departmentId: dept.id,
      hireDate: new Date("2022-03-01"),
    },
  });

  await prisma.department.update({
    where: { id: dept.id },
    data: { managerId: manager.id },
  });

  console.log("Creating employees…");
  await prisma.user.createMany({
    data: [
      {
        email: "employee@demo.local",
        phone: "+79990000002",
        firstName: "Павел",
        lastName: "Петров",
        middleName: "Андреевич",
        position: "Специалист",
        role: "EMPLOYEE",
        passwordHash: password,
        departmentId: dept.id,
        hireDate: new Date("2023-09-15"),
      },
      {
        email: "smirnova@demo.local",
        firstName: "Елена",
        lastName: "Смирнова",
        middleName: "Владимировна",
        position: "Ведущий специалист",
        role: "EMPLOYEE",
        passwordHash: password,
        departmentId: dept.id,
        hireDate: new Date("2021-06-10"),
      },
      {
        email: "volkov@demo.local",
        firstName: "Дмитрий",
        lastName: "Волков",
        position: "Стажёр",
        role: "EMPLOYEE",
        passwordHash: password,
        departmentId: dept.id,
        hireDate: new Date("2025-01-12"),
      },
    ],
  });

  const employee = await prisma.user.findFirstOrThrow({
    where: { email: "employee@demo.local" },
  });

  console.log("Creating applications…");
  await prisma.application.createMany({
    data: [
      {
        userId: employee.id,
        type: "VACATION",
        subject: "Отпуск на 5 дней",
        text: "Прошу предоставить очередной оплачиваемый отпуск с 15 по 19 мая 2026 года.",
        startDate: new Date("2026-05-15"),
        endDate: new Date("2026-05-19"),
        status: "SENT",
      },
      {
        userId: employee.id,
        type: "SCHEDULE_CHANGE",
        subject: "Изменение графика 22.04",
        text: "Прошу поменять смену 22 апреля с утренней на вечернюю по семейным обстоятельствам.",
        startDate: new Date("2026-04-22"),
        status: "APPROVED",
        managerComment: "Согласовано. Смена перенесена в графике.",
        reviewedAt: new Date("2026-04-16"),
        reviewedById: manager.id,
      },
      {
        userId: employee.id,
        type: "OTHER",
        subject: "Запрос справки 2-НДФЛ",
        text: "Требуется справка 2-НДФЛ за 2025 год для подачи в банк.",
        status: "CREATED",
      },
    ],
  });

  console.log("Creating knowledge base articles…");
  await prisma.knowledgeArticle.createMany({
    data: [
      {
        title: "Как работать с платёжной формой",
        category: "Обслуживание",
        excerpt:
          "Пошаговая инструкция по заполнению платёжного поручения в клиент-банке и типовые ошибки.",
        content:
          "1. Откройте платёжную форму из главного меню.\n2. Заполните реквизиты плательщика и получателя.\n3. Проверьте назначение платежа.\n4. Подпишите ЭЦП и отправьте.\n\nЧастые ошибки: неверный БИК, дублирующийся номер документа, отсутствие НДС в назначении.",
        authorId: manager.id,
        views: 42,
      },
      {
        title: "Правила приёма клиентов на обслуживание",
        category: "Обслуживание",
        excerpt:
          "Регламент идентификации клиента-физ. лица, работы с пакетом документов, открытия счёта.",
        content:
          "Идентификация клиента проводится в соответствии с 115-ФЗ.\n\nОбязательные документы:\n— паспорт РФ\n— СНИЛС\n— ИНН (при наличии)\n\nПри открытии счёта сотрудник обязан сверить фото в паспорте с клиентом и проверить документ по базе МВД.",
        authorId: manager.id,
        views: 28,
      },
      {
        title: "Кредитные продукты: матрица решений",
        category: "Кредитование",
        excerpt:
          "Критерии одобрения потребительского кредита, автокредита и ипотеки по доходу и возрасту клиента.",
        content:
          "Потребительский кредит — до 1 млн ₽, возраст от 21 до 65, доход от 25 000 ₽/мес.\nАвтокредит — до 3 млн ₽, возраст от 23 лет, первый взнос от 15%.\nИпотека — до 20 млн ₽, возраст от 21 до 70 (на момент погашения), первый взнос от 20%.",
        authorId: manager.id,
        views: 15,
      },
    ],
  });

  const allEmployees = await prisma.user.findMany({
    where: { role: "EMPLOYEE" },
    select: { id: true, firstName: true, lastName: true },
  });

  console.log("Creating events…");
  await prisma.event.createMany({
    data: [
      {
        title: "Совещание команды",
        description: "Еженедельное собрание в конференц-зале.",
        startsAt: new Date("2026-04-25T10:00:00"),
        importance: "IMPORTANT",
        createdById: manager.id,
      },
      {
        title: "Корпоратив ко Дню Победы",
        description: "Праздничное мероприятие в ресторане «Казань».",
        startsAt: new Date("2026-05-08T18:00:00"),
        importance: "CORPORATE",
        createdById: manager.id,
      },
      {
        title: "Тимбилдинг: верёвочный парк",
        description: "Активный выезд на природу, сбор у офиса в 9:00.",
        startsAt: new Date("2026-05-22T09:00:00"),
        importance: "ACTIVITY",
        createdById: manager.id,
      },
    ],
  });

  console.log("Creating tasks…");
  const employeeIds = allEmployees.map((e) => e.id);
  await prisma.task.createMany({
    data: [
      {
        title: "Подготовить отчёт по кредитованию за апрель",
        description: "Сводка по выданным кредитам физ. лицам.",
        goal: "Готовый отчёт в формате Excel",
        createdById: manager.id,
        assigneeId: employee.id,
        deadline: new Date("2026-04-30"),
        status: "IN_PROGRESS",
        progress: 70,
      },
      {
        title: "Обзвонить клиентов по просроченным платежам",
        description: "Список в CRM (фильтр «overdue»).",
        createdById: manager.id,
        assigneeId: employee.id,
        deadline: new Date("2026-04-23"),
        status: "TODO",
        progress: 0,
      },
      {
        title: "Пройти курс «Антифрод 2026»",
        description: "Онлайн-курс на корпоративной платформе.",
        goal: "Сертификат о прохождении",
        createdById: manager.id,
        assigneeId: employeeIds[1] ?? employee.id,
        deadline: new Date("2026-05-15"),
        status: "DONE",
        progress: 100,
        result: "Курс пройден, сертификат получен",
        completedAt: new Date("2026-04-15"),
      },
    ],
  });

  console.log("Creating document templates…");
  const templateDefs: Array<{ name: string; type: string; content: string }> = [
    {
      name: "Заявление на отпуск",
      type: "Заявление",
      content:
        "Руководителю {{отдел}}\n{{ФИО_руководителя}}\nот {{должность_сотрудника}}\n{{ФИО_сотрудника}}\n\n\nЗАЯВЛЕНИЕ\n\nПрошу предоставить мне очередной оплачиваемый отпуск продолжительностью {{количество_дней}} календарных дней с «{{дата_начала}}» по «{{дата_окончания}}» {{год}} года.\n\n\n«___» ______________ {{год}} г.\n\n_________________ / {{ФИО_сотрудника}} /\n      подпись",
    },
    {
      name: "Заявление о переносе смены",
      type: "Заявление",
      content:
        "Руководителю отдела {{название_отдела}}\n{{ФИО_руководителя}}\nот {{должность}}\n{{ФИО_сотрудника}}\n\n\nЗАЯВЛЕНИЕ\n\nПрошу перенести смену «{{дата_смены}}» с {{время_начала}} на {{новое_время}} в связи с {{причина}}.\n\nОтработать пропущенные часы обязуюсь «{{дата_отработки}}».\n\n\n«___» ______________ 20__ г.\n\n_________________ / {{ФИО_сотрудника}} /\n      подпись",
    },
    {
      name: "Справка о доходах (2-НДФЛ)",
      type: "Справка",
      content:
        "СПРАВКА о доходах и суммах налога физического лица\nза {{год}} год № {{номер}}\n\n\nНалоговый агент: ПАО «Ак Барс Банк», ИНН 1653001805, КПП 165601001.\n\nСведения о физическом лице — получателе дохода:\n  ФИО: {{ФИО_полностью}}\n  ИНН: {{ИНН}}\n  СНИЛС: {{СНИЛС}}\n  Дата рождения: {{дата_рождения}}\n  Документ: паспорт {{серия_паспорта}} № {{номер_паспорта}}\n\nОбщая сумма дохода: {{сумма_дохода}} руб.\nНалоговая база: {{налоговая_база}} руб.\nСумма исчисленного налога: {{налог}} руб.\n\nСправка выдана для представления по месту требования.\n\nНалоговый агент: _________________ / {{ФИО_ответственного}} /",
    },
    {
      name: "Справка с места работы",
      type: "Справка",
      content:
        "СПРАВКА № {{номер_справки}}\nот «{{дата_выдачи}}»\n\n\nНастоящая справка выдана {{ФИО_сотрудника}} в том, что он(а) действительно работает в ПАО «Ак Барс Банк» в должности «{{должность}}» с «{{дата_приёма}}» по настоящее время.\n\nРазмер среднемесячной заработной платы составляет {{зарплата}} рублей.\n\nСправка выдана для предъявления по месту требования.\n\n\nРуководитель отдела: _________________ / {{ФИО_руководителя}} /\n                              М.П.",
    },
    {
      name: "Кредитный договор (физ. лицо)",
      type: "Договор",
      content:
        "КРЕДИТНЫЙ ДОГОВОР № {{номер_договора}}\nг. Казань, «{{дата}}»\n\n\nПАО «Ак Барс Банк», именуемое в дальнейшем «Банк», в лице {{ФИО_представителя_банка}}, действующего на основании доверенности, с одной стороны, и {{ФИО_заёмщика}}, именуемый(ая) в дальнейшем «Заёмщик», с другой стороны, заключили настоящий Договор о нижеследующем:\n\n1. ПРЕДМЕТ ДОГОВОРА\n1.1. Банк предоставляет Заёмщику кредит в сумме {{сумма_кредита}} рублей на срок {{срок_месяцев}} месяцев под {{ставка}}% годовых.\n1.2. Цель кредита: {{цель}}.\n\n2. ПОРЯДОК ВЫДАЧИ И ПОГАШЕНИЯ\n2.1. Кредит выдаётся единовременно путём зачисления на счёт Заёмщика № {{номер_счёта}}.\n2.2. Ежемесячный аннуитетный платёж: {{платёж}} рублей, дата погашения — {{день_платежа}} число каждого месяца.\n\n3. ОТВЕТСТВЕННОСТЬ СТОРОН\n3.1. За просрочку платежа начисляется неустойка в размере 0,1% от суммы просроченного платежа за каждый день.\n\n4. РЕКВИЗИТЫ И ПОДПИСИ СТОРОН\nБанк: ______________________\nЗаёмщик: ______________________",
    },
    {
      name: "Доверенность на получение документов",
      type: "Доверенность",
      content:
        "ДОВЕРЕННОСТЬ № {{номер}}\nг. {{город}}, «{{дата}}»\n\n\nЯ, {{ФИО_доверителя}}, паспорт {{серия}} № {{номер_паспорта}}, выдан {{кем_выдан}} «{{дата_выдачи}}», зарегистрирован(а) по адресу: {{адрес}},\n\nдоверяю гражданину(ке) {{ФИО_доверенного}}, паспорт {{серия_2}} № {{номер_2}}, выдан {{кем_выдан_2}},\n\nпредставлять мои интересы в ПАО «Ак Барс Банк», получать от моего имени документы, справки, выписки по счетам, а также расписываться за меня по всем вопросам, связанным с настоящим поручением.\n\nДоверенность выдана сроком на {{срок}} без права передоверия.\n\nПодпись доверителя: _________________ / {{ФИО_доверителя}} /",
    },
    {
      name: "Служебная записка о закупке",
      type: "Служебная записка",
      content:
        "Руководителю {{название_отдела}}\n{{ФИО_руководителя}}\nот {{должность_сотрудника}}\n{{ФИО_сотрудника}}\n\n\nСЛУЖЕБНАЯ ЗАПИСКА\n\nПрошу согласовать закупку следующего оборудования/канцелярии для нужд отдела:\n\n1. {{наименование_1}} — {{кол-во_1}} шт. — ориентировочная стоимость {{цена_1}} руб.\n2. {{наименование_2}} — {{кол-во_2}} шт. — ориентировочная стоимость {{цена_2}} руб.\n3. {{наименование_3}} — {{кол-во_3}} шт. — ориентировочная стоимость {{цена_3}} руб.\n\nИтого: {{итого}} руб.\n\nОбоснование: {{обоснование}}.\n\n\n«___» ______________ 20__ г.\n\n_________________ / {{ФИО_сотрудника}} /",
    },
    {
      name: "Уведомление о закрытии счёта",
      type: "Уведомление",
      content:
        "УВЕДОМЛЕНИЕ о закрытии счёта\n№ {{номер_уведомления}} от «{{дата}}»\n\n\nУважаемый(ая) {{ФИО_клиента}}!\n\nУведомляем Вас, что в соответствии с Вашим заявлением от «{{дата_заявления}}» счёт № {{номер_счёта}}, открытый в ПАО «Ак Барс Банк», закрыт «{{дата_закрытия}}».\n\nОстаток денежных средств в размере {{остаток}} рублей выдан/перечислен на реквизиты, указанные в заявлении.\n\nПо всем возникающим вопросам просим обращаться в отделение Банка или по телефону: 8 (800) {{телефон}}.\n\n\nРуководитель отдела обслуживания: _________________ / {{ФИО_руководителя}} /\n                                           М.П.",
    },
    {
      name: "Акт приёма-передачи оборудования",
      type: "Акт",
      content:
        "АКТ приёма-передачи оборудования № {{номер}}\nг. {{город}}, «{{дата}}»\n\n\nМы, нижеподписавшиеся,\nпередающая сторона: {{ФИО_передающего}}, должность — {{должность_1}},\nпринимающая сторона: {{ФИО_принимающего}}, должность — {{должность_2}},\n\nсоставили настоящий Акт о том, что передающая сторона передала, а принимающая сторона приняла следующее оборудование:\n\n1. {{наименование_1}}\n   Инв. номер: {{инв_1}}\n   Состояние: {{сост_1}}\n\n2. {{наименование_2}}\n   Инв. номер: {{инв_2}}\n   Состояние: {{сост_2}}\n\nОборудование передано в рабочем состоянии, комплектность проверена. Претензий не имеем.\n\nПередал: _________________ / {{ФИО_передающего}} /\nПринял:  _________________ / {{ФИО_принимающего}} /",
    },
  ];

  const createdTemplates: Array<{ id: string; name: string }> = [];
  for (const def of templateDefs) {
    const tpl = await prisma.documentTemplate.create({
      data: { ...def, authorId: manager.id },
    });
    await attachPdfToTemplate(tpl.id, def.name, def.type, def.content);
    createdTemplates.push({ id: tpl.id, name: def.name });
    console.log(`  · PDF готов: ${def.name}`);
  }

  const tplVacation = createdTemplates.find((t) => t.name === "Заявление на отпуск")!;
  const tplSick = createdTemplates.find((t) => t.name === "Заявление о переносе смены")!;

  // заполненные
  await prisma.filledDocument.createMany({
    data: [
      {
        templateId: tplVacation.id,
        userId: employee.id,
        content:
          "Заполненное заявление на отпуск сотрудника Петрова П.А. на период с 15.05.2026 по 19.05.2026.",
      },
      {
        templateId: tplVacation.id,
        userId: employee.id,
        content:
          "Заполненное заявление на отпуск сотрудника Петрова П.А. на период с 10.03.2026 по 14.03.2026.",
      },
      {
        templateId: tplSick.id,
        userId: employee.id,
        content:
          "Заполненное заявление о переносе смены 22.04.2026 с утренней на вечернюю.",
      },
    ],
  });

  console.log("Creating reports…");
  await prisma.report.createMany({
    data: [
      {
        title: "Квартальный отчёт Q1 2026",
        type: "Квартальный",
        content: "Итоги первого квартала: рост по вкладам +8%, по кредитам +12%.",
        status: "SUBMITTED",
        authorId: manager.id,
      },
      {
        title: "Отчёт по обслуживанию: март",
        type: "По обслуживанию",
        content: "Проведено 1423 операции. Среднее время обслуживания 7 минут.",
        status: "IN_REVIEW",
        authorId: employee.id,
      },
      {
        title: "Внутренний отчёт по безопасности",
        type: "Внутренний",
        content: "Черновик. Требуется дополнить данными за апрель.",
        status: "DRAFT",
        authorId: employee.id,
      },
    ],
  });

  console.log("Creating notifications…");
  await prisma.notification.createMany({
    data: [
      {
        userId: employee.id,
        title: "Новая задача",
        body: "Вам назначена задача «Подготовить отчёт по кредитованию за апрель»",
        type: "TASK",
      },
      {
        userId: employee.id,
        title: "Заявление одобрено",
        body: "Руководитель одобрил заявление «Изменение графика 22.04»",
        type: "APPLICATION",
        readAt: new Date(),
      },
      {
        userId: employee.id,
        title: "Новое мероприятие",
        body: "Запланировано «Совещание команды» на 25 апреля в 10:00",
        type: "EVENT",
      },
      {
        userId: manager.id,
        title: "Новое заявление на рассмотрение",
        body: "Сотрудник Павел Петров отправил заявление «Отпуск на 5 дней»",
        type: "APPLICATION",
      },
    ],
  });

  console.log("Creating schedule entries for current month…");
  const now = new Date();
  const year = now.getFullYear();
  const month = now.getMonth();
  const days = new Date(year, month + 1, 0).getDate();
  const scheduleOps: Array<Promise<unknown>> = [];
  for (const emp of allEmployees) {
    for (let d = 1; d <= days; d++) {
      const date = new Date(year, month, d);
      const wd = date.getDay();
      const shiftType = wd === 0 || wd === 6 ? "WEEKEND" : "WORK";
      scheduleOps.push(
        prisma.scheduleEntry.create({
          data: {
            userId: emp.id,
            date,
            shiftType,
            shiftStart: shiftType === "WORK" ? "09:00" : null,
            shiftEnd: shiftType === "WORK" ? "18:00" : null,
          },
        }),
      );
    }
  }
  await Promise.all(scheduleOps);

  console.log("Done.");
  console.log("--------------------------------------------------");
  console.log("Demo accounts (password: demo1234):");
  console.log("  Руководитель: manager@demo.local");
  console.log("  Сотрудник:    employee@demo.local");
  console.log("--------------------------------------------------");
}

main()
  .catch((e) => {
    console.error(e);
    process.exit(1);
  })
  .finally(async () => {
    await prisma.$disconnect();
  });
