import PDFDocument from "pdfkit";
import path from "node:path";
import fs from "node:fs";

// шрифты
const FONTS_DIR = path.join(
  process.cwd(),
  "node_modules",
  "dejavu-fonts-ttf",
  "ttf",
);
const FONT_REGULAR = path.join(FONTS_DIR, "DejaVuSans.ttf");
const FONT_BOLD = path.join(FONTS_DIR, "DejaVuSans-Bold.ttf");
const FONT_ITALIC = path.join(FONTS_DIR, "DejaVuSans-Oblique.ttf");

type GenerateOpts = {
  title: string;
  type: string;
  body: string;
};

// генерация
export function generateTemplatePdf({
  title,
  type,
  body,
}: GenerateOpts): Promise<Buffer> {
  return new Promise((resolve, reject) => {
    try {
      const doc = new PDFDocument({
        size: "A4",
        margins: { top: 64, bottom: 64, left: 56, right: 56 },
        bufferPages: true,
        info: {
          Title: title,
          Author: "ПАО «Ак Барс Банк»",
          Subject: type,
        },
      });

      const chunks: Buffer[] = [];
      doc.on("data", (chunk: Buffer) => chunks.push(chunk));
      doc.on("end", () => resolve(Buffer.concat(chunks)));
      doc.on("error", reject);

      // шрифты
      doc.registerFont("Regular", FONT_REGULAR);
      doc.registerFont("Bold", FONT_BOLD);
      doc.registerFont("Italic", FONT_ITALIC);

      // шапка
      doc
        .font("Bold")
        .fontSize(14)
        .fillColor("#1d4a35")
        .text("Ак Барс Банк", { continued: false });
      doc
        .font("Regular")
        .fontSize(9)
        .fillColor("#5a6963")
        .text("Кадровая система · шаблон документа");

      // линия
      const lineY = doc.y + 4;
      doc
        .moveTo(56, lineY)
        .lineTo(doc.page.width - 56, lineY)
        .strokeColor("#d7ddd9")
        .lineWidth(1)
        .stroke();
      doc.moveDown(1.2);

      // заголовок
      doc
        .font("Bold")
        .fontSize(16)
        .fillColor("#0d1915")
        .text(title, { align: "center" });

      // тип
      doc
        .font("Italic")
        .fontSize(10)
        .fillColor("#5a6963")
        .text(type, { align: "center" });

      doc.moveDown(1.5);

      // тело
      doc
        .font("Regular")
        .fontSize(11)
        .fillColor("#0d1915")
        .text(body, {
          align: "left",
          lineGap: 3,
        });

      // футер
      doc.moveDown(2);
      const range = doc.bufferedPageRange();
      for (let i = 0; i < range.count; i++) {
        doc.switchToPage(range.start + i);
        doc
          .font("Regular")
          .fontSize(8)
          .fillColor("#8a9690")
          .text(
            `ПАО «Ак Барс Банк» · стр. ${i + 1} из ${range.count}`,
            56,
            doc.page.height - 40,
            {
              align: "center",
              width: doc.page.width - 112,
            },
          );
      }

      doc.end();
    } catch (err) {
      reject(err);
    }
  });
}

// CLI
if (import.meta.url === `file://${process.argv[1]?.replace(/\\/g, "/")}`) {
  const [, , out, titleArg, typeArg, ...bodyArg] = process.argv;
  if (!out) {
    console.error("Usage: generate-template-pdf.ts <out.pdf> <title> <type> <body>");
    process.exit(1);
  }
  generateTemplatePdf({
    title: titleArg ?? "Test",
    type: typeArg ?? "Прочее",
    body: bodyArg.join(" ") || "Тестовый контент",
  })
    .then((buf) => {
      fs.writeFileSync(out, buf);
      console.log(`Written: ${out}`);
    })
    .catch((e) => {
      console.error(e);
      process.exit(1);
    });
}
