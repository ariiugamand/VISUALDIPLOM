-- AlterTable
ALTER TABLE "DocumentTemplate" ADD COLUMN "pdfFilename" TEXT;
ALTER TABLE "DocumentTemplate" ADD COLUMN "pdfSize" INTEGER;
ALTER TABLE "DocumentTemplate" ADD COLUMN "pdfUrl" TEXT;
